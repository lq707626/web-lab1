package com.hotel.pms.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final JwtAuthFilter jwtAuthFilter;
    private final ObjectMapper objectMapper;

    public SecurityConfig(JwtAuthFilter jwtAuthFilter, ObjectMapper objectMapper) {
        this.jwtAuthFilter = jwtAuthFilter;
        this.objectMapper = objectMapper;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                // 登录接口公开访问
                .requestMatchers("/api/auth/**").permitAll()

                // 游客端接口公开访问
                .requestMatchers("/api/guest/**").permitAll()

                // 系统管理（员工管理）- 仅系统管理员
                .requestMatchers("/api/employees/**").hasRole("系统管理员")

                // 房态管理 - 系统管理员、前台接待、客房经理
                .requestMatchers("/api/rooms/**").hasAnyRole("系统管理员", "前台接待", "客房经理")

                // 房型查询 - 所有登录员工可读（预订、入住、报表都需要选择或展示房型）
                .requestMatchers(HttpMethod.GET, "/api/room-types/**").hasAnyRole(
                    "系统管理员", "客房经理", "前台接待", "收银", "总经理")

                // 房型维护 - 系统管理员、客房经理
                .requestMatchers("/api/room-types/**").hasAnyRole("系统管理员", "客房经理")

                // 预订管理 - 系统管理员、前台接待
                .requestMatchers("/api/reservations/**").hasAnyRole("系统管理员", "前台接待")

                // 入住管理 - 系统管理员、前台接待
                .requestMatchers("/api/checkins/**").hasAnyRole("系统管理员", "前台接待")

                // 账单管理 - 系统管理员、收银
                .requestMatchers("/api/bills/**").hasAnyRole("系统管理员", "收银")

                // 会员查询 - 系统管理员、前台接待、收银（收银需要进行会员余额支付）
                .requestMatchers(HttpMethod.GET, "/api/members/**").hasAnyRole(
                    "系统管理员", "前台接待", "收银")

                // 会员余额消费 - 系统管理员、前台接待、收银
                .requestMatchers(HttpMethod.PUT, "/api/members/*/consume").hasAnyRole(
                    "系统管理员", "前台接待", "收银")

                // 会员管理 - 系统管理员、前台接待
                .requestMatchers("/api/members/**").hasAnyRole("系统管理员", "前台接待")

                // 支付管理 - 系统管理员、收银
                .requestMatchers("/api/payment/**").hasAnyRole("系统管理员", "收银")

                // 统计报表 - 与报告 2.1.2 角色表一致：系统管理员、客房经理、总经理
                .requestMatchers("/api/statistics/**").hasAnyRole(
                    "系统管理员", "客房经理", "总经理")

                // 其他所有请求需要登录
                .anyRequest().authenticated()
            )
            // 配置401/403 JSON返回
            .exceptionHandling(ex -> ex
                .authenticationEntryPoint((request, response, authException) -> {
                    response.setStatus(200);
                    response.setContentType(MediaType.APPLICATION_JSON_VALUE);
                    response.setCharacterEncoding("UTF-8");
                    Map<String, Object> result = new HashMap<>();
                    result.put("code", 401);
                    result.put("message", "未登录或登录已过期，请重新登录");
                    result.put("data", null);
                    response.getWriter().write(objectMapper.writeValueAsString(result));
                })
                .accessDeniedHandler((request, response, accessDeniedException) -> {
                    response.setStatus(200);
                    response.setContentType(MediaType.APPLICATION_JSON_VALUE);
                    response.setCharacterEncoding("UTF-8");
                    Map<String, Object> result = new HashMap<>();
                    result.put("code", 403);
                    result.put("message", "无权限访问该资源");
                    result.put("data", null);
                    response.getWriter().write(objectMapper.writeValueAsString(result));
                })
            )
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    /**
     * CORS配置
     */
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOriginPatterns(List.of("*"));
        configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(List.of("*"));
        configuration.setAllowCredentials(true);
        configuration.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}
