package com.hotel.pms.modules.reservation;

import com.hotel.pms.common.PageResult;
import com.hotel.pms.entity.Reservation;
import com.hotel.pms.vo.ReservationVO;

import java.util.List;

public interface ReservationService {

    List<ReservationVO> list();

    PageResult<ReservationVO> page(int pageNum, int pageSize, String keyword, String status);

    ReservationVO findById(Long id);

    ReservationVO create(Reservation reservation);

    /** 编辑预订信息（客人、日期、房型、间数、备注） */
    void update(Long id, Reservation reservation);

    /** 逻辑删除预订 */
    void delete(Long id);

    void confirm(Long id);

    void cancel(Long id, String reason);

    ReservationVO queryByPhoneAndCode(String phone, String queryCode);
}
