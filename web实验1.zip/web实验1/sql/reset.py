import pymysql

conn = pymysql.connect(host='your-vm-ip', user='root', password='your_password',
                       database='mydb', charset='utf8mb4')
cur = conn.cursor()

sqls = [
    ('软删入住记录', "UPDATE checkin SET is_deleted=1 WHERE is_deleted=0"),
    ('软删账单',     "UPDATE bill SET is_deleted=1 WHERE is_deleted=0"),
    ('软删账单明细', "UPDATE bill_item SET is_deleted=1 WHERE is_deleted=0"),
    ('软删预订',     "UPDATE reservation SET is_deleted=1 WHERE is_deleted=0"),
    ('软删支付流水', "UPDATE payment SET is_deleted=1 WHERE is_deleted=0"),
    ('房间恢复空房(除306)', "UPDATE room SET room_status='空房' WHERE room_number!='306' AND is_deleted=0"),
    ('306设为维修中', "UPDATE room SET room_status='维修中' WHERE room_number='306' AND is_deleted=0"),
    ('清测试会员(保留前22条)', "UPDATE member SET is_deleted=1 WHERE id>22"),
    ('清测试员工(按用户名)', "UPDATE employee SET is_deleted=1 WHERE username NOT IN ('admin','front','cashier','manager','gm')"),
    ('门锁复位',     "UPDATE room_lock SET status='已锁闭'"),
]

for label, s in sqls:
    cur.execute(s)
    print(f'  {cur.rowcount:>4} rows  <- {label}')

conn.commit()

cur.execute("SELECT room_number, room_status FROM room WHERE is_deleted=0 ORDER BY room_number")
print('\n房间状态：')
for r in cur.fetchall():
    print(f'  {r[0]}  {r[1]}')

cur.execute("SELECT username, role FROM employee WHERE is_deleted=0 ORDER BY id")
print('\n种子员工：')
for r in cur.fetchall():
    print(f'  {r[0]}  {r[1]}')

cur.close()
conn.close()
print('\nDone.')
