# E2E 自动化测试说明

本目录是《Vue3 可测试性前端开发要求》任务3要求的 Playwright E2E UI 自动化测试。

## 目录结构

```
tests-e2e/
├── helpers/
│   └── auth.js               # 登录、ElMessage 断言、MessageBox 确认、下拉选择等公共辅助
├── login.spec.js             # 登录与权限（7.2.1）：13 条
├── room.spec.js              # 房态管理（7.2.2）：10 条
├── reservation.spec.js       # 预订管理（7.2.3）：12 条
├── checkin.spec.js           # 入住管理（7.2.4）：11 条
├── bill.spec.js              # 账单结算（7.2.5）：6 条
├── cashier.spec.js           # 收银结算（7.2.6）：6 条
├── member.spec.js            # 会员管理（7.2.7）：12 条
├── statistics.spec.js        # 报表统计（7.2.8）：6 条
├── employee.spec.js          # 员工管理（7.2.9）：8 条
├── thirdparty.spec.js        # 第三方对接/门锁（7.2.10）：8 条
├── guest.spec.js             # 游客门户（7.2.11）：8 条
├── security.spec.js           # 异常与安全（7.3/7.5）：8 条
├── screenshots/               # 关键步骤截图（模块名-序号.png）
└── report/                    # playwright-html 报告（运行后生成）
```

**总计 108 条用例，覆盖报告 7.2 全部业务模块 + 7.3/7.5 中 E2E 可验证的部分。**

## 报告 173 条用例的覆盖说明

| 报告章节 | 用例数 | E2E 覆盖 | 未覆盖原因 |
|---|---|---|---|
| 7.2.1 登录与权限 | 15 | 13 | 连续失败锁定（会真锁 15 分钟，污染数据）、越权接口（已在 security.spec.js 用 API 方式覆盖） |
| 7.2.2 房态管理 | 15 | 10 | 颜色状态（CSS 颜色断言不稳定）、乐观锁冲突（需双标签页并发）、非法房态值（接口层） |
| 7.2.3 预订管理 | 16 | 12 | 库存不足/日期不重叠（需造满房数据）、分页（仅断言可见） |
| 7.2.4 入住管理 | 13 | 11 | 关联预订入住（需先造已确认订单）、入住后房态联动（跨页面） |
| 7.2.5 账单结算 | 11 | 6 | 退款（需微信/支付宝已结算账单，沙箱数据可能没有）、金额计算（接口层） |
| 7.2.6 收银结算 | 9 | 6 | 微信/支付宝沙箱支付（点"我已支付"弹窗交互复杂）、会员余额支付（需余额充足会员） |
| 7.2.7 会员管理 | 12 | 12 | 全覆盖 |
| 7.2.8 报表统计 | 7 | 6 | 图表空状态（需无数据日期） |
| 7.2.9 员工管理 | 9 | 8 | 禁用后登录失败（需重新登录验证） |
| 7.2.10 第三方对接 | 9 | 8 | 同房间重复发卡（需连续操作两次） |
| 7.2.11 游客门户 | 9 | 8 | 日期校验（与预订重复） |
| 7.3 异常与边界 | 17 | 8 | 停后端/停 MySQL/停 Redis（E2E 无法模拟）、Token 篡改（JWT 层）、跨月间夜（需造数据） |
| 7.4 数据库约束 | 16 | 0 | 纯数据库层，需 SQL 直连，不属于 E2E |
| 7.5 安全性 | 15 | 5 | 密码加密/JWT 生成/Token 过期（需看数据库或构造 JWT） |

## 快速开始（三步）

### 第 1 步：启动后端（8080）

在你平时启动 Spring Boot 的方式里启动它（IDEA 里点运行，或者 `mvn spring-boot:run`），确认控制台看到 `Started ... in X seconds` 日志。

依赖：MySQL（虚拟机 your-vm-ip:3306）和 Redis（your-vm-ip:6379）要先起着。

### 第 2 步：启动前端（5173）

新开一个 PowerShell 窗口：

```powershell
cd C:\Users\lq\Desktop\web实验1\hotel-pms-frontend
npm run dev
```

看到 `➜ Local: http://localhost:5173/` 就行，这个窗口**别关**。

> 首次运行如果没装过依赖，先 `npm install`。

### 第 3 步：跑测试

再新开一个 PowerShell 窗口（第三个窗口）：

```powershell
cd C:\Users\lq\Desktop\web实验1\hotel-pms-frontend
```

首次运行先装 Playwright 浏览器（已经装过就跳过）：

```powershell
npx playwright install chromium
```

然后选一种方式跑：

```powershell
# A. 无头跑（后台跑，不看浏览器，最快，全量约 10-15 分钟）
npx playwright test

# B. 有头跑（看着浏览器操作）
npx playwright test --headed

# C. 有头 + 慢动作（看得最清楚，新手推荐）
npx playwright test --headed --slow-mo=500

# D. 只跑某个模块先试水（推荐先跑这个）
npx playwright test member --headed --slow-mo=300

# E. 交互式 UI（能点选、单步、看时间线）
npm run test:e2e:ui
```

### 跑完看结果

```powershell
# 打开 HTML 报告（失败截图、日志都在里面）
npm run test:e2e:report
```

截图保存在 `tests-e2e/screenshots/` 目录里，按"模块-序号-动作.png"命名。

### 建议顺序

第一次跑先用 D 跑 `member` 模块试试水（12 条，约 1 分钟），确认登录、新增、删除流程都通了，再全量跑 A。

## 常用命令速查

| 命令 | 作用 |
|---|---|
| `npx playwright test` | 全量无头跑 |
| `npx playwright test --headed` | 全量有头跑 |
| `npx playwright test --headed --slow-mo=500` | 有头慢动作 |
| `npx playwright test member` | 只跑会员模块 |
| `npx playwright test login reservation` | 跑多个模块 |
| `npx playwright test --grep "删除"` | 按用例名关键词筛 |
| `npx playwright test --workers=3` | 并行跑（加快，但数据隔离依赖时间戳） |
| `npm run test:e2e:ui` | 交互式 UI 调试 |
| `npm run test:e2e:report` | 查看 HTML 报告 |

## 编写约定（对应任务3要求）

1. **定位**：页面上所有业务控件一律 `page.getByTestId('xxx')`，testid 全部取自前端根目录 `testid-list.md`。
   不使用 class、nth-child、DOM 顺序定位。
2. **登录前置**：每个 spec 的 `test.beforeEach` 调用 `loginAsAdmin(page, '/xxx')`，自动以 admin/123456 登录后再进入目标页面。
3. **等待策略**：不写死 `setTimeout`。等待信号为：
   - `ElMessage.success/error` 出现（`expectMessage`）
   - 弹窗 `data-testid` 可见
   - 表格行 `{module}-row` 出现
   - loading 按钮恢复
4. **截图**：关键步骤 `page.screenshot({ path: 'tests-e2e/screenshots/模块-序号-动作.png' })`。
5. **确认弹窗**：删除/禁用/退房等操作通过 `ElMessageBox`，统一用 `confirmMessageBox(page)` 点"确定"。
6. **数据隔离**：每条用例自己造数据，手机号/用户名/姓名用 `Date.now()` 后缀保证唯一，用例结束不依赖他人。

## 关于下拉选项与日期面板的说明

业务控件本身都带 `data-testid`，但 Element Plus 的下拉面板（`.el-select-dropdown`）和日期面板是组件库渲染在 `<body>` 末尾的浮层，前端无法给单个选项加 testid。因此：

- 打开下拉用 `getByTestId(select-testid).click()`；
- 选择选项时按**选项可见文本**匹配（如"大床房"、"普通会员"、"前台接待"），这是业务数据文本，不是靠 DOM 顺序；
- 日期选择器直接 `fill('YYYY-MM-DD')` + `Enter`。

这是组件库浮层限制下的必要妥协，spec 文件本身不出现 class 定位业务元素。
