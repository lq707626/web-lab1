<template>
  <div>
    <el-row :gutter="12">
      <el-col :xs="12" :sm="6" v-for="card in cards" :key="card.code">
        <el-card shadow="never" class="stat-card" :data-testid="`statistics-card-${card.code}`">
          <div class="stat-label">{{ card.label }}</div>
          <div class="stat-value" :class="card.type" :data-testid="`statistics-value-${card.code}`">{{ card.value }}</div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="12">
      <el-col :xs="24" :md="10">
        <el-card shadow="never" class="chart-card">
          <template #header>
            <div class="chart-header">
              <span>房态分布统计</span>
              <el-tag size="small" type="info" data-testid="statistics-room-total-tag">共 {{ overview.roomTotal || 0 }} 间</el-tag>
            </div>
          </template>
          <div ref="statusChartRef" class="chart" data-testid="statistics-status-chart"></div>
        </el-card>
      </el-col>
      <el-col :xs="24" :md="14">
        <el-card shadow="never" class="chart-card">
          <template #header>
            <div class="chart-header">
              <span>会员等级分布</span>
              <el-tag size="small" type="info" data-testid="statistics-member-total-tag">共 {{ overview.memberTotal || 0 }} 位会员</el-tag>
            </div>
          </template>
          <div ref="memberChartRef" class="chart" data-testid="statistics-member-chart"></div>
        </el-card>
      </el-col>
    </el-row>

    <el-card shadow="never" class="chart-card">
      <template #header>
        <div class="chart-header">
          <span>营收趋势（近 7 天，按结算日期）</span>
          <el-date-picker
            v-model="dateRange"
            type="daterange"
            value-format="YYYY-MM-DD"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            size="small"
            style="width: 260px"
            data-testid="statistics-trend-date-picker"
          />
        </div>
      </template>
      <div ref="trendChartRef" class="chart" data-testid="statistics-trend-chart"></div>
    </el-card>
  </div>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import * as echarts from 'echarts'
import api from '../api'
import { ROOM_STATUS_LIST, money } from '../utils/format'

const overview = ref({})
const roomStatusData = ref([])
const memberLevelData = ref([])
const trendData = ref([])
const dateRange = ref([])

const statusChartRef = ref(null)
const memberChartRef = ref(null)
const trendChartRef = ref(null)

let statusChart = null
let memberChart = null
let trendChart = null

const cards = computed(() => [
  { code: 'revenue-today', label: '今日营收', value: `¥${money(overview.value.revenueToday)}`, type: 'success' },
  { code: 'revenue-month', label: '本月营收', value: `¥${money(overview.value.revenueMonth)}`, type: 'success' },
  { code: 'occupancy-rate', label: '入住率', value: `${Number(overview.value.occupancyRate || 0).toFixed(2)}%`, type: 'warning' },
  { code: 'adr', label: '平均房价 ADR', value: `¥${money(overview.value.adr)}`, type: '' },
  { code: 'room-total', label: '客房总数', value: `${overview.value.roomTotal ?? 0} 间`, type: '' },
  { code: 'checkin-active', label: '在住人数', value: `${overview.value.checkinActive ?? 0} 人`, type: 'danger' },
  { code: 'reservation-today', label: '今日预订', value: `${overview.value.reservationToday ?? 0} 单`, type: '' },
  { code: 'member-total', label: '会员总数', value: `${overview.value.memberTotal ?? 0} 人`, type: '' }
])

const filteredTrend = computed(() => trendData.value)

function emptyTitle() {
  return {
    text: '暂无数据',
    left: 'center',
    top: 'center',
    textStyle: { color: '#909399', fontSize: 14, fontWeight: 'normal' }
  }
}

function renderStatusChart() {
  if (!statusChartRef.value) return
  if (!statusChart) statusChart = echarts.init(statusChartRef.value)
  const data = ROOM_STATUS_LIST.map(item => {
    const hit = roomStatusData.value.find(row => row.status === item.label)
    return { name: item.label, value: hit ? Number(hit.count) : 0, itemStyle: { color: item.color } }
  }).filter(item => item.value > 0)

  statusChart.setOption(
    {
      title: data.length ? { show: false } : emptyTitle(),
      tooltip: { trigger: 'item', formatter: '{b}：{c} 间（{d}%）' },
      legend: { bottom: 0, icon: 'circle' },
      series: [
        {
          type: 'pie',
          radius: ['40%', '65%'],
          center: ['50%', '45%'],
          avoidLabelOverlap: true,
          label: { formatter: '{b}\n{c} 间' },
          data
        }
      ]
    },
    true
  )
  statusChart.resize()
}

function renderMemberChart() {
  if (!memberChartRef.value) return
  if (!memberChart) memberChart = echarts.init(memberChartRef.value)
  const levels = ['普通会员', '银卡会员', '金卡会员', '钻石会员']
  const values = levels.map(level => {
    const hit = memberLevelData.value.find(row => row.level === level)
    return hit ? Number(hit.count) : 0
  })
  const total = values.reduce((sum, v) => sum + v, 0)

  memberChart.setOption(
    {
      title: total ? { show: false } : emptyTitle(),
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
      grid: { left: 50, right: 30, top: 30, bottom: 40 },
      xAxis: { type: 'category', data: levels, axisTick: { show: false } },
      yAxis: { type: 'value', minInterval: 1 },
      series: [
        {
          type: 'bar',
          barWidth: 36,
          data: values,
          itemStyle: { color: '#409EFF', borderRadius: [4, 4, 0, 0] },
          label: { show: true, position: 'top' }
        }
      ]
    },
    true
  )
  memberChart.resize()
}

function renderTrendChart() {
  if (!trendChartRef.value) return
  if (!trendChart) trendChart = echarts.init(trendChartRef.value)
  const rows = trendData.value
  const dates = rows.map(row => String(row.date || ''))
  const revenues = rows.map(row => Number(row.revenue || 0))

  trendChart.setOption(
    {
      title: rows.length ? { show: false } : emptyTitle(),
      tooltip: {
        trigger: 'axis',
        formatter: params => {
          if (!params.length) return ''
          return `${params[0].axisValue}<br/>营收：¥${money(params[0].value)}`
        }
      },
      grid: { left: 60, right: 30, top: 30, bottom: 50 },
      xAxis: { type: 'category', data: dates, boundaryGap: false },
      yAxis: { type: 'value', name: '营收(元)' },
      series: [
        {
          type: 'line',
          smooth: true,
          data: revenues,
          areaStyle: { opacity: 0.15 },
          itemStyle: { color: '#67C23A' },
          lineStyle: { width: 2 }
        }
      ]
    },
    true
  )
  trendChart.resize()
}

function renderAll() {
  renderStatusChart()
  renderMemberChart()
  renderTrendChart()
}

function handleResize() {
  statusChart?.resize()
  memberChart?.resize()
  trendChart?.resize()
}

async function load() {
  try {
    const [overviewRes, statusRes, memberRes] = await Promise.all([
      api.get('/statistics/overview'),
      api.get('/statistics/room-status'),
      api.get('/statistics/member-level')
    ])
    overview.value = overviewRes.data || {}
    roomStatusData.value = statusRes.data || []
    memberLevelData.value = memberRes.data || []
  } catch (e) {
    // 请求失败时保持空状态，图表展示"暂无数据"，页面不崩溃（报告 6.3）
  }
  await nextTick()
  renderStatusChart()
  renderMemberChart()
  await loadTrend()
}

/** 营收趋势：日期范围由后端按 settle_time 过滤（报告 6.2.8 日期筛选） */
async function loadTrend() {
  const params = {}
  if (dateRange.value && dateRange.value.length === 2) {
    params.start = dateRange.value[0]
    params.end = dateRange.value[1]
  }
  try {
    const res = await api.get('/statistics/revenue-trend', { params })
    trendData.value = res.data || []
  } catch (e) {
    trendData.value = []
  }
  await nextTick()
  renderTrendChart()
}

watch(dateRange, () => {
  loadTrend()
})

onMounted(async () => {
  await load()
  window.addEventListener('resize', handleResize)
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', handleResize)
  statusChart?.dispose()
  memberChart?.dispose()
  trendChart?.dispose()
})
</script>

<style scoped>
.stat-card {
  margin-bottom: 12px;
}
.stat-label {
  color: #909399;
  font-size: 13px;
}
.stat-value {
  font-size: 22px;
  font-weight: 600;
  margin-top: 6px;
  color: #303133;
}
.stat-value.success {
  color: #67c23a;
}
.stat-value.warning {
  color: #e6a23c;
}
.stat-value.danger {
  color: #f56c6c;
}
.chart-card {
  margin-bottom: 12px;
}
.chart-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 14px;
  font-weight: 600;
}
.chart {
  height: 300px;
  width: 100%;
}
</style>
