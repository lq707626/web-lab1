import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import { firstPathForRole, menusForRole } from '../utils/permission'

export const useUserStore = defineStore('user', () => {
  const token = ref(localStorage.getItem('token') || '')
  const name = ref(localStorage.getItem('name') || '')
  const role = ref(localStorage.getItem('role') || '')
  const username = ref(localStorage.getItem('username') || '')

  const isLoggedIn = computed(() => !!token.value)
  const menus = computed(() => menusForRole(role.value))
  const homePath = computed(() => firstPathForRole(role.value) || '/login')

  function setLogin(data) {
    token.value = data.token || ''
    name.value = data.name || data.username || ''
    role.value = data.role || ''
    username.value = data.username || ''
    localStorage.setItem('token', token.value)
    localStorage.setItem('name', name.value)
    localStorage.setItem('role', role.value)
    localStorage.setItem('username', username.value)
  }

  function logout() {
    token.value = ''
    name.value = ''
    role.value = ''
    username.value = ''
    localStorage.clear()
  }

  return { token, name, role, username, isLoggedIn, menus, homePath, setLogin, logout }
})
