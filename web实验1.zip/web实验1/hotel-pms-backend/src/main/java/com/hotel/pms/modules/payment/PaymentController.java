package com.hotel.pms.modules.payment;

import com.hotel.pms.common.Result;
import com.hotel.pms.entity.Payment;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @GetMapping
    public Result<List<Payment>> list() {
        return Result.success(paymentService.list());
    }

    @GetMapping("/{id}")
    public Result<Payment> findById(@PathVariable Long id) {
        Payment payment = paymentService.findById(id);
        if (payment == null) {
            return Result.error("支付单不存在");
        }
        return Result.success(payment);
    }

    /**
     * 支付下单（沙箱）
     */
    @PostMapping("/create")
    public Result<Payment> create(@RequestBody Map<String, Object> body) {
        Long billId = Long.valueOf(body.get("billId").toString());
        String orderNo = (String) body.get("orderNo");
        String channel = (String) body.get("channel");
        BigDecimal amount = new BigDecimal(body.get("amount").toString());
        return Result.success(paymentService.createPayment(billId, orderNo, channel, amount));
    }

    /**
     * 支付回调（沙箱）
     */
    @PutMapping("/callback/{paymentNo}")
    public Result<Payment> callback(@PathVariable String paymentNo) {
        return Result.success(paymentService.mockPayCallback(paymentNo));
    }

    /**
     * 退款（同步把账单标记为已退款）
     */
    @PutMapping("/refund/{paymentNo}")
    public Result<Payment> refund(@PathVariable String paymentNo) {
        return Result.success(paymentService.refund(paymentNo));
    }
}
