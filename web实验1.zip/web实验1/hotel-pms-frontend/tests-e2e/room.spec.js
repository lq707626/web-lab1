// 房态管理模块 E2E
// 对应用例：报告 7.2.2 房态管理模块测试
import { test, expect } from '@playwright/test'
import { loginAsAdmin, expectMessage, selectOption } from './helpers/auth.js'

test.describe('房态管理', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page, '/room')
  })

  test('房态图渲染：所有房间卡片可见，按楼层分组', async ({ page }) => {
    // 至少渲染出 10 个以上房间卡片（报告写 18 间）
    await page.getByTestId('room-cell').first().waitFor({ state: 'visible' })
    const count = await page.getByTestId('room-cell').count()
    expect(count).toBeGreaterThanOrEqual(10)
    await page.screenshot({ path: 'tests-e2e/screenshots/room-01-render.png', fullPage: true })
  })

  test('图例与筛选：点击"维修中"只显示对应状态，再点恢复', async ({ page }) => {
    await page.getByTestId('room-filter-repair').click()
    // 筛选后所有可见房间都是维修中
    const cells = page.getByTestId('room-cell')
    const n = await cells.count()
    for (let i = 0; i < Math.min(n, 3); i++) {
      await expect(cells.nth(i)).toHaveAttribute('data-room-status', '维修中')
    }
    await page.screenshot({ path: 'tests-e2e/screenshots/room-02-filter-repair.png', fullPage: true })
    // 再点一次取消筛选
    await page.getByTestId('room-filter-repair').click()
    await page.getByTestId('room-cell').first().waitFor({ state: 'visible' })
  })

  test('全部按钮恢复显示所有房间', async ({ page }) => {
    const before = await page.getByTestId('room-cell').count()
    await page.getByTestId('room-filter-empty').click()
    await page.waitForTimeout(200) // 等前端过滤
    const afterFilter = await page.getByTestId('room-cell').count()
    expect(afterFilter).toBeLessThan(before)
    await page.getByTestId('room-filter-all').click()
    await page.waitForTimeout(200)
    const afterAll = await page.getByTestId('room-cell').count()
    expect(afterAll).toBe(before)
    await page.screenshot({ path: 'tests-e2e/screenshots/room-03-filter-all.png', fullPage: true })
  })

  test('房型价格显示：卡片上有 ¥ 价格', async ({ page }) => {
    const first = page.getByTestId('room-cell').first()
    await expect(first).toContainText('¥')
    await page.screenshot({ path: 'tests-e2e/screenshots/room-04-price.png', fullPage: true })
  })

  test('查看房间详情：点击卡片弹出详情对话框', async ({ page }) => {
    await page.getByTestId('room-cell').first().click()
    await page.getByTestId('room-detail-dialog').waitFor({ state: 'visible' })
    // 详情里应包含房间号、门锁、设施等字段
    await expect(page.getByTestId('room-detail-dialog')).toContainText('房间号')
    await expect(page.getByTestId('room-detail-dialog')).toContainText('门锁')
    await expect(page.getByTestId('room-detail-dialog')).toContainText('客房设施')
    await page.screenshot({ path: 'tests-e2e/screenshots/room-05-detail.png', fullPage: true })
    await page.getByTestId('room-status-cancel-btn').click()
  })

  test('门锁编号在详情中展示', async ({ page }) => {
    await page.getByTestId('room-cell').first().click()
    await page.getByTestId('room-detail-dialog').waitFor({ state: 'visible' })
    await expect(page.getByTestId('room-detail-dialog')).toContainText('LOCK-')
    await page.screenshot({ path: 'tests-e2e/screenshots/room-13-lock.png', fullPage: true })
    await page.getByTestId('room-status-cancel-btn').click()
  })

  test('房态变更：空房 → 维修中 → 空房，提示成功', async ({ page }) => {
    // 先筛空房
    await page.getByTestId('room-filter-empty').click()
    const cell = page.getByTestId('room-cell').first()
    await cell.waitFor({ state: 'visible' })
    const roomNo = await cell.getAttribute('data-room-number')
    await cell.click()

    await page.getByTestId('room-detail-dialog').waitFor({ state: 'visible' })
    await selectOption(page, 'room-status-select', '维修中')
    await page.screenshot({ path: 'tests-e2e/screenshots/room-06-to-repair.png', fullPage: true })
    await page.getByTestId('room-status-submit-btn').click()

    await expectMessage(page, '房态已更新')

    // 等待详情对话框完全关闭，避免关闭动画/loading mask 拦截下一次点击
    await page.getByTestId('room-detail-dialog').waitFor({ state: 'hidden', timeout: 5_000 })

    // 房间已变成"维修中"，从空房筛选里消失了，切到"全部"才能再点到它
    await page.getByTestId('room-filter-all').click()

    // 改回空房
    await page.locator(`[data-testid="room-cell"][data-room-number="${roomNo}"]`).first().click()
    await page.getByTestId('room-detail-dialog').waitFor({ state: 'visible' })
    await selectOption(page, 'room-status-select', '空房')
    await page.getByTestId('room-status-submit-btn').click()
    await expectMessage(page, '房态已更新')
    await page.screenshot({ path: 'tests-e2e/screenshots/room-06-restore-empty.png', fullPage: true })
  })

  test('已入住房间不能直接修改房态', async ({ page }) => {
    // 筛已入住
    await page.getByTestId('room-filter-occupied').click()
    const occupied = page.getByTestId('room-cell')
    if ((await occupied.count()) === 0) {
      // 没有已入住房间，跳过（不算失败）
      test.info().annotations.push({ type: 'skip', description: '当前无已入住房间' })
      return
    }
    await occupied.first().click()
    await page.getByTestId('room-detail-dialog').waitFor({ state: 'visible' })
    await selectOption(page, 'room-status-select', '空房')
    await page.getByTestId('room-status-submit-btn').click()
    const err = page.locator('.el-message--error').last()
    await err.waitFor({ state: 'visible', timeout: 8_000 })
    await expect(err).toContainText(/已入住房间需先办理退房/)
    await page.screenshot({ path: 'tests-e2e/screenshots/room-09-occupied-forbidden.png', fullPage: true })
  })

  test('非法状态流转：维修中 → 已入住 被拒绝', async ({ page }) => {
    await page.getByTestId('room-filter-repair').click()
    const repair = page.getByTestId('room-cell')
    if ((await repair.count()) === 0) {
      test.info().annotations.push({ type: 'skip', description: '当前无维修中房间' })
      return
    }
    await repair.first().click()
    await page.getByTestId('room-detail-dialog').waitFor({ state: 'visible' })
    await selectOption(page, 'room-status-select', '已入住')
    await page.getByTestId('room-status-submit-btn').click()
    const err = page.locator('.el-message--error').last()
    await err.waitFor({ state: 'visible', timeout: 8_000 })
    await expect(err).toContainText(/不允许变更/)
    await page.screenshot({ path: 'tests-e2e/screenshots/room-10-illegal-transition.png', fullPage: true })
  })

  test('刷新房态按钮可点击并重新加载', async ({ page }) => {
    await page.getByTestId('room-refresh-btn').click()
    // loading 出现后消失
    await page.getByTestId('room-cell').first().waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/room-15-refresh.png', fullPage: true })
  })
})
