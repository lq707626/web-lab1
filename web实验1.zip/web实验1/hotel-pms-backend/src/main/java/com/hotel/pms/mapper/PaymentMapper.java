package com.hotel.pms.mapper;

import com.hotel.pms.entity.Payment;
import org.apache.ibatis.annotations.*;
import java.util.List;

public interface PaymentMapper {

    @Select("SELECT * FROM payment WHERE is_deleted = 0 ORDER BY create_time DESC")
    List<Payment> findAll();

    @Select("SELECT * FROM payment WHERE id = #{id} AND is_deleted = 0")
    Payment findById(@Param("id") Long id);

    @Select("SELECT * FROM payment WHERE payment_no = #{paymentNo} AND is_deleted = 0")
    Payment findByPaymentNo(@Param("paymentNo") String paymentNo);

    @Select("SELECT * FROM payment WHERE bill_id = #{billId} AND is_deleted = 0")
    Payment findByBillId(@Param("billId") Long billId);

    @Insert("INSERT INTO payment(payment_no, order_no, bill_id, channel, amount, status, create_by, remark) " +
            "VALUES(#{paymentNo}, #{orderNo}, #{billId}, #{channel}, #{amount}, #{status}, #{createBy}, #{remark})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Payment payment);

    @Update("UPDATE payment SET status=#{status}, trade_no=#{tradeNo}, pay_time=#{payTime}, " +
            "update_time=NOW() WHERE id=#{id}")
    int updatePayResult(Payment payment);

    @Update("UPDATE payment SET status=#{status}, refund_time=#{refundTime}, update_time=NOW() " +
            "WHERE id=#{id}")
    int updateRefund(Payment payment);
}
