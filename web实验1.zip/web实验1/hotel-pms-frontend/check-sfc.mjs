/**
 * 临时校验脚本：在进程内用 @vue/compiler-sfc 解析并编译所有 .vue 文件，
 * 不依赖 esbuild 子进程，用于在沙箱受限时验证语法。
 * 校验完成后可删除。
 */
import { readdirSync, readFileSync, statSync } from 'node:fs'
import { join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'
import { parse, compileTemplate, compileScript } from '@vue/compiler-sfc'

const root = fileURLToPath(new URL('./src/', import.meta.url))

function walk(dir) {
  const out = []
  for (const name of readdirSync(dir)) {
    const full = join(dir, name)
    if (statSync(full).isDirectory()) out.push(...walk(full))
    else if (name.endsWith('.vue')) out.push(full)
  }
  return out
}

let failures = 0
const files = walk(root)
for (const file of files) {
  const source = readFileSync(file, 'utf8')
  const rel = relative(root, file)
  try {
    const { descriptor, errors } = parse(source, { filename: file })
    if (errors.length) throw errors[0]
    if (descriptor.script || descriptor.scriptSetup) {
      compileScript(descriptor, { id: rel })
    }
    if (descriptor.template) {
      const res = compileTemplate({
        source: descriptor.template.content,
        filename: file,
        id: rel,
        compilerOptions: { scopeId: 'data-v-x' }
      })
      if (res.errors.length) throw res.errors[0]
    }
    console.log(`OK    ${rel}`)
  } catch (e) {
    failures++
    console.log(`FAIL  ${rel}\n      ${e.message || e}`)
  }
}

// JS 文件语法检查：用 @babel/parser 在进程内解析（沙箱禁止 spawn 子进程）
import { parse as babelParse } from '@babel/parser'
for (const f of ['utils/useRowAction.js', 'utils/permission.js', 'utils/format.js', 'router/index.js', 'store/user.js', 'api/index.js', 'main.js']) {
  const full = join(root, f)
  try {
    babelParse(readFileSync(full, 'utf8'), { sourceType: 'module', plugins: ['jsx'] })
    console.log(`OK    ${f}`)
  } catch (e) {
    failures++
    console.log(`FAIL  ${f}\n      ${e.message}`)
  }
}

console.log(failures === 0 ? `\nALL PASS (${files.length} vue files)` : `\n${failures} FAILURE(S)`)
process.exit(failures === 0 ? 0 : 1)
