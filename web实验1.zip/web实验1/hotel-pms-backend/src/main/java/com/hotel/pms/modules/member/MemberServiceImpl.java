package com.hotel.pms.modules.member;

import com.hotel.pms.common.BizException;
import com.hotel.pms.common.PageResult;
import com.hotel.pms.common.SecurityUtil;
import com.hotel.pms.entity.Member;
import com.hotel.pms.entity.MemberTransaction;
import com.hotel.pms.mapper.MemberMapper;
import com.hotel.pms.mapper.MemberTransactionMapper;
import com.hotel.pms.vo.MemberVO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MemberServiceImpl implements MemberService {

    private final MemberMapper memberMapper;
    private final MemberTransactionMapper transactionMapper;

    public MemberServiceImpl(MemberMapper memberMapper,
                             MemberTransactionMapper transactionMapper) {
        this.memberMapper = memberMapper;
        this.transactionMapper = transactionMapper;
    }

    @Override
    public List<MemberVO> list() {
        return memberMapper.findAll().stream().map(this::toVO).collect(Collectors.toList());
    }

    @Override
    public PageResult<MemberVO> page(int pageNum, int pageSize, String keyword, String level) {
        pageNum = Math.max(pageNum, 1);
        pageSize = Math.min(Math.max(pageSize, 1), 100);
        int offset = (pageNum - 1) * pageSize;
        List<MemberVO> records = memberMapper.findPageVO(offset, pageSize, keyword, level);
        long total = memberMapper.countVO(keyword, level);
        return new PageResult<>(total, pageNum, pageSize, records);
    }

    @Override
    public MemberVO findById(Long id) {
        Member member = memberMapper.findById(id);
        if (member == null) {
            throw new BizException("会员不存在");
        }
        return toVO(member);
    }

    @Override
    @Transactional
    public MemberVO create(Member member) {
        if (member.getPhone() == null || !member.getPhone().matches("^1[3-9]\\d{9}$")) {
            throw new BizException("请输入正确的手机号");
        }
        if (memberMapper.findByPhone(member.getPhone()) != null) {
            throw new BizException("该手机号已注册为会员");
        }
        if (member.getPoints() == null) {
            member.setPoints(0);
        }
        if (member.getBalance() == null) {
            member.setBalance(BigDecimal.ZERO);
        }
        if (member.getLevel() == null) {
            member.setLevel("普通会员");
        }
        member.setCreateBy(SecurityUtil.getCurrentUsername());
        memberMapper.insert(member);
        return findById(member.getId());
    }

    @Override
    @Transactional
    public void update(Long id, Member member) {
        Member existing = memberMapper.findById(id);
        if (existing == null) {
            throw new BizException("会员不存在");
        }
        if (member.getPhone() != null && !member.getPhone().matches("^1[3-9]\\d{9}$")) {
            throw new BizException("请输入正确的手机号");
        }
        member.setId(id);
        // 部分更新：未传的字段回填已有值（phone 为 null 不得写 NULL）
        if (member.getPhone() == null) {
            member.setPhone(existing.getPhone());
        }
        if (member.getPoints() == null) {
            member.setPoints(existing.getPoints());
        }
        if (member.getBalance() == null) {
            member.setBalance(existing.getBalance());
        }
        if (member.getLevel() == null) {
            member.setLevel(existing.getLevel());
        }
        memberMapper.update(member);
    }

    @Override
    @Transactional
    public void delete(Long id) {
        if (memberMapper.findById(id) == null) {
            throw new BizException("会员不存在");
        }
        if (memberMapper.delete(id) == 0) {
            throw new BizException("会员删除失败，请刷新后重试");
        }
    }

    @Override
    @Transactional
    public void addPoints(Long memberId, Integer points) {
        if (points == null || points <= 0) {
            throw new BizException("积分数量必须大于0");
        }
        Member member = memberMapper.findById(memberId);
        if (member == null) {
            throw new BizException("会员不存在");
        }
        int current = member.getPoints() != null ? member.getPoints() : 0;
        member.setPoints(current + points);
        memberMapper.update(member);
        recordTransaction(member, "积分充值", new BigDecimal(points), "积分充值");
    }

    @Override
    @Transactional
    public void addBalance(Long memberId, BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new BizException("充值金额必须大于0");
        }
        Member member = memberMapper.findById(memberId);
        if (member == null) {
            throw new BizException("会员不存在");
        }
        BigDecimal current = member.getBalance() != null ? member.getBalance() : BigDecimal.ZERO;
        member.setBalance(current.add(amount));
        memberMapper.update(member);
        recordTransaction(member, "余额充值", amount, "余额充值");
    }

    @Override
    @Transactional
    public void consumeBalance(Long memberId, BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new BizException("消费金额必须大于0");
        }
        Member member = memberMapper.findById(memberId);
        if (member == null) {
            throw new BizException("会员不存在");
        }
        BigDecimal current = member.getBalance() != null ? member.getBalance() : BigDecimal.ZERO;
        if (current.compareTo(amount) < 0) {
            throw new BizException("余额不足，请更换支付方式");
        }
        member.setBalance(current.subtract(amount));
        int points = member.getPoints() != null ? member.getPoints() : 0;
        int earned = amount.intValue();
        member.setPoints(points + earned);
        memberMapper.update(member);
        recordTransaction(member, "余额消费", amount, "消费金额，获得" + earned + "积分");
    }

    @Override
    public List<MemberTransaction> getTransactions(Long memberId) {
        return transactionMapper.findByMemberId(memberId);
    }

    @Override
    public Member findByPhone(String phone) {
        return memberMapper.findByPhone(phone);
    }

    private void recordTransaction(Member member, String type, BigDecimal amount, String remark) {
        MemberTransaction tx = new MemberTransaction();
        tx.setMemberId(member.getId());
        tx.setType(type);
        tx.setAmount(amount);
        tx.setBalanceAfter(member.getBalance());
        tx.setPointsAfter(member.getPoints());
        tx.setRemark(remark);
        transactionMapper.insert(tx);
    }

    private MemberVO toVO(Member m) {
        MemberVO vo = new MemberVO();
        vo.setId(m.getId());
        vo.setName(m.getName());
        vo.setPhone(m.getPhone());
        vo.setLevel(m.getLevel());
        vo.setPoints(m.getPoints());
        vo.setBalance(m.getBalance());
        vo.setCreateTime(m.getCreateTime());
        return vo;
    }
}
