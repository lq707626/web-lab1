package com.hotel.pms.vo;

import lombok.Data;

import java.math.BigDecimal;

/**
 * 账单明细视图对象
 */
@Data
public class BillItemVO {
    private Long id;
    private String billNo;
    private String itemType;
    private BigDecimal amount;
    private Integer quantity;
    private String payMethod;
    private String itemTime;
}
