<template>
  <div>
    <el-card shadow="never">
      <div class="toolbar">
        <div class="filters">
          <el-input
            v-model="query.keyword"
            placeholder="按姓名 / 手机号查询会员"
            clearable
            style="width: 260px"
            :prefix-icon="Search"
            data-testid="member-keyword-input"
            @keyup.enter="search"
          />
          <el-select
            v-model="query.level"
            placeholder="全部等级"
            clearable
            style="width: 140px"
            data-testid="member-level-select"
          >
            <el-option v-for="level in levels" :key="level" :label="level" :value="level" />
          </el-select>
          <el-button type="primary" :loading="loading" data-testid="member-search-btn" @click="search">
            查询
          </el-button>
          <el-button :disabled="loading" data-testid="member-reset-btn" @click="resetQuery">重置</el-button>
        </div>
        <el-button type="primary" :icon="Plus" data-testid="member-add-btn" @click="openAdd">
          新增会员
        </el-button>
      </div>

      <el-table :data="list" border stripe v-loading="loading" empty-text="暂无会员数据" data-testid="member-table">
        <el-table-column prop="id" label="会员ID" width="90" />
        <el-table-column prop="name" label="姓名" width="110" />
        <el-table-column label="手机号" width="140">
          <template #default="{ row }">{{ maskPhone(row.phone) }}</template>
        </el-table-column>
        <el-table-column label="会员等级" width="120">
          <template #default="{ row }">
            <el-tag :type="MEMBER_LEVEL_TYPE[row.level] || 'info'" effect="dark">{{ row.level }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="points" label="积分" width="100" align="right" />
        <el-table-column label="储值余额" width="120" align="right">
          <template #default="{ row }">¥{{ money(row.balance) }}</template>
        </el-table-column>
        <el-table-column label="注册时间" width="160">
          <template #default="{ row }">{{ formatTime(row.createTime) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="400" fixed="right">
          <template #default="{ row }">
            <div class="row-actions" data-testid="member-row" :data-member-id="row.id">
              <el-button size="small" data-testid="member-edit-btn" @click="openEdit(row)">编辑</el-button>
              <el-button size="small" type="primary" plain data-testid="member-points-btn" @click="openPoints(row)">
                积分
              </el-button>
              <el-button size="small" type="success" plain data-testid="member-recharge-btn" @click="openRecharge(row)">
                充值
              </el-button>
              <el-button
                size="small"
                type="info"
                plain
                :loading="isPending(row, 'transactions')"
                data-testid="member-transactions-btn"
                @click="openTransactions(row)"
              >
                流水
              </el-button>
              <el-button
                size="small"
                type="danger"
                plain
                :loading="isPending(row, 'delete')"
                data-testid="member-delete-btn"
                @click="remove(row)"
              >
                删除
              </el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>

      <div class="pager">
        <el-pagination
          v-model:current-page="query.pageNum"
          v-model:page-size="query.pageSize"
          :total="total"
          :page-sizes="[5, 10, 20, 50]"
          layout="total, sizes, prev, pager, next, jumper"
          data-testid="member-pagination"
          @size-change="load"
          @current-change="load"
        />
      </div>
    </el-card>

    <!-- 新增会员：只负责新增 -->
    <el-dialog v-model="addVisible" title="新增会员" width="460px" data-testid="member-add-dialog" @closed="resetAddForm">
      <el-form ref="addFormRef" :model="addForm" :rules="addRules" label-width="90px">
        <el-form-item label="姓名" prop="name">
          <el-input v-model="addForm.name" maxlength="50" placeholder="请输入姓名" data-testid="member-add-name-input" />
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input v-model="addForm.phone" maxlength="11" placeholder="11 位手机号" data-testid="member-add-phone-input" />
        </el-form-item>
        <el-form-item label="会员等级" prop="level">
          <el-select v-model="addForm.level" style="width: 100%" data-testid="member-add-level-select">
            <el-option v-for="level in levels" :key="level" :label="level" :value="level" />
          </el-select>
        </el-form-item>
        <el-form-item label="初始余额">
          <el-input-number v-model="addForm.balance" :min="0" :precision="2" data-testid="member-add-balance-input" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button data-testid="member-add-cancel-btn" @click="addVisible = false">取消</el-button>
        <el-button type="primary" :loading="adding" data-testid="member-add-submit-btn" @click="submitAdd">
          新增
        </el-button>
      </template>
    </el-dialog>

    <!-- 编辑会员：只负责编辑 -->
    <el-dialog v-model="editVisible" title="编辑会员" width="460px" data-testid="member-edit-dialog" @closed="resetEditForm">
      <el-form ref="editFormRef" :model="editForm" :rules="editRules" label-width="90px">
        <el-form-item label="姓名" prop="name">
          <el-input v-model="editForm.name" maxlength="50" placeholder="请输入姓名" data-testid="member-edit-name-input" />
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input v-model="editForm.phone" maxlength="11" placeholder="11 位手机号" data-testid="member-edit-phone-input" />
        </el-form-item>
        <el-form-item label="会员等级" prop="level">
          <el-select v-model="editForm.level" style="width: 100%" data-testid="member-edit-level-select">
            <el-option v-for="level in levels" :key="level" :label="level" :value="level" />
          </el-select>
        </el-form-item>
        <el-form-item label="积分">
          <el-input-number v-model="editForm.points" :min="0" :precision="0" data-testid="member-edit-points-input" />
        </el-form-item>
        <el-form-item label="储值余额">
          <el-input-number v-model="editForm.balance" :min="0" :precision="2" data-testid="member-edit-balance-input" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button data-testid="member-edit-cancel-btn" @click="editVisible = false">取消</el-button>
        <el-button type="primary" :loading="editing" data-testid="member-edit-submit-btn" @click="submitEdit">
          保存修改
        </el-button>
      </template>
    </el-dialog>

    <!-- 积分充值 -->
    <el-dialog v-model="pointsVisible" title="积分充值" width="380px" data-testid="member-points-dialog">
      <p class="dialog-tip">
        <span data-testid="member-points-name">{{ currentMember?.name }}</span>
        当前积分：<span data-testid="member-points-current">{{ currentMember?.points }}</span>
      </p>
      <el-input-number v-model="pointsValue" :min="1" :precision="0" data-testid="member-points-input" />
      <template #footer>
        <el-button data-testid="member-points-cancel-btn" @click="pointsVisible = false">取消</el-button>
        <el-button type="primary" :loading="pointsSaving" data-testid="member-points-submit-btn" @click="submitPoints">
          确认充值
        </el-button>
      </template>
    </el-dialog>

    <!-- 余额充值 -->
    <el-dialog v-model="rechargeVisible" title="储值余额充值" width="400px" data-testid="member-recharge-dialog">
      <p class="dialog-tip">
        <span data-testid="member-recharge-name">{{ currentMember?.name }}</span>
        当前余额：<span data-testid="member-recharge-current">¥{{ money(currentMember?.balance) }}</span>
      </p>
      <el-input-number
        v-model="rechargeValue"
        :min="0.01"
        :precision="2"
        :step="100"
        data-testid="member-recharge-input"
      />
      <template #footer>
        <el-button data-testid="member-recharge-cancel-btn" @click="rechargeVisible = false">取消</el-button>
        <el-button type="primary" :loading="rechargeSaving" data-testid="member-recharge-submit-btn" @click="submitRecharge">
          确认充值
        </el-button>
      </template>
    </el-dialog>

    <!-- 会员流水 -->
    <el-dialog
      v-model="transactionsVisible"
      title="会员消费 / 积分流水"
      width="640px"
      data-testid="member-transactions-dialog"
    >
      <p class="dialog-tip" data-testid="member-transactions-title">
        {{ currentMember?.name }}（{{ maskPhone(currentMember?.phone) }}）
      </p>
      <el-table
        :data="transactions"
        border
        size="small"
        v-loading="transactionsLoading"
        empty-text="暂无流水记录"
        data-testid="member-transactions-table"
      >
        <el-table-column prop="type" label="类型" width="110" />
        <el-table-column label="变动金额" width="110">
          <template #default="{ row }">{{ money(row.amount) }}</template>
        </el-table-column>
        <el-table-column label="变动后余额" width="120">
          <template #default="{ row }">¥{{ money(row.balanceAfter) }}</template>
        </el-table-column>
        <el-table-column prop="pointsAfter" label="变动后积分" width="110" />
        <el-table-column prop="remark" label="备注" min-width="120" />
        <el-table-column label="时间" width="160">
          <template #default="{ row }">{{ formatTime(row.createTime) }}</template>
        </el-table-column>
      </el-table>
      <template #footer>
        <el-button data-testid="member-transactions-close-btn" @click="transactionsVisible = false">关闭</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Search } from '@element-plus/icons-vue'
import api from '../api'
import { MEMBER_LEVEL_TYPE, isValidPhone, maskPhone, money } from '../utils/format'
import { useRowAction } from '../utils/useRowAction'

const levels = ['普通会员', '银卡会员', '金卡会员', '钻石会员']

const list = ref([])
const total = ref(0)
const loading = ref(false)

const addVisible = ref(false)
const addFormRef = ref(null)
const adding = ref(false)

const editVisible = ref(false)
const editFormRef = ref(null)
const editing = ref(false)

const currentMember = ref(null)

const pointsVisible = ref(false)
const pointsValue = ref(100)
const pointsSaving = ref(false)

const rechargeVisible = ref(false)
const rechargeValue = ref(100)
const rechargeSaving = ref(false)

const transactionsVisible = ref(false)
const transactions = ref([])
const transactionsLoading = ref(false)

const { isPending, run } = useRowAction()

const query = reactive({ pageNum: 1, pageSize: 10, keyword: '', level: '' })

const addForm = reactive({ name: '', phone: '', level: '普通会员', balance: 0 })
const editForm = reactive({ id: null, name: '', phone: '', level: '普通会员', points: 0, balance: 0 })

function validatePhone(rule, value, callback) {
  if (!value) {
    callback(new Error('会员手机号不能为空'))
  } else if (!isValidPhone(value)) {
    callback(new Error('会员手机号格式不正确'))
  } else {
    callback()
  }
}

const addRules = {
  name: [{ required: true, message: '会员姓名不能为空', trigger: 'blur' }],
  phone: [{ required: true, validator: validatePhone, trigger: 'blur' }],
  level: [{ required: true, message: '请选择会员等级', trigger: 'change' }]
}

const editRules = {
  name: [{ required: true, message: '会员姓名不能为空', trigger: 'blur' }],
  phone: [{ required: true, validator: validatePhone, trigger: 'blur' }],
  level: [{ required: true, message: '请选择会员等级', trigger: 'change' }]
}

function formatTime(value) {
  if (!value) return '-'
  return String(value).replace('T', ' ').slice(0, 19)
}

async function load() {
  loading.value = true
  try {
    const res = await api.get('/members/page', {
      params: {
        pageNum: query.pageNum,
        pageSize: query.pageSize,
        keyword: query.keyword || undefined,
        level: query.level || undefined
      }
    })
    list.value = res.data.records || []
    total.value = res.data.total || 0
  } catch (e) {
    list.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

function search() {
  query.pageNum = 1
  load()
}

function resetQuery() {
  query.keyword = ''
  query.level = ''
  query.pageNum = 1
  load()
}

function resetAddForm() {
  addForm.name = ''
  addForm.phone = ''
  addForm.level = '普通会员'
  addForm.balance = 0
  addFormRef.value?.clearValidate()
}

function resetEditForm() {
  editForm.id = null
  editForm.name = ''
  editForm.phone = ''
  editForm.level = '普通会员'
  editForm.points = 0
  editForm.balance = 0
  editFormRef.value?.clearValidate()
}

function openAdd() {
  resetAddForm()
  addVisible.value = true
}

function openEdit(row) {
  editForm.id = row.id
  editForm.name = row.name
  editForm.phone = row.phone
  editForm.level = row.level
  editForm.points = row.points ?? 0
  editForm.balance = Number(row.balance ?? 0)
  editVisible.value = true
}

async function submitAdd() {
  if (!addFormRef.value) return
  try {
    await addFormRef.value.validate()
  } catch (e) {
    return
  }
  adding.value = true
  try {
    await api.post('/members', {
      name: addForm.name,
      phone: addForm.phone,
      level: addForm.level,
      points: 0,
      balance: addForm.balance
    })
    ElMessage.success('会员添加成功')
    addVisible.value = false
    await load()
  } finally {
    adding.value = false
  }
}

async function submitEdit() {
  if (!editFormRef.value) return
  try {
    await editFormRef.value.validate()
  } catch (e) {
    return
  }
  editing.value = true
  try {
    await api.put(`/members/${editForm.id}`, {
      name: editForm.name,
      phone: editForm.phone,
      level: editForm.level,
      points: editForm.points,
      balance: editForm.balance
    })
    ElMessage.success('会员信息已更新')
    editVisible.value = false
    await load()
  } finally {
    editing.value = false
  }
}

async function remove(row) {
  try {
    await ElMessageBox.confirm('确认删除该会员？删除后不可恢复。', '删除会员', { type: 'warning' })
  } catch (e) {
    return
  }
  await run(row, 'delete', async () => {
    await api.delete(`/members/${row.id}`)
    ElMessage.success('会员已删除')
    if (list.value.length === 1 && query.pageNum > 1) {
      query.pageNum -= 1
    }
    await load()
  })
}

function openPoints(row) {
  currentMember.value = row
  pointsValue.value = 100
  pointsVisible.value = true
}

async function submitPoints() {
  pointsSaving.value = true
  try {
    await api.put(`/members/${currentMember.value.id}/points`, { points: pointsValue.value })
    ElMessage.success('积分充值成功')
    pointsVisible.value = false
    await load()
  } finally {
    pointsSaving.value = false
  }
}

function openRecharge(row) {
  currentMember.value = row
  rechargeValue.value = 100
  rechargeVisible.value = true
}

async function submitRecharge() {
  rechargeSaving.value = true
  try {
    await api.put(`/members/${currentMember.value.id}/balance`, { amount: rechargeValue.value })
    ElMessage.success('余额充值成功')
    rechargeVisible.value = false
    await load()
  } finally {
    rechargeSaving.value = false
  }
}

async function openTransactions(row) {
  currentMember.value = row
  transactions.value = []
  transactionsVisible.value = true
  await run(row, 'transactions', async () => {
    transactionsLoading.value = true
    try {
      const res = await api.get(`/members/${row.id}/transactions`)
      transactions.value = res.data || []
    } finally {
      transactionsLoading.value = false
    }
  })
}

onMounted(load)
</script>

<style scoped>
.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  gap: 12px;
  flex-wrap: wrap;
}
.filters {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}
.row-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.row-actions :deep(.el-button + .el-button) {
  margin-left: 0;
}
.pager {
  display: flex;
  justify-content: flex-end;
  margin-top: 14px;
}
.dialog-tip {
  margin: 0 0 12px;
  color: #606266;
}
</style>