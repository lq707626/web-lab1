package com.hotel.pms.vo;

import com.hotel.pms.entity.Amenity;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * 房间视图对象：房间 + 房型 + 门锁（一对一） + 设施（多对多）
 */
@Data
public class RoomVO {
    private Long id;
    private String roomNumber;
    private Long roomTypeId;
    private Integer floor;
    private String roomStatus;
    private String remark;
    private Integer version;

    private String typeName;
    private String bedType;
    private BigDecimal basePrice;

    private String lockNo;
    private String lockStatus;

    private List<Amenity> amenities;
}
