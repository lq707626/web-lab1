package com.hotel.pms.entity;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 会员流水记录（积分、余额变动）
 */
@Data
public class MemberTransaction {
    private Long id;
    private Long memberId;
    private String type;        // 类型：积分充值、余额充值、余额消费、积分奖励
    private BigDecimal amount;  // 变动金额（积分也用数字表示）
    private BigDecimal balanceAfter; // 变动后余额
    private Integer pointsAfter;     // 变动后积分
    private String remark;
    private LocalDateTime createTime;
}
