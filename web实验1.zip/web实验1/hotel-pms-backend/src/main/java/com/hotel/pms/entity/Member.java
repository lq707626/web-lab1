package com.hotel.pms.entity;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class Member {
    private Long id;
    private String name;
    private String phone;
    private String level;
    private Integer points;
    private BigDecimal balance;
    private String createBy;
    private LocalDateTime createTime;
    private String updateBy;
    private LocalDateTime updateTime;
    private Integer isDeleted;
}
