package com.hotel.pms.modules.bill;

import com.hotel.pms.common.PageResult;
import com.hotel.pms.common.Result;
import com.hotel.pms.entity.Bill;
import com.hotel.pms.vo.BillVO;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bills")
public class BillController {

    private final BillService billService;

    public BillController(BillService billService) {
        this.billService = billService;
    }

    @GetMapping
    public Result<List<BillVO>> list() {
        return Result.success(billService.list());
    }

    /**
     * 条件分页：keyword（账单号/客人/房间号）、status
     */
    @GetMapping("/page")
    public Result<PageResult<BillVO>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String status) {
        return Result.success(billService.page(pageNum, pageSize, keyword, status));
    }

    @GetMapping("/{id}")
    public Result<BillVO> detail(@PathVariable Long id) {
        return Result.success(billService.detail(id));
    }

    /**
     * 入住单与账单 1:1 查询（用于退房后查看账单）
     */
    @GetMapping("/checkin/{checkinId}")
    public Result<BillVO> byCheckin(@PathVariable Long checkinId) {
        return Result.success(billService.findByCheckinId(checkinId));
    }

    @PostMapping
    public Result<BillVO> create(@RequestBody Bill bill) {
        return Result.success(billService.create(bill));
    }

    @PutMapping("/{id}/settle")
    public Result<?> settle(@PathVariable Long id,
                            @RequestBody(required = false) Map<String, Object> body) {
        BigDecimal actualAmount = null;
        if (body != null && body.get("actualAmount") != null) {
            actualAmount = new BigDecimal(body.get("actualAmount").toString());
        }
        billService.settle(id, actualAmount);
        return Result.success();
    }
}
