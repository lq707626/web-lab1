package com.hotel.pms.mapper;

import com.hotel.pms.entity.Checkin;
import com.hotel.pms.vo.CheckinVO;
import org.apache.ibatis.annotations.*;
import java.util.List;

public interface CheckinMapper {
    @Select("SELECT c.*, r.room_number FROM checkin c " +
            "LEFT JOIN room r ON c.room_id = r.id " +
            "WHERE c.is_deleted = 0 ORDER BY c.checkin_time DESC")
    List<Checkin> findAll();

    @Select("SELECT * FROM checkin WHERE id = #{id} AND is_deleted = 0")
    Checkin findById(@Param("id") Long id);

    @Select("SELECT * FROM checkin WHERE room_id = #{roomId} AND status = '在住' AND is_deleted = 0")
    Checkin findActiveByRoomId(@Param("roomId") Long roomId);

    @Insert("INSERT INTO checkin(checkin_no, reservation_id, room_id, guest_name, id_card, phone, " +
            "deposit, checkin_time, status, create_by) " +
            "VALUES(#{checkinNo}, #{reservationId}, #{roomId}, #{guestName}, #{idCard}, #{phone}, " +
            "#{deposit}, NOW(), '在住', #{createBy})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Checkin checkin);

    @Update("UPDATE checkin SET status = '已退房', checkout_time = NOW() WHERE id = #{id} AND is_deleted = 0")
    int checkout(@Param("id") Long id);

    /* ========== 以下方法由 CheckinMapper.xml 实现（条件分页 / 编辑 / 删除） ========== */

    List<CheckinVO> findPageVO(@Param("offset") int offset,
                               @Param("size") int size,
                               @Param("keyword") String keyword,
                               @Param("status") String status);

    long countVO(@Param("keyword") String keyword, @Param("status") String status);

    CheckinVO findVOById(@Param("id") Long id);

    int logicalDelete(@Param("id") Long id);

    /** 编辑入住信息（客人姓名、身份证、手机号、押金） */
    int updateInfo(Checkin checkin);
}
