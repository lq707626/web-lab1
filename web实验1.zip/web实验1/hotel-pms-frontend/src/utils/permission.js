/**
 * 角色与菜单权限（对应实验报告 2.1.2 角色权限表、4.3.8 权限管理）
 *
 * 系统管理员：全部菜单
 * 前台接待  ：房态、预订、入住、会员
 * 收银      ：账单结算、收银结算
 * 客房经理  ：房态、报表统计
 * 总经理    ：仅报表统计（无操作权限）
 */

export const ROLE_ADMIN = '系统管理员'
export const ROLE_FRONT = '前台接待'
export const ROLE_CASHIER = '收银'
export const ROLE_MANAGER = '客房经理'
export const ROLE_GENERAL = '总经理'

export const ALL_ROLES = [ROLE_ADMIN, ROLE_FRONT, ROLE_CASHIER, ROLE_MANAGER, ROLE_GENERAL]

/**
 * key 用于生成菜单的 data-testid：layout-menu-{key}
 * 命名与 testid-list.md 中登记的清单保持一致。
 */
export const MENUS = [
  { key: 'room', path: '/room', title: '房态管理', icon: 'House', roles: [ROLE_ADMIN, ROLE_FRONT, ROLE_MANAGER] },
  { key: 'reservation', path: '/reservation', title: '预订管理', icon: 'Calendar', roles: [ROLE_ADMIN, ROLE_FRONT] },
  { key: 'checkin', path: '/checkin', title: '入住管理', icon: 'User', roles: [ROLE_ADMIN, ROLE_FRONT] },
  { key: 'bill', path: '/bill', title: '账单结算', icon: 'Money', roles: [ROLE_ADMIN, ROLE_CASHIER] },
  { key: 'cashier', path: '/cashier', title: '收银结算', icon: 'Wallet', roles: [ROLE_ADMIN, ROLE_CASHIER] },
  { key: 'member', path: '/member', title: '会员管理', icon: 'Star', roles: [ROLE_ADMIN, ROLE_FRONT] },
  { key: 'statistics', path: '/statistics', title: '报表统计', icon: 'DataLine', roles: [ROLE_ADMIN, ROLE_MANAGER, ROLE_GENERAL] },
  { key: 'employee', path: '/employee', title: '员工管理', icon: 'UserFilled', roles: [ROLE_ADMIN] },
  { key: 'third-party', path: '/third-party', title: '第三方对接', icon: 'Connection', roles: [ROLE_ADMIN] }
]

export const HOME_PATH = '/room'

/** 当前角色可访问的菜单 */
export function menusForRole(role) {
  return MENUS.filter(menu => menu.roles.includes(role))
}

/** 当前角色的默认首页 */
export function firstPathForRole(role) {
  const menus = menusForRole(role)
  if (!menus.length) return '/login'
  return menus[0].path
}

/** 角色是否可访问某个路由 */
export function canAccess(role, path) {
  const menu = MENUS.find(item => item.path === path)
  if (!menu) return true
  return menu.roles.includes(role)
}

/** 角色中文说明，用于页面提示 */
export function roleDescription(role) {
  const map = {
    [ROLE_ADMIN]: '拥有全部菜单与操作权限',
    [ROLE_FRONT]: '预订、入住、房态、会员业务办理',
    [ROLE_CASHIER]: '账单收款、退款与收银日结',
    [ROLE_MANAGER]: '房态管理与报表查看',
    [ROLE_GENERAL]: '仅报表查看，无操作权限'
  }
  return map[role] || '未知角色'
}
