<template>
  <div>
    <el-card shadow="never">
      <div class="toolbar">
        <div class="filters">
          <el-input
            v-model="query.keyword"
            placeholder="按用户名 / 姓名查询"
            clearable
            style="width: 240px"
            :prefix-icon="Search"
            data-testid="employee-keyword-input"
            @keyup.enter="search"
          />
          <el-select
            v-model="query.role"
            placeholder="全部角色"
            clearable
            style="width: 150px"
            data-testid="employee-role-select"
          >
            <el-option v-for="role in roles" :key="role" :label="role" :value="role" />
          </el-select>
          <el-button type="primary" :loading="loading" data-testid="employee-search-btn" @click="search">
            查询
          </el-button>
          <el-button :disabled="loading" data-testid="employee-reset-btn" @click="resetQuery">重置</el-button>
        </div>
        <el-button type="primary" :icon="Plus" data-testid="employee-add-btn" @click="openAdd">
          新增员工
        </el-button>
      </div>

      <el-table
        :data="list"
        border
        stripe
        v-loading="loading"
        empty-text="暂无员工数据"
        data-testid="employee-table"
      >
        <el-table-column prop="username" label="用户名" width="160" />
        <el-table-column prop="name" label="姓名" width="150" />
        <el-table-column label="角色" width="150">
          <template #default="{ row }">
            <el-tag :type="row.role === '系统管理员' ? 'danger' : 'primary'" effect="plain">{{ row.role }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="100">
          <template #default>
            <el-tag type="success" size="small">启用</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="创建时间" width="180">
          <template #default="{ row }">{{ formatTime(row.createTime) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <div class="row-actions" data-testid="employee-row" :data-employee-id="row.id">
              <el-button size="small" data-testid="employee-edit-btn" @click="openEdit(row)">编辑</el-button>
              <el-button
                size="small"
                type="danger"
                plain
                :loading="isPending(row, 'disable')"
                data-testid="employee-disable-btn"
                @click="disable(row)"
              >
                禁用
              </el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>

      <div class="pager">
        <el-pagination
          v-model:current-page="query.pageNum"
          v-model:page-size="query.pageSize"
          :total="total"
          :page-sizes="[5, 10, 20, 50]"
          layout="total, sizes, prev, pager, next, jumper"
          data-testid="employee-pagination"
          @size-change="load"
          @current-change="load"
        />
      </div>
    </el-card>

    <!-- 新增员工：只负责新增 -->
    <el-dialog v-model="addVisible" title="新增员工" width="460px" data-testid="employee-add-dialog" @closed="resetAddForm">
      <el-form ref="addFormRef" :model="addForm" :rules="addRules" label-width="90px">
        <el-form-item label="用户名" prop="username">
          <el-input
            v-model="addForm.username"
            maxlength="50"
            placeholder="登录账号"
            data-testid="employee-add-username-input"
          />
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input
            v-model="addForm.password"
            type="password"
            show-password
            maxlength="50"
            placeholder="初始密码"
            data-testid="employee-add-password-input"
          />
        </el-form-item>
        <el-form-item label="姓名" prop="name">
          <el-input
            v-model="addForm.name"
            maxlength="50"
            placeholder="员工姓名"
            data-testid="employee-add-name-input"
          />
        </el-form-item>
        <el-form-item label="角色" prop="role">
          <el-select v-model="addForm.role" style="width: 100%" data-testid="employee-add-role-select">
            <el-option v-for="role in roles" :key="role" :label="role" :value="role" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button data-testid="employee-add-cancel-btn" @click="addVisible = false">取消</el-button>
        <el-button type="primary" :loading="adding" data-testid="employee-add-submit-btn" @click="submitAdd">
          新增
        </el-button>
      </template>
    </el-dialog>

    <!-- 编辑员工：只负责编辑 -->
    <el-dialog v-model="editVisible" title="编辑员工" width="460px" data-testid="employee-edit-dialog" @closed="resetEditForm">
      <el-form ref="editFormRef" :model="editForm" :rules="editRules" label-width="90px">
        <el-form-item label="用户名">
          <el-input
            :model-value="editForm.username"
            disabled
            data-testid="employee-edit-username-input"
          />
        </el-form-item>
        <el-form-item label="重置密码" prop="password">
          <el-input
            v-model="editForm.password"
            type="password"
            show-password
            maxlength="50"
            placeholder="不修改请留空"
            data-testid="employee-edit-password-input"
          />
        </el-form-item>
        <el-form-item label="姓名" prop="name">
          <el-input
            v-model="editForm.name"
            maxlength="50"
            placeholder="员工姓名"
            data-testid="employee-edit-name-input"
          />
        </el-form-item>
        <el-form-item label="角色" prop="role">
          <el-select v-model="editForm.role" style="width: 100%" data-testid="employee-edit-role-select">
            <el-option v-for="role in roles" :key="role" :label="role" :value="role" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button data-testid="employee-edit-cancel-btn" @click="editVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" data-testid="employee-edit-submit-btn" @click="submitEdit">
          保存修改
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Search } from '@element-plus/icons-vue'
import api from '../api'
import { ALL_ROLES } from '../utils/permission'
import { useRowAction } from '../utils/useRowAction'

const roles = ALL_ROLES
const list = ref([])
const total = ref(0)
const loading = ref(false)
const adding = ref(false)
const saving = ref(false)
const addVisible = ref(false)
const editVisible = ref(false)
const addFormRef = ref(null)
const editFormRef = ref(null)

const { isPending, run } = useRowAction()

const query = reactive({ pageNum: 1, pageSize: 10, keyword: '', role: '' })

const addForm = reactive({
  username: '',
  password: '',
  name: '',
  role: '前台接待'
})

const editForm = reactive({
  id: null,
  username: '',
  password: '',
  name: '',
  role: '前台接待'
})

const addRules = {
  username: [
    { required: true, message: '用户名不能为空', trigger: 'blur' },
    { min: 3, max: 50, message: '用户名长度 3-50 个字符', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '密码不能为空', trigger: 'blur' },
    { min: 6, message: '密码至少 6 位', trigger: 'blur' }
  ],
  name: [{ required: true, message: '员工姓名不能为空', trigger: 'blur' }],
  role: [{ required: true, message: '请选择角色', trigger: 'change' }]
}

const editRules = {
  password: [
    {
      validator: (rule, value, callback) => {
        if (value && value.length < 6) {
          callback(new Error('密码至少 6 位'))
        } else {
          callback()
        }
      },
      trigger: 'blur'
    }
  ],
  name: [{ required: true, message: '员工姓名不能为空', trigger: 'blur' }],
  role: [{ required: true, message: '请选择角色', trigger: 'change' }]
}

function formatTime(value) {
  if (!value) return '-'
  return String(value).replace('T', ' ').slice(0, 19)
}

async function load() {
  loading.value = true
  try {
    const res = await api.get('/employees/page', {
      params: {
        pageNum: query.pageNum,
        pageSize: query.pageSize,
        keyword: query.keyword || undefined,
        role: query.role || undefined
      }
    })
    list.value = res.data.records || []
    total.value = res.data.total || 0
  } catch (e) {
    list.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

function search() {
  query.pageNum = 1
  load()
}

function resetQuery() {
  query.keyword = ''
  query.role = ''
  query.pageNum = 1
  load()
}

function resetAddForm() {
  addForm.username = ''
  addForm.password = ''
  addForm.name = ''
  addForm.role = '前台接待'
  addFormRef.value?.clearValidate()
}

function resetEditForm() {
  editForm.id = null
  editForm.username = ''
  editForm.password = ''
  editForm.name = ''
  editForm.role = '前台接待'
  editFormRef.value?.clearValidate()
}

function openAdd() {
  resetAddForm()
  addVisible.value = true
}

function openEdit(row) {
  editForm.id = row.id
  editForm.username = row.username
  editForm.password = ''
  editForm.name = row.name
  editForm.role = row.role
  editVisible.value = true
}

async function submitAdd() {
  if (!addFormRef.value) return
  try {
    await addFormRef.value.validate()
  } catch (e) {
    return
  }
  adding.value = true
  try {
    await api.post('/employees', {
      username: addForm.username,
      password: addForm.password,
      name: addForm.name,
      role: addForm.role
    })
    ElMessage.success('员工添加成功')
    addVisible.value = false
    await load()
  } finally {
    adding.value = false
  }
}

async function submitEdit() {
  if (!editFormRef.value) return
  try {
    await editFormRef.value.validate()
  } catch (e) {
    return
  }
  saving.value = true
  try {
    await api.put(`/employees/${editForm.id}`, {
      name: editForm.name,
      role: editForm.role,
      password: editForm.password || null
    })
    ElMessage.success('员工信息已更新')
    editVisible.value = false
    await load()
  } finally {
    saving.value = false
  }
}

async function disable(row) {
  if (row.role === '系统管理员' && row.username === 'admin') {
    ElMessage.warning('默认管理员账号不允许禁用')
    return
  }
  try {
    await ElMessageBox.confirm('确认禁用该员工？禁用后该账号将无法登录系统。', '禁用员工', { type: 'warning' })
  } catch (e) {
    return
  }
  await run(row, 'disable', async () => {
    await api.delete(`/employees/${row.id}`)
    ElMessage.success('员工已禁用')
    if (list.value.length === 1 && query.pageNum > 1) {
      query.pageNum -= 1
    }
    await load()
  })
}

onMounted(load)
</script>

<style scoped>
.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  gap: 12px;
  flex-wrap: wrap;
}
.filters {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}
.row-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.row-actions :deep(.el-button + .el-button) {
  margin-left: 0;
}
.pager {
  display: flex;
  justify-content: flex-end;
  margin-top: 14px;
}
</style>