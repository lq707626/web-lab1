package com.hotel.pms.modules.roomtype;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hotel.pms.common.RedisService;
import com.hotel.pms.common.SecurityUtil;
import com.hotel.pms.entity.RoomType;
import com.hotel.pms.mapper.RoomTypeMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class RoomTypeServiceImpl implements RoomTypeService {

    private final RoomTypeMapper roomTypeMapper;
    private final RedisService redisService;
    private final ObjectMapper objectMapper;

    private static final String ROOM_TYPE_CACHE_KEY = "room:types";

    public RoomTypeServiceImpl(RoomTypeMapper roomTypeMapper,
                               RedisService redisService,
                               ObjectMapper objectMapper) {
        this.roomTypeMapper = roomTypeMapper;
        this.redisService = redisService;
        this.objectMapper = objectMapper;
    }

    @Override
    public List<RoomType> list() {
        String cacheJson = redisService.get(ROOM_TYPE_CACHE_KEY);
        if (cacheJson != null) {
            try {
                return objectMapper.readValue(cacheJson,
                    objectMapper.getTypeFactory().constructCollectionType(List.class, RoomType.class));
            } catch (Exception e) {
                // 忽略缓存异常，回源数据库
            }
        }

        List<RoomType> types = roomTypeMapper.findAll();
        try {
            redisService.set(ROOM_TYPE_CACHE_KEY, objectMapper.writeValueAsString(types),
                10, TimeUnit.MINUTES);
        } catch (Exception e) {
            // 缓存写入失败不影响主流程
        }
        return types;
    }

    @Override
    public RoomType findById(Long id) {
        return roomTypeMapper.findById(id);
    }

    @Override
    public RoomType create(RoomType roomType) {
        roomType.setCreateBy(SecurityUtil.getCurrentUsername());
        roomTypeMapper.insert(roomType);
        redisService.delete(ROOM_TYPE_CACHE_KEY);
        return roomType;
    }

    @Override
    public boolean update(Long id, RoomType roomType) {
        roomType.setId(id);
        int rows = roomTypeMapper.update(roomType);
        if (rows > 0) {
            redisService.delete(ROOM_TYPE_CACHE_KEY);
            return true;
        }
        return false;
    }

    @Override
    public boolean delete(Long id) {
        int rows = roomTypeMapper.delete(id);
        if (rows > 0) {
            redisService.delete(ROOM_TYPE_CACHE_KEY);
            return true;
        }
        return false;
    }
}
