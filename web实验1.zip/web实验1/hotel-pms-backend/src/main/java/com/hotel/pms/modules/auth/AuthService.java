package com.hotel.pms.modules.auth;

import java.util.Map;

/**
 * 登录认证服务（原 AuthController 中的业务逻辑下沉到 Service 层）
 */
public interface AuthService {

    /**
     * 员工登录
     *
     * @return token、username、name、role
     */
    Map<String, Object> login(String username, String password);

    /**
     * 注销登录（删除 Redis 会话）
     */
    void logout(String authorizationHeader);
}
