package com.hotel.pms.modules.roomtype;

import com.hotel.pms.common.Result;
import com.hotel.pms.entity.RoomType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/room-types")
public class RoomTypeController {

    private final RoomTypeService roomTypeService;

    public RoomTypeController(RoomTypeService roomTypeService) {
        this.roomTypeService = roomTypeService;
    }

    @GetMapping
    public Result<List<RoomType>> list() {
        return Result.success(roomTypeService.list());
    }

    @GetMapping("/{id}")
    public Result<RoomType> detail(@PathVariable Long id) {
        RoomType roomType = roomTypeService.findById(id);
        if (roomType == null) {
            return Result.error("房型不存在");
        }
        return Result.success(roomType);
    }

    @PostMapping
    public Result<?> create(@RequestBody RoomType roomType) {
        return Result.success(roomTypeService.create(roomType));
    }

    @PutMapping("/{id}")
    public Result<?> update(@PathVariable Long id, @RequestBody RoomType roomType) {
        if (!roomTypeService.update(id, roomType)) {
            return Result.error("房型不存在");
        }
        return Result.success();
    }

    @DeleteMapping("/{id}")
    public Result<?> delete(@PathVariable Long id) {
        if (!roomTypeService.delete(id)) {
            return Result.error("房型不存在");
        }
        return Result.success();
    }
}
