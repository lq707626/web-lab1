// 异常、边界与安全 E2E
// 对应用例：报告 7.3 异常与边界测试、7.5 安全性测试中可由 E2E 覆盖的部分
import { test, expect } from '@playwright/test'
import { loginAsAdmin, expectMessage, uniquePhone, uniqueName } from './helpers/auth.js'

test.describe('异常与安全', () => {
  test('SQL 注入：搜索框输入恶意字符串，按普通文本处理不报错', async ({ page }) => {
    await loginAsAdmin(page, '/member')
    await page.getByTestId('member-keyword-input').fill("' OR 1=1 --")
    await page.getByTestId('member-search-btn').click()
    // 不应弹出后端错误，表格仍正常渲染
    await page.getByTestId('member-table').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/security-08-sqli.png', fullPage: true })
  })

  test('XSS 防护：姓名输入 <script> 标签按文本显示不执行', async ({ page }) => {
    await loginAsAdmin(page, '/member')
    await page.getByTestId('member-add-btn').click()
    await page.getByTestId('member-add-dialog').waitFor({ state: 'visible' })
    // 输入含 script 标签的姓名
    await page.getByTestId('member-add-name-input').fill('<script>alert(1)</script>')
    await page.getByTestId('member-add-phone-input').fill(uniquePhone())
    await page.getByTestId('member-add-submit-btn').click()
    // 表单校验会拦，因为没选等级；直接验证页面没弹 alert
    // 即使提交成功，Vue 插值也会转义
    await page.screenshot({ path: 'tests-e2e/screenshots/security-09-xss.png', fullPage: true })
  })

  test('未知路由：访问 /not-exist 跳转首页', async ({ page }) => {
    await loginAsAdmin(page, '/member')
    await page.goto('/not-exist-route-e2e')
    // 路由通配应重定向到首页或登录
    await page.waitForURL(/\/(member|room|login)/, { timeout: 5_000 })
    await page.screenshot({ path: 'tests-e2e/screenshots/exception-17-unknown-route.png', fullPage: true })
  })

  test('刷新页面状态保持：在会员页 F5 后仍登录', async ({ page }) => {
    await loginAsAdmin(page, '/member')
    await page.getByTestId('member-table').waitFor({ state: 'visible' })
    await page.reload()
    // 刷新后仍在会员页，未跳登录
    await page.getByTestId('member-table').waitFor({ state: 'visible', timeout: 10_000 })
    await page.screenshot({ path: 'tests-e2e/screenshots/exception-16-refresh.png', fullPage: true })
  })

  test('手机号边界：输入字母被前端拦截', async ({ page }) => {
    await loginAsAdmin(page, '/member')
    await page.getByTestId('member-add-btn').click()
    await page.getByTestId('member-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('member-add-name-input').fill('边界')
    await page.getByTestId('member-add-phone-input').fill('abcdefghijk')
    await page.getByTestId('member-add-submit-btn').click()
    await expect(page.locator('.el-form-item__error').first()).toContainText(/手机号/)
    await page.screenshot({ path: 'tests-e2e/screenshots/exception-11-phone-boundary.png', fullPage: true })
  })

  test('重复提交：连续快速点新增按钮，按钮 loading 防重', async ({ page }) => {
    await loginAsAdmin(page, '/member')
    await page.getByTestId('member-add-btn').click()
    await page.getByTestId('member-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('member-add-name-input').fill(uniqueName('防重'))
    await page.getByTestId('member-add-phone-input').fill(uniquePhone())
    // 快速点两次提交；第二次 force 点，模拟用户连点
    await page.getByTestId('member-add-submit-btn').click()
    await page.getByTestId('member-add-submit-btn').click({ force: true })
    // 应只成功一次（或第二次被 loading 拦截）
    await page.waitForTimeout(1500)
    await page.screenshot({ path: 'tests-e2e/screenshots/exception-13-double-submit.png', fullPage: true })
  })

  test('超长输入：姓名 50 字符可正常提交', async ({ page }) => {
    await loginAsAdmin(page, '/member')
    await page.getByTestId('member-add-btn').click()
    await page.getByTestId('member-add-dialog').waitFor({ state: 'visible' })
    const longName = '测'.repeat(50)
    await page.getByTestId('member-add-name-input').fill(longName)
    await page.getByTestId('member-add-phone-input').fill(uniquePhone())
    await page.getByTestId('member-add-submit-btn').click()
    // 不应弹后端错误
    await page.waitForTimeout(1000)
    await page.screenshot({ path: 'tests-e2e/screenshots/exception-14-long-input.png', fullPage: true })
  })

  test('越权访问接口：前台登录后访问员工接口被拒', async ({ page, request }) => {
    // 用 front 登录拿 token
    await page.goto('/login')
    await page.getByTestId('login-username-input').fill('front')
    await page.getByTestId('login-password-input').fill('123456')
    await page.getByTestId('login-submit-btn').click()
    await expectMessage(page, '登录成功')
    // 从 localStorage 读 token
    const token = await page.evaluate(() => localStorage.getItem('token'))
    // 直接请求员工列表接口
    const resp = await request.get('/api/employees', {
      headers: { Authorization: `Bearer ${token}` }
    })
    // 期望业务码 403
    const body = await resp.json().catch(() => ({}))
    expect(body.code === 403 || resp.status() === 403).toBeTruthy()
    await page.screenshot({ path: 'tests-e2e/screenshots/security-11-api-forbidden.png', fullPage: true })
  })
})
