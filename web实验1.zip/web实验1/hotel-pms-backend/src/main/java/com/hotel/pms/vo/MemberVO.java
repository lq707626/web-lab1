package com.hotel.pms.vo;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 会员视图对象（不返回审计/软删除等内部字段）
 */
@Data
public class MemberVO {
    private Long id;
    private String name;
    private String phone;
    private String level;
    private Integer points;
    private BigDecimal balance;
    private LocalDateTime createTime;
}
