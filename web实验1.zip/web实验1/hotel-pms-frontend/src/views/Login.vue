<template>
  <div class="login-container">
    <el-card class="login-card">
      <h2 class="login-title">酒店 PMS 管理系统</h2>
      <p class="login-sub">员工登录 · 角色权限控制</p>

      <el-form ref="formRef" :model="form" :rules="rules" label-position="top" @submit.prevent>
        <el-form-item label="用户名" prop="username">
          <el-input
            v-model="form.username"
            prefix-icon="User"
            placeholder="请输入用户名"
            size="large"
            clearable
            data-testid="login-username-input"
          />
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input
            v-model="form.password"
            prefix-icon="Lock"
            type="password"
            placeholder="请输入密码"
            size="large"
            show-password
            data-testid="login-password-input"
            @keyup.enter="handleLogin"
          />
        </el-form-item>
        <el-button
          type="primary"
          size="large"
          class="login-btn"
          :loading="loading"
          data-testid="login-submit-btn"
          @click="handleLogin"
        >
          登 录
        </el-button>
      </el-form>

      <div class="login-footer">
        <el-button link type="primary" data-testid="login-guest-btn" @click="goGuest">
          游客在线预订入口 &gt;
        </el-button>
      </div>
      <p class="login-tip">
        测试账号：admin（管理员）、front（前台）、cashier（收银）、manager（客房经理）、gm（总经理），密码均为 123456
      </p>
    </el-card>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import api from '../api'
import { useUserStore } from '../store/user'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const formRef = ref(null)
const loading = ref(false)
const form = reactive({ username: '', password: '' })

const rules = {
  username: [{ required: true, message: '用户名不能为空', trigger: 'blur' }],
  password: [{ required: true, message: '密码不能为空', trigger: 'blur' }]
}

function goGuest() {
  router.push('/guest')
}

async function handleLogin() {
  if (!formRef.value) return
  try {
    await formRef.value.validate()
  } catch (e) {
    // 前端校验未通过，不发起请求
    return
  }

  loading.value = true
  try {
    const res = await api.post('/auth/login', {
      username: form.username.trim(),
      password: form.password
    })
    userStore.setLogin(res.data)
    // 固定文案 + 数据单独渲染，避免把断言文本拼成动态字符串
    ElMessage.success('登录成功')
    const redirect = route.query.redirect
    if (redirect && typeof redirect === 'string') {
      router.push(redirect)
    } else {
      router.push(userStore.homePath)
    }
  } catch (e) {
    // 错误提示已由 Axios 响应拦截器统一弹出
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.login-container {
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}
.login-card {
  width: 420px;
  padding: 8px 12px 0;
  border-radius: 10px;
}
.login-title {
  text-align: center;
  margin: 4px 0 4px;
  color: #303133;
}
.login-sub {
  text-align: center;
  color: #909399;
  font-size: 13px;
  margin: 0 0 18px;
}
.login-btn {
  width: 100%;
  margin-top: 4px;
}
.login-footer {
  text-align: center;
  margin-top: 6px;
}
.login-tip {
  color: #a8abb2;
  font-size: 12px;
  line-height: 1.6;
  text-align: center;
  margin: 10px 0 4px;
}
</style>