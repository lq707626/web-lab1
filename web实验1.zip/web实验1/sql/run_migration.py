# -*- coding: utf-8 -*-
"""执行增量迁移脚本（可重复运行，失败语句会打印但不中断后续语句）"""
import os
import pymysql

HOST = 'your-vm-ip'
PORT = 3306
USER = 'root'
PASSWORD = 'root'
DATABASE = 'mydb'

sql_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'migrate_20261031.sql')

with open(sql_path, 'r', encoding='utf-8') as f:
    content = f.read()

lines = []
for line in content.split('\n'):
    if line.strip().startswith('--'):
        continue
    lines.append(line)
sql = '\n'.join(lines)

statements = [s.strip() for s in sql.split(';') if s.strip()]
print(f'共 {len(statements)} 条 SQL 语句')

conn = pymysql.connect(host=HOST, port=PORT, user=USER, password=PASSWORD,
                       database=DATABASE, charset='utf8mb4', autocommit=True)
cursor = conn.cursor()

failed = 0
for i, stmt in enumerate(statements):
    try:
        cursor.execute(stmt)
        print(f'  [{i + 1}] OK: {stmt[:70].replace(chr(10), " ")}...')
    except Exception as e:
        failed += 1
        print(f'  [{i + 1}] FAIL: {e}')

conn.commit()
cursor.execute('SHOW TABLES')
tables = [t[0] for t in cursor.fetchall()]
print(f'\nmydb 现有 {len(tables)} 张表: {", ".join(tables)}')

for table in ['employee', 'room', 'reservation', 'bill', 'payment', 'member_transaction']:
    try:
        cursor.execute(f'SELECT COUNT(*) FROM {table}')
        print(f'  {table}: {cursor.fetchone()[0]} 条记录')
    except Exception:
        print(f'  {table}: 不存在')

conn.close()
print(f'\n迁移完成，失败语句 {failed} 条')
