// 账单结算模块 E2E
// 对应用例：报告 7.2.5 退房与账单结算模块测试
import { test, expect } from '@playwright/test'
import { loginAsAdmin, expectMessage, confirmMessageBox } from './helpers/auth.js'

test.describe('账单结算', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page, '/bill')
  })

  test('账单列表渲染：表格、表头字段可见', async ({ page }) => {
    await page.getByTestId('bill-table').waitFor({ state: 'visible' })
    await expect(page.getByTestId('bill-table')).toContainText(/账单号|应收|结算状态/)
    await page.screenshot({ path: 'tests-e2e/screenshots/bill-01-list.png', fullPage: true })
  })

  test('账单详情：点击明细弹出对话框，展示明细合计', async ({ page }) => {
    await page.getByTestId('bill-table').waitFor({ state: 'visible' })
    const rows = page.getByTestId('bill-row')
    if ((await rows.count()) === 0) {
      test.info().annotations.push({ type: 'skip', description: '当前无账单数据' })
      return
    }
    await rows.first().getByTestId('bill-detail-btn').click()
    await page.getByTestId('bill-detail-dialog').waitFor({ state: 'visible' })
    await expect(page.getByTestId('bill-detail-dialog')).toContainText('明细合计')
    await expect(page.getByTestId('bill-detail-items-table')).toBeVisible()
    await page.screenshot({ path: 'tests-e2e/screenshots/bill-05-detail.png', fullPage: true })
    await page.getByTestId('bill-detail-close-btn').click()
  })

  test('结算未结算账单：弹确认框，确认后状态变已结算', async ({ page }) => {
    await page.getByTestId('bill-table').waitFor({ state: 'visible' })
    // 找第一行带结算按钮的
    const rows = page.getByTestId('bill-row')
    const n = await rows.count()
    let settled = false
    for (let i = 0; i < n; i++) {
      const row = rows.nth(i)
      const settleBtn = row.getByTestId('bill-settle-btn')
      if (await settleBtn.count()) {
        await settleBtn.click()
        await confirmMessageBox(page)
        await expectMessage(page, '结算成功')
        settled = true
        break
      }
    }
    if (!settled) {
      test.info().annotations.push({ type: 'skip', description: '当前无未结算账单' })
    }
    await page.screenshot({ path: 'tests-e2e/screenshots/bill-06-settle.png', fullPage: true })
  })

  test('已结算账单不显示结算按钮', async ({ page }) => {
    await page.getByTestId('bill-status-select').click()
    const dropdown = page.locator('.el-select-dropdown:visible').last()
    await dropdown.waitFor({ state: 'visible' })
    await dropdown.locator('.el-select-dropdown__item', { hasText: '已结算' }).first().click()

    await page.getByTestId('bill-table').waitFor({ state: 'visible' })
    const rows = page.getByTestId('bill-row')
    if ((await rows.count()) === 0) {
      test.info().annotations.push({ type: 'skip', description: '当前无已结算账单' })
      return
    }
    // 已结算行不应有结算按钮
    await expect(rows.first().getByTestId('bill-settle-btn')).toHaveCount(0)
    await page.screenshot({ path: 'tests-e2e/screenshots/bill-07-settled-no-settle.png', fullPage: true })
  })

  test('条件查询：输入不存在的关键字，列表为空', async ({ page }) => {
    await page.getByTestId('bill-keyword-input').fill('BILL-NOT-EXIST-E2E')
    // bill 页面是前端过滤，不需要点查询
    await page.waitForTimeout(500)
    await page.getByTestId('bill-table').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/bill-10-empty.png', fullPage: true })
  })

  test('状态筛选：选"已退款"后只显示已退款', async ({ page }) => {
    await page.getByTestId('bill-status-select').click()
    const dropdown = page.locator('.el-select-dropdown:visible').last()
    await dropdown.waitFor({ state: 'visible' })
    await dropdown.locator('.el-select-dropdown__item', { hasText: '已退款' }).first().click()
    await page.waitForTimeout(500)
    await page.getByTestId('bill-table').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/bill-status-refund.png', fullPage: true })
  })
})
