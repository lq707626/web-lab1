// 入住管理模块 E2E
// 对应用例：报告 7.2.4 入住管理模块测试
import { test, expect } from '@playwright/test'
import {
  loginAsAdmin,
  expectMessage,
  confirmMessageBox,
  uniquePhone,
  uniqueName
} from './helpers/auth.js'

// 合法测试身份证号（不关联真实人员）
const TEST_ID_CARD = '610113199001011234'

test.describe('入住管理', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page, '/checkin')
  })

  test('散客办理入住：选空房、填姓名/身份证/手机号/押金后提交', async ({ page }) => {
    const phone = uniquePhone()
    const name = uniqueName('E2E入住')

    await page.getByTestId('checkin-add-btn').click()
    await page.getByTestId('checkin-add-dialog').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/checkin-01-add-dialog.png', fullPage: true })

    // 房间下拉：选第一个"空房"选项（选项文本含"空房"）
    await page.getByTestId('checkin-add-room-select').click()
    const roomDropdown = page.locator('.el-select-dropdown:visible').last()
    await roomDropdown.waitFor({ state: 'visible' })
    await roomDropdown.locator('.el-select-dropdown__item', { hasText: '空房' }).first().click()

    await page.getByTestId('checkin-add-name-input').fill(name)
    await page.getByTestId('checkin-add-idcard-input').fill(TEST_ID_CARD)
    await page.getByTestId('checkin-add-phone-input').fill(phone)
    await page.getByTestId('checkin-add-deposit-input').locator('input').fill('100')

    await page.getByTestId('checkin-add-submit-btn').click()
    await expectMessage(page, '入住成功')

    // 搜出来确认
    await page.getByTestId('checkin-keyword-input').fill(phone)
    await page.getByTestId('checkin-search-btn').click()
    await page.getByTestId('checkin-row').first().waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/checkin-01-checkin-success.png', fullPage: true })
  })

  test('身份证号格式错误时前端校验拦截', async ({ page }) => {
    await page.getByTestId('checkin-add-btn').click()
    await page.getByTestId('checkin-add-dialog').waitFor({ state: 'visible' })

    await page.getByTestId('checkin-add-room-select').click()
    const roomDropdown = page.locator('.el-select-dropdown:visible').last()
    await roomDropdown.waitFor({ state: 'visible' })
    await roomDropdown.locator('.el-select-dropdown__item', { hasText: '空房' }).first().click()

    await page.getByTestId('checkin-add-name-input').fill('身份证校验')
    await page.getByTestId('checkin-add-idcard-input').fill('12345') // 非法身份证
    await page.getByTestId('checkin-add-phone-input').fill(uniquePhone())
    await page.getByTestId('checkin-add-deposit-input').locator('input').fill('100')
    await page.getByTestId('checkin-add-submit-btn').click()

    await expect(page.locator('.el-form-item__error').first()).toContainText(/身份证/)
    await page.getByTestId('checkin-add-dialog').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/checkin-02-idcard-invalid.png', fullPage: true })
  })

  test('押金为 0 时提示错误', async ({ page }) => {
    await page.getByTestId('checkin-add-btn').click()
    await page.getByTestId('checkin-add-dialog').waitFor({ state: 'visible' })

    await page.getByTestId('checkin-add-room-select').click()
    const roomDropdown = page.locator('.el-select-dropdown:visible').last()
    await roomDropdown.waitFor({ state: 'visible' })
    await roomDropdown.locator('.el-select-dropdown__item', { hasText: '空房' }).first().click()

    await page.getByTestId('checkin-add-name-input').fill('押金校验')
    await page.getByTestId('checkin-add-idcard-input').fill(TEST_ID_CARD)
    await page.getByTestId('checkin-add-phone-input').fill(uniquePhone())
    await page.getByTestId('checkin-add-deposit-input').locator('input').fill('0')
    await page.getByTestId('checkin-add-submit-btn').click()

    // 押金必须大于 0（表单内联校验，不是全局 toast）
    const err = page.locator('.el-form-item__error').last()
    await err.waitFor({ state: 'visible', timeout: 8_000 })
    await expect(err).toContainText(/押金/)
  })

  test('编辑入住信息：修改姓名后保存', async ({ page }) => {
    const phone = uniquePhone()
    await page.getByTestId('checkin-add-btn').click()
    await page.getByTestId('checkin-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('checkin-add-room-select').click()
    const roomDropdown = page.locator('.el-select-dropdown:visible').last()
    await roomDropdown.waitFor({ state: 'visible' })
    await roomDropdown.locator('.el-select-dropdown__item', { hasText: '空房' }).first().click()
    await page.getByTestId('checkin-add-name-input').fill(uniqueName('待编辑'))
    await page.getByTestId('checkin-add-idcard-input').fill(TEST_ID_CARD)
    await page.getByTestId('checkin-add-phone-input').fill(phone)
    await page.getByTestId('checkin-add-deposit-input').locator('input').fill('100')
    await page.getByTestId('checkin-add-submit-btn').click()
    await expectMessage(page, '入住成功')

    await page.getByTestId('checkin-keyword-input').fill(phone)
    await page.getByTestId('checkin-search-btn').click()
    await page.getByTestId('checkin-row').first().waitFor({ state: 'visible' })
    await page.getByTestId('checkin-row').first().getByTestId('checkin-edit-btn').click()

    await page.getByTestId('checkin-edit-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('checkin-edit-name-input').fill(uniqueName('已编辑'))
    await page.screenshot({ path: 'tests-e2e/screenshots/checkin-03-edit-dialog.png', fullPage: true })
    await page.getByTestId('checkin-edit-submit-btn').click()

    await expectMessage(page, '入住信息已更新')
    await page.screenshot({ path: 'tests-e2e/screenshots/checkin-03-edit-success.png', fullPage: true })
  })

  test('退房：在住记录点退房，确认后提示成功', async ({ page }) => {
    const phone = uniquePhone()
    await page.getByTestId('checkin-add-btn').click()
    await page.getByTestId('checkin-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('checkin-add-room-select').click()
    const roomDropdown = page.locator('.el-select-dropdown:visible').last()
    await roomDropdown.waitFor({ state: 'visible' })
    await roomDropdown.locator('.el-select-dropdown__item', { hasText: '空房' }).first().click()
    await page.getByTestId('checkin-add-name-input').fill(uniqueName('待退房'))
    await page.getByTestId('checkin-add-idcard-input').fill(TEST_ID_CARD)
    await page.getByTestId('checkin-add-phone-input').fill(phone)
    await page.getByTestId('checkin-add-deposit-input').locator('input').fill('100')
    await page.getByTestId('checkin-add-submit-btn').click()
    await expectMessage(page, '入住成功')

    await page.getByTestId('checkin-keyword-input').fill(phone)
    await page.getByTestId('checkin-search-btn').click()
    await page.getByTestId('checkin-row').first().waitFor({ state: 'visible' })
    await page.getByTestId('checkin-row').first().getByTestId('checkin-checkout-btn').click()

    await page.getByTestId('checkin-checkout-dialog').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/checkin-04-checkout-dialog.png', fullPage: true })
    await page.getByTestId('checkin-checkout-confirm-btn').click()

    await expectMessage(page, '退房成功')
    await page.screenshot({ path: 'tests-e2e/screenshots/checkin-04-checkout-success.png', fullPage: true })
  })

  test('删除已退房记录：弹确认框后删除', async ({ page }) => {
    // 先造一条入住
    const phone = uniquePhone()
    await page.getByTestId('checkin-add-btn').click()
    await page.getByTestId('checkin-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('checkin-add-room-select').click()
    const roomDropdown = page.locator('.el-select-dropdown:visible').last()
    await roomDropdown.waitFor({ state: 'visible' })
    await roomDropdown.locator('.el-select-dropdown__item', { hasText: '空房' }).first().click()
    await page.getByTestId('checkin-add-name-input').fill(uniqueName('待删'))
    await page.getByTestId('checkin-add-idcard-input').fill(TEST_ID_CARD)
    await page.getByTestId('checkin-add-phone-input').fill(phone)
    await page.getByTestId('checkin-add-deposit-input').locator('input').fill('100')
    await page.getByTestId('checkin-add-submit-btn').click()
    await expectMessage(page, '入住成功')

    // 退房
    await page.getByTestId('checkin-keyword-input').fill(phone)
    await page.getByTestId('checkin-search-btn').click()
    await page.getByTestId('checkin-row').first().waitFor({ state: 'visible' })
    await page.getByTestId('checkin-row').first().getByTestId('checkin-checkout-btn').click()
    await page.getByTestId('checkin-checkout-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('checkin-checkout-confirm-btn').click()
    await expectMessage(page, '退房成功')

    // 切到已退房状态筛选，找到刚退的记录
    await selectStatusFilter(page, '已退房')
    await page.getByTestId('checkin-keyword-input').fill(phone)
    await page.getByTestId('checkin-search-btn').click()
    await page.getByTestId('checkin-row').first().waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/checkin-05-before-delete.png', fullPage: true })
    await page.getByTestId('checkin-row').first().getByTestId('checkin-delete-btn').click()

    await confirmMessageBox(page)
    await expectMessage(page, '入住记录已删除')
    await page.screenshot({ path: 'tests-e2e/screenshots/checkin-05-after-delete.png', fullPage: true })
  })

  test('列表脱敏：手机号与身份证列显示 ****', async ({ page }) => {
    await page.getByTestId('checkin-table').waitFor({ state: 'visible' })
    const rows = page.locator('tr:has([data-testid="checkin-row"])')
    if ((await rows.count()) === 0) {
      test.info().annotations.push({ type: 'skip', description: '无入住记录' })
      return
    }
    // 手机号列应有 ****
    await expect(rows.first()).toContainText('****')
    await page.screenshot({ path: 'tests-e2e/screenshots/checkin-08-mask.png', fullPage: true })
  })

  test('状态筛选：选"已退房"只显示已退房记录', async ({ page }) => {
    await page.getByTestId('checkin-status-select').click()
    const dropdown = page.locator('.el-select-dropdown:visible').last()
    await dropdown.waitFor({ state: 'visible' })
    await dropdown.locator('.el-select-dropdown__item', { hasText: '已退房' }).first().click()
    await page.getByTestId('checkin-search-btn').click()
    await page.getByTestId('checkin-table').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/checkin-12-status-filter.png', fullPage: true })
  })

  test('分页器可见', async ({ page }) => {
    await page.getByTestId('checkin-pagination').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/checkin-13-pagination.png', fullPage: true })
  })

  test('空列表：查询不存在的客人显示空表格', async ({ page }) => {
    await page.getByTestId('checkin-keyword-input').fill('NOT-EXIST-E2E')
    await page.getByTestId('checkin-search-btn').click()
    await page.getByTestId('checkin-table').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/checkin-11-empty.png', fullPage: true })
  })
})

async function selectStatusFilter(page, label) {
  await page.getByTestId('checkin-status-select').click()
  const dropdown = page.locator('.el-select-dropdown:visible').last()
  await dropdown.waitFor({ state: 'visible' })
  await dropdown.locator('.el-select-dropdown__item', { hasText: label }).first().click()
}
