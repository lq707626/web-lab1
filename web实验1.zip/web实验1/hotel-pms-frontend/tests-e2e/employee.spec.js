// 员工管理模块 E2E
// 对应用例：报告 7.2.9 系统管理与权限测试
import { test, expect } from '@playwright/test'
import {
  loginAsAdmin,
  expectMessage,
  confirmMessageBox,
  selectOption,
  uniqueUsername,
  uniqueName
} from './helpers/auth.js'

test.describe('员工管理', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page, '/employee')
  })

  test('新增员工：填写用户名/密码/姓名/角色后保存成功', async ({ page }) => {
    const username = uniqueUsername('e2e')
    const name = uniqueName('E2E员工')

    await page.getByTestId('employee-add-btn').click()
    await page.getByTestId('employee-add-dialog').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/employee-01-add-dialog.png', fullPage: true })

    await page.getByTestId('employee-add-username-input').fill(username)
    await page.getByTestId('employee-add-password-input').fill('123456')
    await page.getByTestId('employee-add-name-input').fill(name)
    await selectOption(page, 'employee-add-role-select', '前台接待')

    await page.getByTestId('employee-add-submit-btn').click()
    await expectMessage(page, '员工添加成功')

    // 搜出来确认
    await page.getByTestId('employee-keyword-input').fill(username)
    await page.getByTestId('employee-search-btn').click()
    await page.getByTestId('employee-row').first().waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/employee-01-add-success.png', fullPage: true })
  })

  test('用户名重复时提示"用户名已存在"，不新增', async ({ page }) => {
    // 先造一个员工
    const username = uniqueUsername('dup')
    await page.getByTestId('employee-add-btn').click()
    await page.getByTestId('employee-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('employee-add-username-input').fill(username)
    await page.getByTestId('employee-add-password-input').fill('123456')
    await page.getByTestId('employee-add-name-input').fill(uniqueName('重复'))
    await selectOption(page, 'employee-add-role-select', '前台接待')
    await page.getByTestId('employee-add-submit-btn').click()
    await expectMessage(page, '员工添加成功')
    await page.getByTestId('employee-add-cancel-btn').click().catch(() => {})

    // 再次用同名新增
    await page.getByTestId('employee-add-btn').click()
    await page.getByTestId('employee-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('employee-add-username-input').fill(username)
    await page.getByTestId('employee-add-password-input').fill('123456')
    await page.getByTestId('employee-add-name-input').fill(uniqueName('重复2'))
    await selectOption(page, 'employee-add-role-select', '前台接待')
    await page.getByTestId('employee-add-submit-btn').click()

    const err = page.locator('.el-message--error').last()
    await err.waitFor({ state: 'visible', timeout: 8_000 })
    await expect(err).toContainText(/用户名已存在/)
    await page.screenshot({ path: 'tests-e2e/screenshots/employee-02-duplicate-username.png', fullPage: true })
  })

  test('编辑员工：修改姓名后保存', async ({ page }) => {
    const username = uniqueUsername('edit')
    const name = uniqueName('原')
    await page.getByTestId('employee-add-btn').click()
    await page.getByTestId('employee-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('employee-add-username-input').fill(username)
    await page.getByTestId('employee-add-password-input').fill('123456')
    await page.getByTestId('employee-add-name-input').fill(name)
    await selectOption(page, 'employee-add-role-select', '前台接待')
    await page.getByTestId('employee-add-submit-btn').click()
    await expectMessage(page, '员工添加成功')

    await page.getByTestId('employee-keyword-input').fill(username)
    await page.getByTestId('employee-search-btn').click()
    await page.getByTestId('employee-row').first().waitFor({ state: 'visible' })
    await page.getByTestId('employee-row').first().getByTestId('employee-edit-btn').click()

    await page.getByTestId('employee-edit-dialog').waitFor({ state: 'visible' })
    const newName = uniqueName('改后')
    await page.getByTestId('employee-edit-name-input').fill(newName)
    await page.screenshot({ path: 'tests-e2e/screenshots/employee-03-edit-dialog.png', fullPage: true })
    await page.getByTestId('employee-edit-submit-btn').click()

    await expectMessage(page, '员工信息已更新')
    await page.screenshot({ path: 'tests-e2e/screenshots/employee-03-edit-success.png', fullPage: true })
  })

  test('禁用员工：弹确认框，确认后提示成功', async ({ page }) => {
    const username = uniqueUsername('off')
    await page.getByTestId('employee-add-btn').click()
    await page.getByTestId('employee-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('employee-add-username-input').fill(username)
    await page.getByTestId('employee-add-password-input').fill('123456')
    await page.getByTestId('employee-add-name-input').fill(uniqueName('禁用'))
    await selectOption(page, 'employee-add-role-select', '前台接待')
    await page.getByTestId('employee-add-submit-btn').click()
    await expectMessage(page, '员工添加成功')

    await page.getByTestId('employee-keyword-input').fill(username)
    await page.getByTestId('employee-search-btn').click()
    await page.getByTestId('employee-row').first().waitFor({ state: 'visible' })
    await page.getByTestId('employee-row').first().getByTestId('employee-disable-btn').click()

    await confirmMessageBox(page)
    await expectMessage(page, '员工已禁用')
    await page.screenshot({ path: 'tests-e2e/screenshots/employee-04-disable-success.png', fullPage: true })
  })

  test('条件查询：按用户名搜索能过滤出匹配记录', async ({ page }) => {
    const username = uniqueUsername('q')
    await page.getByTestId('employee-add-btn').click()
    await page.getByTestId('employee-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('employee-add-username-input').fill(username)
    await page.getByTestId('employee-add-password-input').fill('123456')
    await page.getByTestId('employee-add-name-input').fill(uniqueName('查询'))
    await selectOption(page, 'employee-add-role-select', '前台接待')
    await page.getByTestId('employee-add-submit-btn').click()
    await expectMessage(page, '员工添加成功')

    await page.getByTestId('employee-keyword-input').fill(username)
    await page.getByTestId('employee-search-btn').click()
    await page.getByTestId('employee-row').first().waitFor({ state: 'visible' })
    // 列表里至少有一行，且包含刚造的用户名
    await expect(page.locator('tr:has([data-testid="employee-row"])').first()).toContainText(username)
    await page.screenshot({ path: 'tests-e2e/screenshots/employee-05-search.png', fullPage: true })
  })

  test('重置密码：编辑员工填新密码保存', async ({ page }) => {
    const username = uniqueUsername('pwd')
    await page.getByTestId('employee-add-btn').click()
    await page.getByTestId('employee-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('employee-add-username-input').fill(username)
    await page.getByTestId('employee-add-password-input').fill('123456')
    await page.getByTestId('employee-add-name-input').fill(uniqueName('改密'))
    await selectOption(page, 'employee-add-role-select', '前台接待')
    await page.getByTestId('employee-add-submit-btn').click()
    await expectMessage(page, '员工添加成功')

    await page.getByTestId('employee-keyword-input').fill(username)
    await page.getByTestId('employee-search-btn').click()
    await page.getByTestId('employee-row').first().waitFor({ state: 'visible' })
    await page.getByTestId('employee-row').first().getByTestId('employee-edit-btn').click()

    await page.getByTestId('employee-edit-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('employee-edit-password-input').fill('newpwd456')
    await page.getByTestId('employee-edit-submit-btn').click()
    await expectMessage(page, '员工信息已更新')
    await page.screenshot({ path: 'tests-e2e/screenshots/employee-06-reset-pwd.png', fullPage: true })
  })

  test('默认管理员 admin 不可禁用', async ({ page }) => {
    await page.getByTestId('employee-keyword-input').fill('admin')
    await page.getByTestId('employee-search-btn').click()
    const adminRow = page.getByTestId('employee-row').first()
    await adminRow.waitFor({ state: 'visible' })
    await adminRow.getByTestId('employee-disable-btn').click()
    const warn = page.locator('.el-message--warning').last()
    await warn.waitFor({ state: 'visible', timeout: 8_000 })
    await expect(warn).toContainText(/默认管理员/)
    await page.screenshot({ path: 'tests-e2e/screenshots/employee-07-admin-protect.png', fullPage: true })
  })

  test('分页器可见', async ({ page }) => {
    await page.getByTestId('employee-pagination').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/employee-09-pagination.png', fullPage: true })
  })
})
