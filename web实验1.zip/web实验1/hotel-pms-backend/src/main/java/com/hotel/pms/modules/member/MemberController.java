package com.hotel.pms.modules.member;

import com.hotel.pms.common.PageResult;
import com.hotel.pms.common.Result;
import com.hotel.pms.entity.Member;
import com.hotel.pms.vo.MemberVO;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/members")
public class MemberController {

    private final MemberService memberService;

    public MemberController(MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping
    public Result<List<MemberVO>> list() {
        return Result.success(memberService.list());
    }

    /**
     * 条件分页：keyword（姓名/手机号）、level
     */
    @GetMapping("/page")
    public Result<PageResult<MemberVO>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String level) {
        return Result.success(memberService.page(pageNum, pageSize, keyword, level));
    }

    @GetMapping("/{id}")
    public Result<MemberVO> findById(@PathVariable Long id) {
        return Result.success(memberService.findById(id));
    }

    @PostMapping
    public Result<MemberVO> create(@RequestBody Member member) {
        return Result.success(memberService.create(member));
    }

    @PutMapping("/{id}")
    public Result<?> update(@PathVariable Long id, @RequestBody Member member) {
        memberService.update(id, member);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    public Result<?> delete(@PathVariable Long id) {
        memberService.delete(id);
        return Result.success();
    }

    @PutMapping("/{id}/points")
    public Result<?> addPoints(@PathVariable Long id, @RequestBody Map<String, Integer> body) {
        memberService.addPoints(id, body.get("points"));
        return Result.success();
    }

    @PutMapping("/{id}/balance")
    public Result<?> addBalance(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        memberService.addBalance(id, new BigDecimal(body.get("amount").toString()));
        return Result.success();
    }

    @PutMapping("/{id}/consume")
    public Result<?> consume(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        memberService.consumeBalance(id, new BigDecimal(body.get("amount").toString()));
        return Result.success();
    }

    @GetMapping("/{id}/transactions")
    public Result<?> transactions(@PathVariable Long id) {
        return Result.success(memberService.getTransactions(id));
    }
}
