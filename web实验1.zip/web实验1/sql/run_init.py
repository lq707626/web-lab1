import pymysql

conn = pymysql.connect(host='your-vm-ip', port=3306, user='root', password='your_password', database='mydb', charset='utf8mb4')
cursor = conn.cursor()

with open(r'C:\Users\lq\Desktop\web实验1\sql\init.sql', 'r', encoding='utf-8') as f:
    content = f.read()

# Remove comment lines
lines = []
for line in content.split('\n'):
    stripped = line.strip()
    if stripped.startswith('--'):
        continue
    lines.append(line)
sql = '\n'.join(lines)

# Split by semicolon
statements = [s.strip() for s in sql.split(';') if s.strip()]
print(f"共 {len(statements)} 条SQL语句")

for i, stmt in enumerate(statements):
    try:
        cursor.execute(stmt)
        print(f"  [{i+1}] OK: {stmt[:60]}...")
    except Exception as e:
        print(f"  [{i+1}] FAIL: {e}")

conn.commit()

cursor.execute('SHOW TABLES')
tables = cursor.fetchall()
print(f"\nmydb 中现有 {len(tables)} 张表:")
for t in tables:
    print(f"  - {t[0]}")

for table in ['employee', 'room', 'room_type', 'member']:
    try:
        cursor.execute(f'SELECT COUNT(*) FROM {table}')
        print(f"{table}: {cursor.fetchone()[0]} 条记录")
    except:
        print(f"{table}: 不存在")

conn.close()
