/**
 * 通用格式化与校验工具
 */

/** 手机号脱敏：138****1234 */
export function maskPhone(phone) {
  if (!phone) return ''
  const s = String(phone)
  if (s.length !== 11) return s
  return s.slice(0, 3) + '****' + s.slice(7)
}

/** 身份证号脱敏：6101**********1234（兼容历史脏数据中的非 18 位号码） */
export function maskIdCard(idCard) {
  if (!idCard) return ''
  const s = String(idCard)
  if (s.length < 10) return s
  const stars = '*'.repeat(Math.max(4, s.length - 8))
  return s.slice(0, 4) + stars + s.slice(-4)
}

/** 金额保留两位小数 */
export function money(value, digits = 2) {
  const n = Number(value)
  return Number.isFinite(n) ? n.toFixed(digits) : Number(0).toFixed(digits)
}

/** 手机号格式（11 位，1 开头，第二位 3-9） */
export function isValidPhone(phone) {
  return /^1[3-9]\d{9}$/.test(String(phone || ''))
}

/** 身份证号格式（18 位，最后一位可为 X） */
export function isValidIdCard(idCard) {
  return /^\d{17}[\dXx]$/.test(String(idCard || ''))
}

/** 当前日期 YYYY-MM-DD */
export function todayStr() {
  const d = new Date()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${d.getFullYear()}-${m}-${day}`
}

/** 两个日期字符串之间相差的间夜数 */
export function diffDays(start, end) {
  if (!start || !end) return 0
  const s = new Date(String(start).replace(/-/g, '/'))
  const e = new Date(String(end).replace(/-/g, '/'))
  const ms = e.getTime() - s.getTime()
  if (Number.isNaN(ms) || ms <= 0) return 0
  return Math.round(ms / 86400000)
}

/**
 * 房态与颜色（与报告 5.2.2 / 6.2.2 保持一致）
 * code 用于生成 data-testid：room-filter-{code} / room-cell 的 data-room-status
 */
export const ROOM_STATUS_LIST = [
  { label: '空房', code: 'empty', color: '#67C23A' },
  { label: '已入住', code: 'occupied', color: '#F56C6C' },
  { label: '已预订', code: 'reserved', color: '#E6A23C' },
  { label: '维修中', code: 'repair', color: '#909399' },
  { label: '待清洁', code: 'cleaning', color: '#9B59B6' }
]

/** 房态颜色 */
export function roomColor(status) {
  const hit = ROOM_STATUS_LIST.find(item => item.label === status)
  return hit ? hit.color : '#C0C4CC'
}

/** 房态可流转的目标状态（已入住必须先退房） */
export const ROOM_STATUS_TRANSITIONS = {
  '空房': ['已预订', '已入住', '维修中', '待清洁'],
  '已预订': ['空房', '已入住', '维修中'],
  // 已入住必须走入住管理的退房流程，不能手工改房态（否则会绕过账单与入住记录）
  '已入住': [],
  '维修中': ['空房', '待清洁'],
  '待清洁': ['空房', '维修中']
}

/** 订单状态标签类型 */
export const RESERVATION_STATUS_TYPE = {
  '待确认': 'warning',
  '已确认': 'success',
  '已到店': 'primary',
  '已离店': 'info',
  '已取消': 'danger',
  'NoShow': 'info'
}

/** 会员等级标签类型 */
export const MEMBER_LEVEL_TYPE = {
  '普通会员': 'info',
  '银卡会员': 'success',
  '金卡会员': 'warning',
  '钻石会员': 'danger'
}

/** 账单状态标签类型 */
export function billStatusType(status) {
  if (status === '已结算') return 'success'
  if (status === '已退款') return 'info'
  return 'warning'
}
