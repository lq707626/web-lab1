package com.hotel.pms.modules.bill;

import cn.hutool.core.util.RandomUtil;
import com.hotel.pms.common.BizException;
import com.hotel.pms.common.PageResult;
import com.hotel.pms.common.SecurityUtil;
import com.hotel.pms.entity.Bill;
import com.hotel.pms.entity.BillItem;
import com.hotel.pms.mapper.BillMapper;
import com.hotel.pms.vo.BillItemVO;
import com.hotel.pms.vo.BillVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BillServiceImpl implements BillService {

    private static final Logger log = LoggerFactory.getLogger(BillServiceImpl.class);

    private final BillMapper billMapper;

    public BillServiceImpl(BillMapper billMapper) {
        this.billMapper = billMapper;
    }

    @Override
    public List<BillVO> list() {
        return billMapper.findPageVO(0, 10000, null, null);
    }

    @Override
    public PageResult<BillVO> page(int pageNum, int pageSize, String keyword, String status) {
        pageNum = Math.max(pageNum, 1);
        pageSize = Math.min(Math.max(pageSize, 1), 100);
        int offset = (pageNum - 1) * pageSize;
        List<BillVO> records = billMapper.findPageVO(offset, pageSize, keyword, status);
        long total = billMapper.countVO(keyword, status);
        return new PageResult<>(total, pageNum, pageSize, records);
    }

    @Override
    public BillVO detail(Long id) {
        BillVO vo = billMapper.findVOById(id);
        if (vo == null) {
            throw new BizException("账单不存在");
        }
        return withItems(vo);
    }

    @Override
    public BillVO findByCheckinId(Long checkinId) {
        BillVO vo = billMapper.findVOByCheckinId(checkinId);
        if (vo == null) {
            throw new BizException("该入住单还没有账单");
        }
        return withItems(vo);
    }

    /**
     * 创建账单：有明细时按"单价 × 数量"汇总应收；无明细时保留传入应收
     */
    @Override
    @Transactional
    public BillVO create(Bill bill) {
        String billNo = "BL" + LocalDateTime.now().format(
            DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS")) + RandomUtil.randomNumbers(3);
        bill.setBillNo(billNo);

        if (bill.getItems() != null && !bill.getItems().isEmpty()) {
            BigDecimal receivable = BigDecimal.ZERO;
            for (BillItem item : bill.getItems()) {
                BigDecimal price = item.getAmount() != null ? item.getAmount() : BigDecimal.ZERO;
                int quantity = item.getQuantity() != null ? item.getQuantity() : 1;
                receivable = receivable.add(price.multiply(BigDecimal.valueOf(quantity)));
            }
            bill.setReceivableAmount(receivable);
        } else if (bill.getReceivableAmount() == null) {
            bill.setReceivableAmount(BigDecimal.ZERO);
        }

        if (bill.getActualAmount() == null) {
            bill.setActualAmount(bill.getReceivableAmount());
        }
        if (bill.getDepositDeduct() == null) {
            bill.setDepositDeduct(BigDecimal.ZERO);
        }
        bill.setSettleStatus("未结算");
        bill.setCreateBy(SecurityUtil.getCurrentUsername());
        billMapper.insert(bill);

        if (bill.getItems() != null && !bill.getItems().isEmpty()) {
            bill.getItems().forEach(item -> item.setBillNo(bill.getBillNo()));
            billMapper.batchInsertItems(bill.getItems());
        }
        log.info("账单创建成功，单号：{}，应收金额：{}", billNo, bill.getReceivableAmount());
        return detail(bill.getId());
    }

    /**
     * 结算：实收为空时按"应收 - 押金抵扣"自动计算
     */
    @Override
    @Transactional
    public void settle(Long id, BigDecimal actualAmount) {
        Bill bill = billMapper.findById(id);
        if (bill == null) {
            throw new BizException("账单不存在");
        }
        if ("已结算".equals(bill.getSettleStatus())) {
            throw new BizException("该账单已结算，已结算账单不可修改");
        }
        if ("已退款".equals(bill.getSettleStatus())) {
            throw new BizException("该账单已退款，不能再次结算");
        }
        if (actualAmount != null && actualAmount.compareTo(BigDecimal.ZERO) < 0) {
            throw new BizException("实收金额不能为负数");
        }
        if (actualAmount == null) {
            BigDecimal receivable = bill.getReceivableAmount() != null
                ? bill.getReceivableAmount() : BigDecimal.ZERO;
            BigDecimal deposit = bill.getDepositDeduct() != null
                ? bill.getDepositDeduct() : BigDecimal.ZERO;
            actualAmount = receivable.subtract(deposit);
            if (actualAmount.compareTo(BigDecimal.ZERO) < 0) {
                actualAmount = BigDecimal.ZERO;
            }
        }
        billMapper.settleWithAmount(id, actualAmount);
        log.info("账单结算成功，单号：{}，实收金额：{}", bill.getBillNo(), actualAmount);
    }

    private BillVO withItems(BillVO vo) {
        List<BillItem> items = billMapper.findItems(vo.getBillNo());
        vo.setItems(items.stream().map(this::toItemVO).collect(Collectors.toList()));
        return vo;
    }

    private BillItemVO toItemVO(BillItem item) {
        BillItemVO vo = new BillItemVO();
        vo.setId(item.getId());
        vo.setBillNo(item.getBillNo());
        vo.setItemType(item.getItemType());
        vo.setAmount(item.getAmount());
        vo.setQuantity(item.getQuantity());
        vo.setPayMethod(item.getPayMethod());
        vo.setItemTime(item.getItemTime() == null ? null : item.getItemTime().toString());
        return vo;
    }
}
