// @ts-check
import { defineConfig, devices } from '@playwright/test'

/**
 * Playwright E2E 配置
 * 前端地址：http://localhost:5173（Vite dev server，/api 代理到 8080）
 *
 * 运行前提：
 *   1. 后端 Spring Boot 已启动（8080）
 *   2. 前端已启动：npm run dev（5173）
 *   3. 已安装浏览器：npx playwright install chromium
 */
export default defineConfig({
  testDir: './tests-e2e',
  // 用例超时：业务用例包含登录 + 多个接口交互，给到 30s
  timeout: 30_000,
  expect: { timeout: 10_000 },
  fullyParallel: false,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  workers: 1, // PMS 共享同一数据库，串行跑避免数据互相干扰
  reporter: [
    ['list'],
    ['html', { open: 'never', outputFolder: 'tests-e2e/report' }]
  ],
  use: {
    baseURL: 'http://localhost:5173',
    headless: true,
    actionTimeout: 10_000,
    navigationTimeout: 15_000,
    // 失败时自动截图，人工查看
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
    locale: 'zh-CN'
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] }
    }
  ]
})
