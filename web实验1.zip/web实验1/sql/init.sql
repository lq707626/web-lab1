-- 酒店PMS系统数据库初始化脚本
-- MySQL 8.0, 数据库 mydb 已存在
-- 注意：本脚本用于【全新数据库】初始化；已有数据的库请勿整份重跑
--      （seed INSERT 会因 room_number / username / phone 等唯一键冲突中断），
--      已有库的升级请执行 sql/migrate_20261031.sql（幂等，可重复执行）。

-- ========== 1. 房型表 ==========
CREATE TABLE IF NOT EXISTS room_type (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(50) NOT NULL COMMENT '房型名称',
    bed_type VARCHAR(20) NOT NULL COMMENT '床型',
    area DECIMAL(6,1) COMMENT '面积(㎡)',
    base_price DECIMAL(10,2) NOT NULL COMMENT '基础房价',
    create_by VARCHAR(50),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_by VARCHAR(50),
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='房型表';

-- ========== 2. 客房表 ==========
CREATE TABLE IF NOT EXISTS room (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(10) NOT NULL UNIQUE COMMENT '房间号',
    room_type_id BIGINT NOT NULL COMMENT '房型ID',
    floor INT COMMENT '楼层',
    room_status VARCHAR(20) NOT NULL DEFAULT '空房' COMMENT '房态:空房/已入住/已预订/维修中/待清洁',
    remark VARCHAR(200) COMMENT '备注',
    version INT DEFAULT 0 COMMENT '乐观锁版本号',
    create_by VARCHAR(50),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_by VARCHAR(50),
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0,
    INDEX idx_room_type(room_type_id),
    INDEX idx_room_status(room_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客房表';

-- ========== 3. 预订表 ==========
CREATE TABLE IF NOT EXISTS reservation (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_no VARCHAR(32) NOT NULL UNIQUE COMMENT '订单号',
    guest_name VARCHAR(50) NOT NULL COMMENT '客人姓名',
    phone VARCHAR(20) NOT NULL COMMENT '联系方式',
    check_in_date DATE NOT NULL COMMENT '入住日期',
    check_out_date DATE NOT NULL COMMENT '离店日期',
    room_type_id BIGINT NOT NULL COMMENT '房型ID',
    room_count INT NOT NULL DEFAULT 1 COMMENT '间数',
    status VARCHAR(20) NOT NULL DEFAULT '待确认' COMMENT '状态:待确认/已确认/已到店/已离店/已取消/NoShow',
    remark VARCHAR(500),
    query_code VARCHAR(10) COMMENT '订单查询码（游客凭手机号+查询码查订单）',
    create_by VARCHAR(50),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_by VARCHAR(50),
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0,
    INDEX idx_order_no(order_no),
    INDEX idx_phone(phone),
    INDEX idx_status(status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='预订表';

-- ========== 4. 入住登记表 ==========
CREATE TABLE IF NOT EXISTS checkin (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    checkin_no VARCHAR(32) NOT NULL UNIQUE COMMENT '入住单号',
    reservation_id BIGINT COMMENT '关联预订ID',
    room_id BIGINT NOT NULL COMMENT '房间ID',
    guest_name VARCHAR(50) NOT NULL COMMENT '客人姓名',
    id_card VARCHAR(18) NOT NULL COMMENT '身份证号',
    phone VARCHAR(20) COMMENT '手机号',
    deposit DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT '押金',
    checkin_time DATETIME NOT NULL COMMENT '入住时间',
    checkout_time DATETIME COMMENT '退房时间',
    status VARCHAR(20) NOT NULL DEFAULT '在住' COMMENT '状态:在住/已退房',
    create_by VARCHAR(50),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_by VARCHAR(50),
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0,
    INDEX idx_checkin_no(checkin_no),
    INDEX idx_room(room_id),
    INDEX idx_status(status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='入住登记表';

-- ========== 5. 账单主表 ==========
CREATE TABLE IF NOT EXISTS bill (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    bill_no VARCHAR(32) NOT NULL UNIQUE COMMENT '账单号',
    checkin_id BIGINT NOT NULL COMMENT '入住ID',
    receivable_amount DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT '应收金额',
    actual_amount DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT '实收金额',
    deposit_deduct DECIMAL(10,2) DEFAULT 0 COMMENT '押金抵扣',
    settle_status VARCHAR(20) NOT NULL DEFAULT '未结算' COMMENT '结算状态:未结算/已结算/已退款',
    settle_time DATETIME COMMENT '结算时间',
    create_by VARCHAR(50),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_by VARCHAR(50),
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0,
    INDEX idx_bill_no(bill_no),
    INDEX idx_settle_status(settle_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='账单主表';

-- ========== 6. 账单明细表 ==========
CREATE TABLE IF NOT EXISTS bill_item (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    bill_no VARCHAR(32) NOT NULL COMMENT '账单号',
    item_type VARCHAR(20) NOT NULL COMMENT '消费项目:房费/餐饮费/迷你吧消费/洗衣服务/加床费/其他',
    amount DECIMAL(10,2) NOT NULL COMMENT '金额',
    quantity INT DEFAULT 1 COMMENT '数量',
    pay_method VARCHAR(20) COMMENT '支付方式:现金/微信支付/支付宝/银行卡/会员余额',
    item_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '消费时间',
    create_by VARCHAR(50),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_by VARCHAR(50),
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0,
    INDEX idx_bill_no(bill_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='账单明细表';

-- ========== 7. 会员表 ==========
CREATE TABLE IF NOT EXISTS member (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL COMMENT '姓名',
    phone VARCHAR(20) NOT NULL UNIQUE COMMENT '手机号',
    level VARCHAR(20) NOT NULL DEFAULT '普通会员' COMMENT '等级:普通会员/银卡会员/金卡会员/钻石会员',
    points INT DEFAULT 0 COMMENT '积分',
    balance DECIMAL(10,2) DEFAULT 0.00 COMMENT '储值余额',
    create_by VARCHAR(50),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_by VARCHAR(50),
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员表';

-- ========== 8. 员工表 ==========
CREATE TABLE IF NOT EXISTS employee (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '登录账号',
    password VARCHAR(100) NOT NULL COMMENT '密码(BCrypt加密)',
    name VARCHAR(50) NOT NULL COMMENT '姓名',
    role VARCHAR(20) NOT NULL COMMENT '角色:系统管理员/前台接待/收银/客房经理/总经理',
    create_by VARCHAR(50),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_by VARCHAR(50),
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='员工表';

-- ========== 初始化数据 ==========

-- 房型
INSERT INTO room_type (type_name, bed_type, area, base_price) VALUES
('大床房', '大床', 25.0, 288.00),
('双床房', '双床', 30.0, 328.00),
('商务大床房', '大床', 35.0, 388.00),
('豪华大床房', '大床', 45.0, 588.00),
('豪华套房', '大床', 65.0, 888.00);

-- 客房（3层，每层6间）
INSERT INTO room (room_number, room_type_id, floor, room_status) VALUES
('301', 1, 3, '空房'), ('302', 1, 3, '空房'), ('303', 2, 3, '空房'),
('304', 2, 3, '空房'), ('305', 3, 3, '空房'), ('306', 5, 3, '维修中'),
('401', 1, 4, '空房'), ('402', 1, 4, '待清洁'), ('403', 2, 4, '空房'),
('404', 3, 4, '空房'), ('405', 4, 4, '空房'), ('406', 5, 4, '空房'),
('501', 1, 5, '空房'), ('502', 2, 5, '空房'), ('503', 2, 5, '空房'),
('504', 3, 5, '空房'), ('505', 4, 5, '空房'), ('506', 5, 5, '空房');

-- 员工（密码均为123456的BCrypt加密）
INSERT INTO employee (username, password, name, role) VALUES
('admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '系统管理员', '系统管理员'),
('front', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '前台小张', '前台接待'),
('cashier', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '收银小李', '收银'),
('manager', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '王经理', '客房经理');

-- 会员
INSERT INTO member (name, phone, level, points, balance) VALUES
('张三', '13800138000', '金卡会员', 2500, 500.00),
('李四', '13900139000', '银卡会员', 800, 200.00);

-- ========== 测试数据扩充（2026-10-31） ==========

-- 会员（20条）
INSERT INTO member (name, phone, level, points, balance) VALUES
('王建国', '13987373389', '普通会员', 1103, 1992.41),
('李秀英', '13925854735', '普通会员', 4456, 424.57),
('张伟', '13943089627', '普通会员', 3166, 1269.31),
('刘芳', '13960303339', '普通会员', 361, 1589.22),
('陈杰', '13964248085', '普通会员', 1657, 2459.90),
('杨丽', '13932066570', '普通会员', 1978, 2793.47),
('赵强', '13942323774', '金卡会员', 3799, 4767.42),
('黄敏', '13964233085', '普通会员', 3301, 2884.60),
('周涛', '13992950793', '普通会员', 4911, 835.22),
('吴霞', '13955877519', '金卡会员', 538, 4646.46),
('徐明', '13997650505', '金卡会员', 3756, 3823.50),
('孙丽', '13985125982', '普通会员', 3132, 4710.18),
('马军', '13955613093', '普通会员', 4946, 1005.82),
('朱燕', '13992119635', '银卡会员', 3375, 3975.26),
('胡刚', '13947799593', '普通会员', 635, 480.30),
('郭静', '13926545281', '银卡会员', 296, 2216.81),
('林强', '13960315982', '钻石会员', 2651, 862.20),
('何雪', '13930300202', '普通会员', 4119, 843.83),
('高鹏', '13931190497', '银卡会员', 4870, 3317.13),
('罗琳', '13990208492', '金卡会员', 68, 3930.11);

-- 预订（20条）
INSERT INTO reservation (order_no, guest_name, phone, check_in_date, check_out_date, room_type_id, room_count, status, remark) VALUES
('RES20261031001', '王建国', '13856229483', '2026-11-07', '2026-11-10', 5, 2, '已入住', '商务出差'),
('RES20261031002', '李秀英', '13892468654', '2026-11-28', '2026-12-02', 5, 1, '已确认', '需要大床房'),
('RES20261031003', '张伟', '13883781518', '2026-11-02', '2026-11-04', 7, 1, '已入住', '旅游度假'),
('RES20261031004', '刘芳', '13846965220', '2026-11-29', '2026-12-04', 5, 1, '已取消', '商务出差'),
('RES20261031005', '陈杰', '13860403103', '2026-11-08', '2026-11-11', 4, 1, '已入住', '无烟房间'),
('RES20261031006', '杨丽', '13869156501', '2026-11-16', '2026-11-21', 1, 2, '已确认', '生日入住'),
('RES20261031007', '赵强', '13865336040', '2026-11-26', '2026-11-30', 2, 1, '待确认', '无烟房间'),
('RES20261031008', '黄敏', '13835825821', '2026-11-23', '2026-11-27', 2, 2, '已入住', '需要加床'),
('RES20261031009', '周涛', '13817416030', '2026-11-12', '2026-11-14', 10, 1, '已入住', '无烟房间'),
('RES20261031010', '吴霞', '13833416332', '2026-11-04', '2026-11-08', 10, 1, '已入住', '无烟房间'),
('RES20261031011', '徐明', '13893603341', '2026-11-03', '2026-11-04', 10, 1, '已确认', '需要加床'),
('RES20261031012', '孙丽', '13880607310', '2026-11-16', '2026-11-17', 9, 1, '已完成', '生日入住'),
('RES20261031013', '马军', '13884434810', '2026-11-28', '2026-12-02', 1, 1, '已确认', '商务出差'),
('RES20261031014', '朱燕', '13835642007', '2026-11-26', '2026-11-28', 2, 1, '待确认', '旅游度假'),
('RES20261031015', '胡刚', '13827506648', '2026-11-14', '2026-11-19', 8, 1, '已确认', '需要加床'),
('RES20261031016', '郭静', '13898628816', '2026-11-27', '2026-11-28', 3, 1, '已取消', '无特殊要求'),
('RES20261031017', '林强', '13870452664', '2026-11-25', '2026-11-27', 4, 1, '已入住', '旅游度假'),
('RES20261031018', '何雪', '13889974152', '2026-11-11', '2026-11-15', 5, 1, '已入住', '无特殊要求'),
('RES20261031019', '高鹏', '13868744411', '2026-11-01', '2026-11-02', 4, 2, '已完成', '生日入住'),
('RES20261031020', '罗琳', '13820156425', '2026-11-27', '2026-12-02', 4, 1, '已入住', '无烟房间');

-- 入住（20条）
INSERT INTO checkin (checkin_no, room_id, guest_name, id_card, phone, deposit, checkin_time, checkout_time, status) VALUES
('CI20261031001', 12, '王建国', '61033380085361372', '13786337597', 220.90, '2026-10-20 00:33:48', '2026-10-24 00:33:48', '已退房'),
('CI20261031002', 16, '李秀英', '61074856348170729', '13717165630', 279.66, '2026-10-20 00:33:48', NULL, '在住'),
('CI20261031003', 9, '张伟', '61010511322350432', '13743893963', 151.50, '2026-10-26 00:33:48', '2026-10-30 00:33:48', '已退房'),
('CI20261031004', 16, '刘芳', '61012087374031710', '13741636861', 138.40, '2026-10-27 00:33:48', NULL, '在住'),
('CI20261031005', 6, '陈杰', '61041055705351144', '13746369825', 167.56, '2026-10-17 00:33:48', '2026-10-18 00:33:48', '已退房'),
('CI20261031006', 17, '杨丽', '61042535574392893', '13737889023', 228.81, '2026-10-14 00:33:48', '2026-10-17 00:33:48', '已退房'),
('CI20261031007', 17, '赵强', '61040562677828541', '13726184955', 497.89, '2026-10-21 00:33:48', '2026-10-25 00:33:48', '已退房'),
('CI20261031008', 15, '黄敏', '61074519047642513', '13734267647', 267.94, '2026-10-03 00:33:48', '2026-10-05 00:33:48', '已退房'),
('CI20261031009', 4, '周涛', '61094754616730972', '13769135743', 245.05, '2026-10-02 00:33:48', '2026-10-04 00:33:48', '已退房'),
('CI20261031010', 16, '吴霞', '61053827496940345', '13756891668', 410.59, '2026-10-11 00:33:48', NULL, '在住'),
('CI20261031011', 4, '徐明', '61039240159840584', '13778892783', 360.60, '2026-10-05 00:33:48', '2026-10-06 00:33:48', '已退房'),
('CI20261031012', 16, '孙丽', '61059824926105271', '13790152656', 483.02, '2026-10-04 00:33:48', '2026-10-08 00:33:48', '已退房'),
('CI20261031013', 10, '马军', '61053554496504236', '13799005790', 205.34, '2026-10-17 00:33:48', '2026-10-19 00:33:48', '已退房'),
('CI20261031014', 4, '朱燕', '61068588573049005', '13730702246', 313.59, '2026-10-02 00:33:48', '2026-10-04 00:33:48', '已退房'),
('CI20261031015', 2, '胡刚', '61036451617254292', '13793739851', 350.23, '2026-10-19 00:33:48', '2026-10-22 00:33:48', '已退房'),
('CI20261031016', 2, '郭静', '61065542690396206', '13721807318', 217.50, '2026-10-12 00:33:48', '2026-10-14 00:33:48', '已退房'),
('CI20261031017', 10, '林强', '61043139873191528', '13748441997', 210.84, '2026-10-13 00:33:48', NULL, '在住'),
('CI20261031018', 7, '何雪', '61088908874392998', '13745653306', 112.65, '2026-10-29 00:33:48', '2026-11-02 00:33:48', '已退房'),
('CI20261031019', 15, '高鹏', '61030042504214818', '13768562333', 144.47, '2026-10-29 00:33:48', NULL, '在住'),
('CI20261031020', 13, '罗琳', '61069083393037327', '13731810681', 283.40, '2026-10-30 00:33:48', '2026-11-04 00:33:48', '已退房');

-- 账单（20条）
INSERT INTO bill (bill_no, checkin_id, receivable_amount, actual_amount, deposit_deduct, settle_status, settle_time) VALUES
('BILL20261031001', 14, 243.04, 240.79, 288.74, '已结算', '2026-10-17 00:33:48'),
('BILL20261031002', 12, 352.82, 337.30, 59.01, '已结算', '2026-10-20 00:33:48'),
('BILL20261031003', 14, 355.39, 345.22, 233.88, '已结算', '2026-10-19 00:33:48'),
('BILL20261031004', 16, 1551.97, 1443.76, 28.57, '未结算', NULL),
('BILL20261031005', 18, 1933.99, 1813.78, 294.56, '已结算', '2026-10-20 00:33:48'),
('BILL20261031006', 4, 1885.57, 1840.27, 286.31, '已结算', '2026-10-18 00:33:48'),
('BILL20261031007', 19, 1618.61, 1542.49, 185.33, '已结算', '2026-10-12 00:33:48'),
('BILL20261031008', 16, 1316.83, 1296.32, 293.86, '已结算', '2026-10-29 00:33:48'),
('BILL20261031009', 17, 400.36, 364.68, 227.18, '已结算', '2026-10-19 00:33:48'),
('BILL20261031010', 4, 1480.87, 1440.16, 57.53, '已结算', '2026-10-21 00:33:48'),
('BILL20261031011', 16, 1703.53, 1574.12, 269.87, '已结算', '2026-10-22 00:33:48'),
('BILL20261031012', 20, 278.95, 251.43, 69.77, '已结算', '2026-10-23 00:33:48'),
('BILL20261031013', 3, 1205.48, 1113.02, 110.06, '部分结算', NULL),
('BILL20261031014', 4, 1097.83, 1097.71, 89.90, '已结算', '2026-10-23 00:33:48'),
('BILL20261031015', 12, 1144.32, 1088.60, 196.81, '部分结算', NULL),
('BILL20261031016', 4, 243.96, 240.04, 35.34, '部分结算', NULL),
('BILL20261031017', 13, 1702.09, 1696.24, 2.44, '已结算', '2026-10-28 00:33:48'),
('BILL20261031018', 17, 1910.00, 1862.48, 263.72, '已结算', '2026-10-23 00:33:48'),
('BILL20261031019', 4, 1019.84, 933.88, 81.68, '已结算', '2026-10-30 00:33:48'),
('BILL20261031020', 5, 341.35, 315.57, 34.94, '未结算', NULL);

-- 账单明细（20条）
INSERT INTO bill_item (bill_no, item_type, amount, quantity, pay_method, item_time) VALUES
('BILL20261031016', '购物', 125.19, 1, '微信', '2026-10-17 00:33:48'),
('BILL20261031010', '娱乐', 293.72, 2, '银行卡', '2026-10-27 00:33:48'),
('BILL20261031009', '娱乐', 187.56, 3, '微信', '2026-10-21 00:33:48'),
('BILL20261031013', '房费', 170.94, 1, '银行卡', '2026-10-26 00:33:48'),
('BILL20261031020', '餐饮', 333.99, 2, '银行卡', '2026-10-11 00:33:48'),
('BILL20261031015', '房费', 474.73, 2, '微信', '2026-10-18 00:33:48'),
('BILL20261031012', '房费', 478.85, 1, '现金', '2026-10-28 00:33:48'),
('BILL20261031002', '其他', 303.50, 3, '微信', '2026-10-24 00:33:48'),
('BILL20261031016', '餐饮', 97.59, 1, '现金', '2026-10-27 00:33:48'),
('BILL20261031003', '购物', 473.75, 3, '微信', '2026-10-29 00:33:48'),
('BILL20261031019', '购物', 154.31, 3, '现金', '2026-10-17 00:33:48'),
('BILL20261031005', '娱乐', 370.37, 1, '银行卡', '2026-10-24 00:33:48'),
('BILL20261031006', '购物', 397.18, 3, '现金', '2026-10-13 00:33:48'),
('BILL20261031002', '娱乐', 100.12, 3, '银行卡', '2026-10-20 00:33:48'),
('BILL20261031007', '餐饮', 283.77, 3, '会员卡', '2026-10-24 00:33:48'),
('BILL20261031018', '餐饮', 169.73, 3, '会员卡', '2026-10-17 00:33:48'),
('BILL20261031008', '其他', 430.82, 2, '微信', '2026-10-18 00:33:48'),
('BILL20261031018', '购物', 489.89, 3, '支付宝', '2026-10-18 00:33:48'),
('BILL20261031005', '餐饮', 157.19, 1, '现金', '2026-10-13 00:33:48'),
('BILL20261031008', '娱乐', 240.89, 1, '会员卡', '2026-10-27 00:33:48');

-- ========== 10. 会员流水表 ==========
CREATE TABLE IF NOT EXISTS member_transaction (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    member_id BIGINT NOT NULL COMMENT '会员ID',
    type VARCHAR(30) NOT NULL COMMENT '类型:积分充值/余额充值/余额消费/积分奖励',
    amount DECIMAL(10,2) NOT NULL COMMENT '变动金额',
    balance_after DECIMAL(10,2) COMMENT '变动后余额',
    points_after INT COMMENT '变动后积分',
    remark VARCHAR(200),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_member_id(member_id),
    INDEX idx_type(type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员流水表';

-- ========== 11. 支付流水表（沙箱） ==========
CREATE TABLE IF NOT EXISTS payment (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    payment_no VARCHAR(32) NOT NULL UNIQUE COMMENT '支付单号',
    order_no VARCHAR(32) COMMENT '关联订单号',
    bill_id BIGINT COMMENT '关联账单ID',
    channel VARCHAR(20) NOT NULL COMMENT '支付渠道:微信支付/支付宝',
    amount DECIMAL(10,2) NOT NULL COMMENT '支付金额',
    status VARCHAR(20) NOT NULL DEFAULT '待支付' COMMENT '状态:待支付/已支付/已退款/支付失败',
    trade_no VARCHAR(64) COMMENT '第三方交易号',
    pay_time DATETIME COMMENT '支付时间',
    refund_time DATETIME COMMENT '退款时间',
    remark VARCHAR(200),
    create_by VARCHAR(50),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0,
    INDEX idx_bill_id(bill_id),
    INDEX idx_status(status),
    INDEX idx_channel(channel)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='支付流水表（沙箱）';

-- 兼容旧库：如果 reservation 表已存在且缺少 query_code 字段则补上
-- 说明：MySQL 8.0 不支持 ALTER TABLE ... ADD COLUMN IF NOT EXISTS（MariaDB 专有），
-- 直接写会导致整个脚本在此处报错，因此用 information_schema 判断后动态执行。
SET @has_query_code := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'reservation' AND COLUMN_NAME = 'query_code'
);
SET @ddl := IF(@has_query_code = 0,
    'ALTER TABLE reservation ADD COLUMN query_code VARCHAR(10) COMMENT ''订单查询码''',
    'SELECT 1');
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ========== 12. 补充测试账号（总经理，密码 123456） ==========
-- 报告 3.3 角色枚举包含"总经理"，前端报表页面按该角色做只读权限控制
INSERT INTO employee (username, password, name, role)
SELECT 'gm', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '总经理', '总经理'
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM employee WHERE username = 'gm');

-- ========== 13. 历史测试数据规范化（与报告 3.3 枚举保持一致，可重复执行） ==========
-- 预订状态：报告枚举为 待确认/已确认/已到店/已离店/已取消/NoShow
UPDATE reservation SET status = '已到店' WHERE status = '已入住';
UPDATE reservation SET status = '已离店' WHERE status = '已完成';
-- 预订表引用了不存在的房型（历史测试数据使用了 6-10 号房型），收敛到现有 1-5 号房型
UPDATE reservation SET room_type_id = ((room_type_id - 1) % 5) + 1 WHERE room_type_id > 5;
-- 账单状态：报告枚举为 未结算/已结算/已退款
UPDATE bill SET settle_status = '未结算' WHERE settle_status = '部分结算';
-- 账单明细消费项目：报告枚举为 房费/餐饮费/迷你吧消费/洗衣服务/加床费/其他
UPDATE bill_item SET item_type = '其他' WHERE item_type IN ('购物', '娱乐');
UPDATE bill_item SET item_type = '餐饮费' WHERE item_type = '餐饮';
-- 支付方式：报告枚举为 现金/微信支付/支付宝/银行卡/会员余额
UPDATE bill_item SET pay_method = '微信支付' WHERE pay_method = '微信';
UPDATE bill_item SET pay_method = '会员余额' WHERE pay_method = '会员卡';
-- 房态与入住记录对齐：有"在住"记录的客房同步为已入住（历史种子数据的房态与入住表不一致）
UPDATE room r
JOIN checkin c ON c.room_id = r.id AND c.status = '在住' AND c.is_deleted = 0
SET r.room_status = '已入住'
WHERE r.is_deleted = 0;

-- ========== 14. 设施表 / 房间-设施关联表（多对多） ==========
CREATE TABLE IF NOT EXISTS amenity (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL COMMENT '设施名称',
    icon VARCHAR(50) COMMENT '图标标识',
    sort_no INT DEFAULT 0 COMMENT '排序号',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客房设施表';

CREATE TABLE IF NOT EXISTS room_amenity (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    room_id BIGINT NOT NULL COMMENT '房间ID',
    amenity_id BIGINT NOT NULL COMMENT '设施ID',
    UNIQUE KEY uk_room_amenity (room_id, amenity_id),
    KEY idx_amenity (amenity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='房间-设施关联表（多对多）';

INSERT IGNORE INTO amenity (id, name, icon, sort_no) VALUES
(1, '免费WiFi', 'wifi', 1),
(2, '空调', 'ac', 2),
(3, '液晶电视', 'tv', 3),
(4, '独立卫浴', 'bath', 4),
(5, '迷你吧', 'minibar', 5),
(6, '保险箱', 'safe', 6),
(7, '浴缸', 'bathtub', 7),
(8, '观景阳台', 'balcony', 8);

INSERT IGNORE INTO room_amenity (room_id, amenity_id) SELECT id, 1 FROM room;
INSERT IGNORE INTO room_amenity (room_id, amenity_id) SELECT id, 2 FROM room;
INSERT IGNORE INTO room_amenity (room_id, amenity_id) SELECT id, 3 FROM room;
INSERT IGNORE INTO room_amenity (room_id, amenity_id) SELECT id, 4 FROM room WHERE room_type_id >= 3;
INSERT IGNORE INTO room_amenity (room_id, amenity_id) SELECT id, 5 FROM room WHERE room_type_id >= 4;
INSERT IGNORE INTO room_amenity (room_id, amenity_id) SELECT id, 6 FROM room WHERE room_type_id = 5;
INSERT IGNORE INTO room_amenity (room_id, amenity_id) SELECT id, 7 FROM room WHERE room_type_id = 5;
INSERT IGNORE INTO room_amenity (room_id, amenity_id) SELECT id, 8 FROM room WHERE room_type_id >= 4;

-- ========== 15. 房间门锁表（与 room 一对一） ==========
CREATE TABLE IF NOT EXISTS room_lock (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    room_id BIGINT NOT NULL COMMENT '房间ID',
    lock_no VARCHAR(32) NOT NULL COMMENT '门锁编号',
    status VARCHAR(20) NOT NULL DEFAULT '已锁闭' COMMENT '门锁状态:已锁闭/已开卡',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_room_lock_room (room_id),
    UNIQUE KEY uk_room_lock_no (lock_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='房间门锁表（一对一）';

INSERT IGNORE INTO room_lock (room_id, lock_no, status)
SELECT id, CONCAT('LOCK-', room_number), '已锁闭' FROM room;
