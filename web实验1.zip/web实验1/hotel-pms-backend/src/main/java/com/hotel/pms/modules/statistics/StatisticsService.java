package com.hotel.pms.modules.statistics;

import com.hotel.pms.vo.StatisticsVO;

import java.util.List;
import java.util.Map;

public interface StatisticsService {

    /** 总览指标（VO 由 Service 组装） */
    StatisticsVO overview();

    List<Map<String, Object>> roomStatus();

    List<Map<String, Object>> memberLevel();

    List<Map<String, Object>> revenueTrend(String start, String end);
}
