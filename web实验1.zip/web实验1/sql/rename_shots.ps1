$dir = "C:\Users\lq\Desktop\web实验1\hotel-pms-frontend\tests-e2e\screenshots"

$map = @{
    # 登录模块 01-15
    "login-01-admin-success.png"    = "登录模块01.png"
    "login-02-front-success.png"   = "登录模块02.png"
    "login-03-cashier-success.png"  = "登录模块03.png"
    "login-04-manager-success.png"  = "登录模块04.png"
    "login-05-gm-success.png"      = "登录模块05.png"
    "login-06-wrong-password.png"   = "登录模块06.png"
    "login-07-no-such-user.png"    = "登录模块07.png"
    "login-08-empty-username.png"  = "登录模块09.png"
    "login-10-empty-password.png"  = "登录模块10.png"
    "login-09-no-auth-redirect.png"= "登录模块11.png"
    "login-10-token-invalid.png"    = "登录模块12.png"
    "login-11-forbidden-page.png" = "登录模块13.png"
    "security-11-api-forbidden.png"= "登录模块14.png"
    "login-12-logout.png"          = "登录模块15.png"

    # 房态管理模块 01-15
    "room-01-render.png"           = "房态管理模块01.png"
    "room-02-filter-repair.png"    = "房态管理模块02.png"
    "room-03-filter-all.png"       = "房态管理模块03.png"
    "room-04-price.png"            = "房态管理模块04.png"
    "room-05-detail.png"           = "房态管理模块05.png"
    "room-06-to-repair.png"        = "房态管理模块07.png"
    "room-09-occupied-forbidden.png" = "房态管理模块09.png"
    "room-10-illegal-transition.png" = "房态管理模块10.png"
    "room-13-lock.png"             = "房态管理模块13.png"
    "room-15-refresh.png"          = "房态管理模块15.png"

    # 预订管理模块 01-16
    "reservation-01-add-success.png" = "预订管理模块01.png"
    "reservation-02-phone-invalid.png" = "预订管理模块02.png"
    "reservation-04-confirm.png"   = "预订管理模块07.png"
    "reservation-05-cancel-success.png" = "预订管理模块08.png"
    "reservation-08-cancel-no-reason.png" = "预订管理模块09.png"
    "reservation-03-edit-success.png" = "预订管理模块10.png"
    "reservation-06-delete.png"    = "预订管理模块11.png"
    "reservation-07-empty.png"     = "预订管理模块15.png"
    "reservation-13-status-filter.png" = "预订管理模块13.png"
    "reservation-14-pagination.png" = "预订管理模块14.png"
    "reservation-16-checkin-btn.png" = "预订管理模块16.png"

    # 入住管理模块 01-13
    "checkin-01-checkin-success.png" = "入住管理模块01.png"
    "checkin-02-idcard-invalid.png" = "入住管理模块03.png"
    "checkin-08-mask.png"          = "入住管理模块08.png"
    "checkin-03-edit-success.png"  = "入住管理模块09.png"
    "checkin-05-after-delete.png"  = "入住管理模块10.png"
    "checkin-11-empty.png"         = "入住管理模块11.png"
    "checkin-12-status-filter.png" = "入住管理模块12.png"
    "checkin-13-pagination.png"   = "入住管理模块13.png"

    # 账单结算模块 01-11
    "checkin-04-checkout-dialog.png" = "账单结算模块01.png"
    "checkin-04-checkout-success.png" = "账单结算模块02.png"
    "bill-01-list.png"             = "账单结算模块03.png"
    "bill-05-detail.png"           = "账单结算模块05.png"
    "bill-06-settle.png"           = "账单结算模块06.png"
    "bill-07-settled-no-settle.png" = "账单结算模块07.png"
    "bill-status-refund.png"       = "账单结算模块08.png"
    "bill-10-empty.png"            = "账单结算模块10.png"

    # 收银结算模块 01-09
    "cashier-01-list.png"          = "收银结算模块01.png"
    "cashier-02-cash-success.png"  = "收银结算模块02.png"
    "cashier-03-insufficient.png"  = "收银结算模块03.png"
    "cashier-06-bankcard.png"      = "收银结算模块06.png"
    "cashier-09-daily.png"         = "收银结算模块09.png"

    # 会员管理模块 01-12
    "member-01-add-success.png"    = "会员管理模块01.png"
    "member-08-duplicate-phone.png" = "会员管理模块02.png"
    "member-02-phone-invalid.png" = "会员管理模块03.png"
    "member-03-edit-success.png"   = "会员管理模块04.png"
    "member-06-after-delete.png"   = "会员管理模块05.png"
    "member-09-level-filter.png"   = "会员管理模块07.png"
    "member-08-pagination.png"     = "会员管理模块08.png"
    "member-04-points-success.png" = "会员管理模块09.png"
    "member-05-recharge-success.png" = "会员管理模块10.png"
    "member-11-transactions.png"  = "会员管理模块11.png"
    "member-12-mask.png"           = "会员管理模块12.png"

    # 报表统计模块 01-07
    "statistics-01-cards.png"      = "报表统计模块01.png"
    "statistics-02-pie.png"        = "报表统计模块02.png"
    "statistics-03-bar.png"        = "报表统计模块03.png"
    "statistics-04-trend.png"      = "报表统计模块04.png"
    "statistics-05-date-picker.png" = "报表统计模块05.png"
    "statistics-07-gm-access.png"  = "报表统计模块07.png"

    # 员工管理模块 01-09
    "employee-01-add-success.png"  = "员工管理模块02.png"
    "employee-02-duplicate-username.png" = "员工管理模块03.png"
    "employee-03-edit-success.png" = "员工管理模块04.png"
    "employee-06-reset-pwd.png"   = "员工管理模块05.png"
    "employee-04-disable-success.png" = "员工管理模块06.png"
    "employee-07-admin-protect.png" = "员工管理模块07.png"
    "employee-05-search.png"      = "员工管理模块08.png"
    "employee-09-pagination.png"   = "员工管理模块09.png"

    # 第三方对接模块 01-09
    "thirdparty-01-ctrip.png"      = "第三方对接模块01.png"
    "thirdparty-02-meituan.png"    = "第三方对接模块02.png"
    "thirdparty-03-cancel.png"     = "第三方对接模块03.png"
    "thirdparty-04-sync.png"       = "第三方对接模块04.png"
    "thirdparty-05-timeout.png"    = "第三方对接模块05.png"
    "thirdparty-06-auth-fail.png"  = "第三方对接模块06.png"
    "thirdparty-07-issue.png"      = "第三方对接模块07.png"
    "thirdparty-08-cancel.png"     = "第三方对接模块08.png"

    # 游客端模块 01-09
    "guest-01-access.png"         = "游客端模块01.png"
    "guest-02-roomtypes.png"       = "游客端模块02.png"
    "guest-03-rooms.png"           = "游客端模块03.png"
    "guest-04-book-success.png"    = "游客端模块04.png"
    "guest-05-phone-invalid.png"   = "游客端模块05.png"
    "guest-07-query.png"           = "游客端模块07.png"
    "guest-08-query-fail.png"      = "游客端模块08.png"
    "guest-09-to-login.png"        = "游客端模块09.png"

    # 异常测试
    "exception-11-phone-boundary.png" = "异常测试11.png"
    "exception-13-double-submit.png"  = "异常测试13.png"
    "exception-14-long-input.png"      = "异常测试14.png"
    "security-09-xss.png"              = "异常测试15.png"
    "exception-16-refresh.png"         = "异常测试16.png"
    "exception-17-unknown-route.png"  = "异常测试17.png"

    # 安全测试
    "security-08-sqli.png"              = "安全测试08.png"
}

$copied = 0
$missing = @()
foreach ($old in $map.Keys) {
    $src = Join-Path $dir $old
    $dst = Join-Path $dir $map[$old]
    if (Test-Path -LiteralPath $src) {
        Copy-Item -LiteralPath $src -Destination $dst -Force
        $copied++
    } else {
        $missing += "$old -> $($map[$old])"
    }
}
Write-Host "Copied: $copied, Missing: $($missing.Count)"
if ($missing.Count -gt 0) {
    Write-Host "`nMissing screenshots:"
    $missing | ForEach-Object { Write-Host "  $_" }
}
