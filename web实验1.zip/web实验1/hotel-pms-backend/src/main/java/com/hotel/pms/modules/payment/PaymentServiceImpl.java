package com.hotel.pms.modules.payment;

import cn.hutool.core.util.RandomUtil;
import com.hotel.pms.common.BizException;
import com.hotel.pms.common.SecurityUtil;
import com.hotel.pms.entity.Bill;
import com.hotel.pms.entity.Payment;
import com.hotel.pms.mapper.BillMapper;
import com.hotel.pms.mapper.PaymentMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

@Service
public class PaymentServiceImpl implements PaymentService {

    private static final Logger log = LoggerFactory.getLogger(PaymentServiceImpl.class);

    private final PaymentMapper paymentMapper;
    private final BillMapper billMapper;

    public PaymentServiceImpl(PaymentMapper paymentMapper, BillMapper billMapper) {
        this.paymentMapper = paymentMapper;
        this.billMapper = billMapper;
    }

    @Override
    public List<Payment> list() {
        return paymentMapper.findAll();
    }

    @Override
    public Payment findById(Long id) {
        return paymentMapper.findById(id);
    }

    @Override
    @Transactional
    public Payment createPayment(Long billId, String orderNo, String channel, BigDecimal amount) {
        if (billId == null || channel == null || amount == null) {
            throw new BizException("支付参数不完整");
        }
        Payment payment = new Payment();
        payment.setPaymentNo("PAY" + LocalDateTime.now().format(
            DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS")) + RandomUtil.randomNumbers(3));
        payment.setOrderNo(orderNo);
        payment.setBillId(billId);
        payment.setChannel(channel);
        payment.setAmount(amount);
        payment.setStatus("待支付");
        payment.setRemark("沙箱环境支付单");
        payment.setCreateBy(SecurityUtil.getCurrentUsername());
        paymentMapper.insert(payment);
        log.info("支付单创建成功：{}，账单ID：{}，金额：{}", payment.getPaymentNo(), billId, amount);
        return payment;
    }

    /**
     * 沙箱支付回调：支付单置已支付，同步结算关联账单（实收 = 支付金额）
     */
    @Override
    @Transactional
    public Payment mockPayCallback(String paymentNo) {
        Payment payment = paymentMapper.findByPaymentNo(paymentNo);
        if (payment == null) {
            throw new BizException("支付单不存在");
        }
        if (!"待支付".equals(payment.getStatus())) {
            throw new BizException("支付单状态不正确");
        }
        String tradeNo = "TRADE" + UUID.randomUUID().toString().replace("-", "").substring(0, 16);
        payment.setStatus("已支付");
        payment.setTradeNo(tradeNo);
        payment.setPayTime(LocalDateTime.now());
        paymentMapper.updatePayResult(payment);

        if (payment.getBillId() != null) {
            Bill bill = billMapper.findById(payment.getBillId());
            if (bill != null && !"已结算".equals(bill.getSettleStatus())) {
                billMapper.settleWithAmount(bill.getId(), payment.getAmount());
                log.info("关联账单已自动结算，账单ID：{}，实收：{}", bill.getId(), payment.getAmount());
            }
        }
        log.info("支付回调成功，支付单号：{}，交易号：{}", paymentNo, tradeNo);
        return payment;
    }

    @Override
    @Transactional
    public Payment refund(String paymentNo) {
        Payment payment = paymentMapper.findByPaymentNo(paymentNo);
        if (payment == null) {
            throw new BizException("支付单不存在");
        }
        if (!"已支付".equals(payment.getStatus())) {
            throw new BizException("只有已支付的订单才能退款");
        }
        payment.setStatus("已退款");
        payment.setRefundTime(LocalDateTime.now());
        paymentMapper.updateRefund(payment);

        if (payment.getBillId() != null) {
            billMapper.markRefunded(payment.getBillId());
        }
        log.info("退款成功，支付单号：{}，账单ID：{}", paymentNo, payment.getBillId());
        return payment;
    }

    @Override
    public Payment findByPaymentNo(String paymentNo) {
        return paymentMapper.findByPaymentNo(paymentNo);
    }
}
