package com.hotel.pms.modules.statistics;

import com.hotel.pms.mapper.StatisticsMapper;
import com.hotel.pms.vo.StatisticsVO;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class StatisticsServiceImpl implements StatisticsService {

    private final StatisticsMapper statisticsMapper;

    public StatisticsServiceImpl(StatisticsMapper statisticsMapper) {
        this.statisticsMapper = statisticsMapper;
    }

    /**
     * 总览：各计数由 Mapper 查询，Service 负责组装 VO 与计算入住率、ADR
     */
    @Override
    public StatisticsVO overview() {
        StatisticsVO vo = new StatisticsVO();
        Integer roomTotal = statisticsMapper.countRoomTotal();
        Integer occupied = statisticsMapper.countRoomByStatus("已入住");

        vo.setRoomTotal(roomTotal);
        vo.setRoomEmpty(statisticsMapper.countRoomByStatus("空房"));
        vo.setRoomOccupied(occupied);
        vo.setRoomReserved(statisticsMapper.countRoomByStatus("已预订"));
        vo.setRoomDirty(statisticsMapper.countRoomByStatus("待清洁"));
        vo.setRoomMaintenance(statisticsMapper.countRoomByStatus("维修中"));
        vo.setMemberTotal(statisticsMapper.countMemberTotal());
        vo.setReservationToday(statisticsMapper.countReservationToday());
        vo.setCheckinActive(statisticsMapper.countCheckinActive());

        double rate = 0.0;
        if (roomTotal != null && roomTotal > 0) {
            rate = (occupied != null ? occupied : 0) * 100.0 / roomTotal;
        }
        vo.setOccupancyRate(Math.round(rate * 100.0) / 100.0);

        Double revenueMonth = statisticsMapper.revenueMonth();
        Double revenueToday = statisticsMapper.revenueToday();
        Integer roomNights = statisticsMapper.roomNightsMonth();
        double month = revenueMonth != null ? revenueMonth : 0.0;
        double adr = 0.0;
        if (roomNights != null && roomNights > 0) {
            adr = month / roomNights;
        }
        vo.setRevenueMonth(month);
        vo.setRevenueToday(revenueToday != null ? revenueToday : 0.0);
        vo.setRoomNights(roomNights != null ? roomNights : 0);
        vo.setAdr(Math.round(adr * 100.0) / 100.0);
        return vo;
    }

    @Override
    public List<Map<String, Object>> roomStatus() {
        return statisticsMapper.roomStatus();
    }

    @Override
    public List<Map<String, Object>> memberLevel() {
        return statisticsMapper.memberLevel();
    }

    @Override
    public List<Map<String, Object>> revenueTrend(String start, String end) {
        return statisticsMapper.revenueTrend(start, end);
    }
}
