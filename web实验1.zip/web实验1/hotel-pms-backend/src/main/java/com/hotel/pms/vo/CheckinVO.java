package com.hotel.pms.vo;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 入住视图对象：入住 + 房间号
 */
@Data
public class CheckinVO {
    private Long id;
    private String checkinNo;
    private Long reservationId;
    private Long roomId;
    private String roomNumber;
    private String guestName;
    private String idCard;
    private String phone;
    private BigDecimal deposit;
    private LocalDateTime checkinTime;
    private LocalDateTime checkoutTime;
    private String status;
    private String createBy;
    private LocalDateTime createTime;
}
