package com.hotel.pms.modules.checkin;

import com.hotel.pms.common.PageResult;
import com.hotel.pms.entity.Checkin;
import com.hotel.pms.vo.CheckinVO;

import java.util.List;

public interface CheckinService {

    List<CheckinVO> list();

    PageResult<CheckinVO> page(int pageNum, int pageSize, String keyword, String status);

    CheckinVO findById(Long id);

    CheckinVO checkin(Checkin checkin);

    void checkout(Long id);

    /** 编辑入住信息（姓名、身份证、手机号、押金） */
    void update(Long id, Checkin checkin);

    /** 逻辑删除（仅已退房记录允许删除） */
    void delete(Long id);
}
