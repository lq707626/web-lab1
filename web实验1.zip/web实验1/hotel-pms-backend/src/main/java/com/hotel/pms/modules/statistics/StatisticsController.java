package com.hotel.pms.modules.statistics;

import com.hotel.pms.common.Result;
import com.hotel.pms.vo.StatisticsVO;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/statistics")
public class StatisticsController {

    private final StatisticsService statisticsService;

    public StatisticsController(StatisticsService statisticsService) {
        this.statisticsService = statisticsService;
    }

    /**
     * 总览指标（VO）
     */
    @GetMapping("/overview")
    public Result<StatisticsVO> overview() {
        return Result.success(statisticsService.overview());
    }

    @GetMapping("/room-status")
    public Result<List<Map<String, Object>>> roomStatus() {
        return Result.success(statisticsService.roomStatus());
    }

    @GetMapping("/member-level")
    public Result<List<Map<String, Object>>> memberLevel() {
        return Result.success(statisticsService.memberLevel());
    }

    /**
     * 营收趋势（默认近 7 天，支持 start/end）
     */
    @GetMapping("/revenue-trend")
    public Result<List<Map<String, Object>>> revenueTrend(
            @RequestParam(required = false) String start,
            @RequestParam(required = false) String end) {
        return Result.success(statisticsService.revenueTrend(start, end));
    }
}
