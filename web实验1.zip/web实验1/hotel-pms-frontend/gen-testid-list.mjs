import { readFileSync, writeFileSync, readdirSync, statSync } from 'node:fs'
import { join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'
import { parse } from '@vue/compiler-sfc'

const expansions = {
  'layout-menu': ['room', 'reservation', 'checkin', 'bill', 'cashier', 'member', 'statistics', 'employee', 'third-party'],
  'room-filter': ['empty', 'occupied', 'reserved', 'repair', 'cleaning'],
  'statistics-card': ['revenue-today', 'revenue-month', 'occupancy-rate', 'adr', 'room-total', 'checkin-active', 'reservation-today', 'member-total'],
  'statistics-value': ['revenue-today', 'revenue-month', 'occupancy-rate', 'adr', 'room-total', 'checkin-active', 'reservation-today', 'member-total'],
  'cashier-pay-method': ['cash', 'wechat', 'alipay', 'bankcard', 'member']
}

const staticTestids = new Set()
const testidRegex = /data-testid="([^"]+)"/g

const root = fileURLToPath(new URL('./src/', import.meta.url))

function walk(dir) {
  const out = []
  for (const name of readdirSync(dir)) {
    const full = join(dir, name)
    if (statSync(full).isDirectory()) out.push(...walk(full))
    else if (name.endsWith('.vue')) out.push(full)
  }
  return out
}

for (const file of walk(root)) {
  const source = readFileSync(file, 'utf8')
  const { descriptor } = parse(source, { filename: file })
  const template = descriptor.template?.content || ''
  let m
  while ((m = testidRegex.exec(template)) !== null) {
    const val = m[1]
    // 跳过动态模板表达式本身
    if (val.includes('${')) continue
    staticTestids.add(val)
  }
}

// 加入动态展开值
for (const [prefix, codes] of Object.entries(expansions)) {
  for (const code of codes) {
    staticTestids.add(`${prefix}-${code}`)
  }
}

const sorted = [...staticTestids].sort((a, b) => a.localeCompare(b, 'en'))
writeFileSync('testid-list.md', sorted.join('\n') + '\n', 'utf8')
console.log(`已生成 testid-list.md，共 ${sorted.length} 条`)
