package com.hotel.pms.modules.payment;

import com.hotel.pms.entity.Payment;

import java.math.BigDecimal;
import java.util.List;

public interface PaymentService {

    List<Payment> list();

    Payment findById(Long id);

    Payment createPayment(Long billId, String orderNo, String channel, BigDecimal amount);

    Payment mockPayCallback(String paymentNo);

    Payment refund(String paymentNo);

    Payment findByPaymentNo(String paymentNo);
}
