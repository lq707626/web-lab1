package com.hotel.pms.vo;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 账单视图对象：账单 + 客人/房间（联查） + 支付单（用于退款） + 明细
 */
@Data
public class BillVO {
    private Long id;
    private String billNo;
    private Long checkinId;
    private BigDecimal receivableAmount;
    private BigDecimal actualAmount;
    private BigDecimal depositDeduct;
    private String settleStatus;
    private LocalDateTime settleTime;
    private LocalDateTime createTime;

    private String guestName;
    private String roomNumber;
    private String checkinNo;

    private String paymentNo;
    private String paymentChannel;

    private List<BillItemVO> items;
}
