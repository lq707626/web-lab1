import pymysql
conn = pymysql.connect(host='your-vm-ip', user='root', password='your_password',
                       database='mydb', charset='utf8mb4')
cur = conn.cursor()

# 清掉测试造的员工（保留5个种子账号）
cur.execute("UPDATE employee SET is_deleted=1 WHERE username NOT IN ('admin','front','cashier','manager','gm')")
print(f'清理测试员工: {cur.rowcount} rows')

conn.commit()

cur.execute("SELECT id, username, name, role FROM employee WHERE is_deleted=0 ORDER BY id")
for r in cur.fetchall():
    print(r)

cur.close()
conn.close()
