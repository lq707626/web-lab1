package com.hotel.pms.modules.room;

import com.hotel.pms.common.Result;
import com.hotel.pms.vo.RoomVO;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/rooms")
public class RoomController {

    private final RoomService roomService;

    public RoomController(RoomService roomService) {
        this.roomService = roomService;
    }

    /**
     * 房间列表（VO：房间 + 房型 + 门锁 + 设施）
     */
    @GetMapping
    public Result<List<RoomVO>> list() {
        return Result.success(roomService.list());
    }

    @GetMapping("/{id}")
    public Result<RoomVO> findById(@PathVariable Long id) {
        return Result.success(roomService.findById(id));
    }

    /**
     * 修改房态（携带 version 做乐观锁）
     */
    @PutMapping("/{id}/status")
    public Result<?> updateStatus(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        String status = (String) body.get("status");
        Integer version = body.get("version") != null
            ? Integer.valueOf(body.get("version").toString()) : 0;
        roomService.updateStatus(id, status, version);
        return Result.success();
    }
}
