package com.hotel.pms.mapper;

import com.hotel.pms.entity.Employee;
import com.hotel.pms.vo.EmployeeVO;
import org.apache.ibatis.annotations.*;
import java.util.List;

public interface EmployeeMapper {
    @Select("SELECT * FROM employee WHERE username = #{username} AND is_deleted = 0")
    Employee findByUsername(@Param("username") String username);

    @Select("SELECT * FROM employee WHERE is_deleted = 0 ORDER BY create_time DESC")
    List<Employee> findAll();

    @Select("SELECT * FROM employee WHERE id = #{id} AND is_deleted = 0")
    Employee findById(@Param("id") Long id);

    @Insert("INSERT INTO employee(username, password, name, role, create_by) " +
            "VALUES(#{username}, #{password}, #{name}, #{role}, #{createBy})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Employee employee);

    @Update("UPDATE employee SET name = #{name}, role = #{role}, " +
            "password = CASE WHEN #{password} IS NOT NULL AND #{password} != '' THEN #{password} ELSE password END, " +
            "update_time = NOW() WHERE id = #{id} AND is_deleted = 0")
    int update(Employee employee);

    /**
     * 逻辑删除（禁用）：同时给 username 追加删除后缀，避免唯一索引与"重新添加同名账号"冲突
     * 对应报告 3.4「软删除与唯一字段冲突」的处理方式
     */
    @Update("UPDATE employee SET is_deleted = 1, " +
            "username = CONCAT(username, '_del_', UNIX_TIMESTAMP()), " +
            "update_time = NOW() WHERE id = #{id} AND is_deleted = 0")
    int delete(@Param("id") Long id);

    /* ========== 以下方法由 EmployeeMapper.xml 实现（条件分页） ========== */

    List<EmployeeVO> findPageVO(@Param("offset") int offset,
                                @Param("size") int size,
                                @Param("keyword") String keyword,
                                @Param("role") String role);

    long countVO(@Param("keyword") String keyword, @Param("role") String role);
}
