package com.hotel.pms.mapper;

import com.hotel.pms.entity.MemberTransaction;
import org.apache.ibatis.annotations.*;
import java.util.List;

public interface MemberTransactionMapper {

    @Select("SELECT * FROM member_transaction WHERE member_id = #{memberId} " +
            "ORDER BY create_time DESC")
    List<MemberTransaction> findByMemberId(@Param("memberId") Long memberId);

    @Insert("INSERT INTO member_transaction(member_id, type, amount, balance_after, " +
            "points_after, remark) VALUES(#{memberId}, #{type}, #{amount}, " +
            "#{balanceAfter}, #{pointsAfter}, #{remark})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(MemberTransaction transaction);
}
