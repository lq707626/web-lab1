package com.hotel.pms.mapper;

import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 报表统计 Mapper：把原来写在 StatisticsService 里的 SQL 全部下沉到数据访问层
 */
public interface StatisticsMapper {

    Integer countRoomTotal();

    Integer countRoomByStatus(@Param("status") String status);

    Integer countMemberTotal();

    Integer countReservationToday();

    Integer countCheckinActive();

    Double revenueMonth();

    Double revenueToday();

    Integer roomNightsMonth();

    List<Map<String, Object>> roomStatus();

    List<Map<String, Object>> memberLevel();

    List<Map<String, Object>> revenueTrend(@Param("start") String start,
                                           @Param("end") String end);
}
