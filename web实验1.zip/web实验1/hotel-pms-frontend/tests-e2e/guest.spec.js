// 游客门户 E2E
// 对应用例：报告 7.2.11 游客门户测试
import { test, expect } from '@playwright/test'
import { expectMessage, uniquePhone, futureDate } from './helpers/auth.js'

test.describe('游客门户', () => {
  test.beforeEach(async ({ page }) => {
    // 不登录，直接访问 /guest
    await page.goto('/guest')
    await page.getByTestId('guest-tabs').waitFor({ state: 'visible' })
  })

  test('免登录访问：/guest 不跳登录页', async ({ page }) => {
    await page.getByTestId('guest-tabs').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/guest-01-access.png', fullPage: true })
  })

  test('房型展示：房型卡片渲染，带价格和可售数', async ({ page }) => {
    await page.getByTestId('guest-roomtype-card').first().waitFor({ state: 'visible' })
    await expect(page.getByTestId('guest-roomtype-card').first()).toContainText('¥')
    await page.screenshot({ path: 'tests-e2e/screenshots/guest-02-roomtypes.png', fullPage: true })
  })

  test('实时房态 tab：切过去显示房间卡片', async ({ page }) => {
    await page.getByTestId('guest-tabs').locator('text=实时房态').click()
    await page.getByTestId('guest-room-card').first().waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/guest-03-rooms.png', fullPage: true })
  })

  test('游客下单：选房型、填信息提交，弹出订单号与查询码', async ({ page }) => {
    await page.getByTestId('guest-roomtype-card').first().waitFor({ state: 'visible' })
    await page.getByTestId('guest-book-btn').first().click()

    await page.getByTestId('guest-book-dialog').waitFor({ state: 'visible' })
    // 默认已填好今天/明天，直接填姓名手机
    await page.getByTestId('guest-book-name-input').fill('游客测试')
    await page.getByTestId('guest-book-phone-input').fill(uniquePhone())
    await page.screenshot({ path: 'tests-e2e/screenshots/guest-04-book-dialog.png', fullPage: true })
    await page.getByTestId('guest-book-submit-btn').click()

    // 成功弹窗
    await page.getByTestId('guest-result-dialog').waitFor({ state: 'visible', timeout: 10_000 })
    await expect(page.getByTestId('guest-result-dialog')).toContainText('订单号')
    await expect(page.getByTestId('guest-result-dialog')).toContainText('查询码')
    await page.screenshot({ path: 'tests-e2e/screenshots/guest-04-book-success.png', fullPage: true })
    await page.getByTestId('guest-result-ok-btn').click()
  })

  test('手机号校验：非 11 位不提交', async ({ page }) => {
    await page.getByTestId('guest-roomtype-card').first().waitFor({ state: 'visible' })
    await page.getByTestId('guest-book-btn').first().click()
    await page.getByTestId('guest-book-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('guest-book-name-input').fill('校验')
    await page.getByTestId('guest-book-phone-input').fill('123')
    await page.getByTestId('guest-book-submit-btn').click()
    await expect(page.locator('.el-form-item__error').first()).toContainText(/手机号/)
    await page.screenshot({ path: 'tests-e2e/screenshots/guest-05-phone-invalid.png', fullPage: true })
  })

  test('订单查询：切到订单查询 tab，输入手机号和查询码', async ({ page }) => {
    await page.getByTestId('guest-tabs').locator('text=订单查询').click()
    await page.getByTestId('guest-query-phone-input').waitFor({ state: 'visible' })
    await page.getByTestId('guest-query-phone-input').fill('13800138000')
    await page.getByTestId('guest-query-code-input').fill('000000')
    await page.getByTestId('guest-query-btn').click()
    // 错误查询码应提示
    await page.screenshot({ path: 'tests-e2e/screenshots/guest-07-query.png', fullPage: true })
  })

  test('查询码错误：提示未找到订单', async ({ page }) => {
    await page.getByTestId('guest-tabs').locator('text=订单查询').click()
    await page.getByTestId('guest-query-phone-input').waitFor({ state: 'visible' })
    await page.getByTestId('guest-query-phone-input').fill('13800138000')
    await page.getByTestId('guest-query-code-input').fill('999999')
    await page.getByTestId('guest-query-btn').click()
    // 后端返回错误时 queryResult 为空，ElMessage.warning 提示
    await page.waitForTimeout(1000)
    await page.screenshot({ path: 'tests-e2e/screenshots/guest-08-query-fail.png', fullPage: true })
  })

  test('员工登录入口：点"员工登录"跳转 /login', async ({ page }) => {
    await page.getByTestId('guest-login-btn').click()
    await page.waitForURL(/\/login/, { timeout: 5_000 })
    await page.getByTestId('login-username-input').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/guest-09-to-login.png', fullPage: true })
  })
})
