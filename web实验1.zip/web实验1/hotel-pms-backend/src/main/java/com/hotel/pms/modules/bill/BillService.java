package com.hotel.pms.modules.bill;

import com.hotel.pms.common.PageResult;
import com.hotel.pms.entity.Bill;
import com.hotel.pms.vo.BillVO;

import java.math.BigDecimal;
import java.util.List;

public interface BillService {

    List<BillVO> list();

    PageResult<BillVO> page(int pageNum, int pageSize, String keyword, String status);

    BillVO detail(Long id);

    /** 入住单 -> 账单（1:1 查询） */
    BillVO findByCheckinId(Long checkinId);

    BillVO create(Bill bill);

    void settle(Long id, BigDecimal actualAmount);
}
