// 收银结算模块 E2E
// 对应用例：报告 7.2.6 收银结算模块测试
import { test, expect } from '@playwright/test'
import { loginAsAdmin, expectMessage } from './helpers/auth.js'

test.describe('收银结算', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page, '/cashier')
  })

  test('收银列表展示：4 张统计卡片可见', async ({ page }) => {
    await page.getByTestId('cashier-pending-count').waitFor({ state: 'visible' })
    await page.getByTestId('cashier-pending-amount').waitFor({ state: 'visible' })
    await page.getByTestId('cashier-today-amount').waitFor({ state: 'visible' })
    await page.getByTestId('cashier-today-settled').waitFor({ state: 'visible' })
    await page.getByTestId('cashier-table').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/cashier-01-list.png', fullPage: true })
  })

  test('日结统计：点击按钮弹出日结对话框', async ({ page }) => {
    await page.getByTestId('cashier-daily-btn').click()
    await page.getByTestId('cashier-daily-dialog').waitFor({ state: 'visible' })
    await expect(page.getByTestId('cashier-daily-table')).toBeVisible()
    await page.screenshot({ path: 'tests-e2e/screenshots/cashier-09-daily.png', fullPage: true })
    await page.getByTestId('cashier-daily-close-btn').click()
  })

  test('现金收款：打开收款弹窗，选现金，实收=应收，提示成功', async ({ page }) => {
    await page.getByTestId('cashier-table').waitFor({ state: 'visible' })
    const rows = page.getByTestId('cashier-row')
    if ((await rows.count()) === 0) {
      test.info().annotations.push({ type: 'skip', description: '当前无待结算账单' })
      return
    }
    await rows.first().getByTestId('cashier-pay-btn').click()
    await page.getByTestId('cashier-pay-dialog').waitFor({ state: 'visible' })
    // 默认现金，实收默认填应付
    await page.getByTestId('cashier-cash-received-input').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/cashier-02-cash-dialog.png', fullPage: true })
    await page.getByTestId('cashier-pay-submit-btn').click()
    await expectMessage(page, '现金收款成功')
    await page.screenshot({ path: 'tests-e2e/screenshots/cashier-02-cash-success.png', fullPage: true })
  })

  test('实收金额不足时提示错误，不结算', async ({ page }) => {
    await page.getByTestId('cashier-table').waitFor({ state: 'visible' })
    const rows = page.getByTestId('cashier-row')
    if ((await rows.count()) === 0) {
      test.info().annotations.push({ type: 'skip', description: '当前无待结算账单' })
      return
    }
    await rows.first().getByTestId('cashier-pay-btn').click()
    await page.getByTestId('cashier-pay-dialog').waitFor({ state: 'visible' })
    // 把实收改成 0.01（远小于应付）
    await page.getByTestId('cashier-cash-received-input').locator('input').fill('0.01')
    await page.getByTestId('cashier-pay-submit-btn').click()
    const err = page.locator('.el-message--error').last()
    await err.waitFor({ state: 'visible', timeout: 8_000 })
    await expect(err).toContainText(/实收金额不足/)
    await page.screenshot({ path: 'tests-e2e/screenshots/cashier-03-insufficient.png', fullPage: true })
  })

  test('银行卡收款：选银行卡，确认收款成功', async ({ page }) => {
    await page.getByTestId('cashier-table').waitFor({ state: 'visible' })
    const rows = page.getByTestId('cashier-row')
    if ((await rows.count()) === 0) {
      test.info().annotations.push({ type: 'skip', description: '当前无待结算账单' })
      return
    }
    await rows.first().getByTestId('cashier-pay-btn').click()
    await page.getByTestId('cashier-pay-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('cashier-pay-method-bankcard').click()
    await page.screenshot({ path: 'tests-e2e/screenshots/cashier-06-bankcard.png', fullPage: true })
    await page.getByTestId('cashier-pay-submit-btn').click()
    await expectMessage(page, '银行卡收款成功')
  })

  test('搜索过滤：输入不存在的关键字，列表为空', async ({ page }) => {
    await page.getByTestId('cashier-keyword-input').fill('BILL-NOT-EXIST-E2E')
    await page.waitForTimeout(500)
    await page.getByTestId('cashier-table').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/cashier-search-empty.png', fullPage: true })
  })
})
