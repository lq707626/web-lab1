<template>
  <div>
    <el-card shadow="never">
      <div class="toolbar">
        <div class="filters">
          <el-input
            v-model="keyword"
            placeholder="按账单号 / 客人姓名 / 房间号查询"
            clearable
            style="width: 280px"
            :prefix-icon="Search"
            data-testid="bill-keyword-input"
          />
          <el-select
            v-model="statusFilter"
            placeholder="全部状态"
            clearable
            style="width: 140px"
            data-testid="bill-status-select"
          >
            <el-option label="未结算" value="未结算" />
            <el-option label="已结算" value="已结算" />
            <el-option label="已退款" value="已退款" />
          </el-select>
        </div>
        <div class="summary">
          共 {{ filteredList.length }} 张账单，待结算 {{ pendingCount }} 张，待收 ¥{{ money(pendingAmount) }}
        </div>
      </div>

      <el-table
        :data="filteredList"
        border
        stripe
        v-loading="loading"
        empty-text="暂无账单数据"
        data-testid="bill-table"
      >
        <el-table-column prop="billNo" label="账单号" width="190" />
        <el-table-column label="客人" width="100">
          <template #default="{ row }">{{ row.guestName || '-' }}</template>
        </el-table-column>
        <el-table-column label="房间号" width="90">
          <template #default="{ row }">{{ row.roomNumber || '-' }}</template>
        </el-table-column>
        <el-table-column label="应收金额" width="110">
          <template #default="{ row }">¥{{ money(row.receivableAmount) }}</template>
        </el-table-column>
        <el-table-column label="押金抵扣" width="110">
          <template #default="{ row }">¥{{ money(row.depositDeduct) }}</template>
        </el-table-column>
        <el-table-column label="实收金额" width="110">
          <template #default="{ row }">¥{{ money(row.actualAmount) }}</template>
        </el-table-column>
        <el-table-column label="结算状态" width="100">
          <template #default="{ row }">
            <el-tag :type="billStatusType(row.settleStatus)">{{ row.settleStatus }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="结算时间" width="160">
          <template #default="{ row }">{{ formatTime(row.settleTime) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="220" fixed="right">
          <template #default="{ row }">
            <div class="row-actions" data-testid="bill-row" :data-bill-id="row.id">
              <el-button
                size="small"
                data-testid="bill-detail-btn"
                @click="showDetail(row)"
              >
                明细
              </el-button>
              <el-button
                v-if="row.settleStatus !== '已结算' && row.settleStatus !== '已退款'"
                size="small"
                type="primary"
                :loading="isPending(row, 'settle')"
                data-testid="bill-settle-btn"
                @click="settle(row)"
              >
                结算
              </el-button>
              <el-button
                v-if="row.settleStatus === '已结算' && row.paymentNo"
                size="small"
                type="danger"
                plain
                :loading="isPending(row, 'refund')"
                data-testid="bill-refund-btn"
                @click="refund(row)"
              >
                退款
              </el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="detailVisible" title="账单明细" width="680px" data-testid="bill-detail-dialog">
      <template v-if="currentBill">
        <el-descriptions :column="2" border size="small">
          <el-descriptions-item label="账单号">{{ currentBill.billNo }}</el-descriptions-item>
          <el-descriptions-item label="客人">{{ currentBill.guestName || '-' }}</el-descriptions-item>
          <el-descriptions-item label="房间号">{{ currentBill.roomNumber || '-' }}</el-descriptions-item>
          <el-descriptions-item label="结算状态">
            <el-tag :type="billStatusType(currentBill.settleStatus)">{{ currentBill.settleStatus }}</el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="创建时间">{{ formatTime(currentBill.createTime) }}</el-descriptions-item>
          <el-descriptions-item label="结算时间">{{ formatTime(currentBill.settleTime) }}</el-descriptions-item>
        </el-descriptions>

        <el-table
          :data="currentBill.items || []"
          border
          size="small"
          style="margin-top: 14px"
          empty-text="暂无消费明细"
          data-testid="bill-detail-items-table"
        >
          <el-table-column prop="itemType" label="消费项目" width="130" />
          <el-table-column label="单价" width="110">
            <template #default="{ row }">¥{{ money(row.amount) }}</template>
          </el-table-column>
          <el-table-column prop="quantity" label="数量" width="80" align="center" />
          <el-table-column label="小计" width="110">
            <template #default="{ row }">¥{{ money(Number(row.amount) * Number(row.quantity || 1)) }}</template>
          </el-table-column>
          <el-table-column prop="payMethod" label="支付方式" />
        </el-table>

        <el-descriptions :column="1" border size="small" style="margin-top: 14px">
          <el-descriptions-item label="明细合计">¥{{ money(itemsTotal) }}</el-descriptions-item>
          <el-descriptions-item label="押金抵扣">¥{{ money(currentBill.depositDeduct) }}</el-descriptions-item>
          <el-descriptions-item label="应收金额">¥{{ money(currentBill.receivableAmount) }}</el-descriptions-item>
          <el-descriptions-item label="实收金额">¥{{ money(currentBill.actualAmount) }}</el-descriptions-item>
        </el-descriptions>
      </template>
      <template #footer>
        <el-button data-testid="bill-detail-close-btn" @click="detailVisible = false">关闭</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search } from '@element-plus/icons-vue'
import api from '../api'
import { billStatusType, money } from '../utils/format'
import { useRowAction } from '../utils/useRowAction'

const list = ref([])
const loading = ref(false)
const keyword = ref('')
const statusFilter = ref('')
const detailVisible = ref(false)
const currentBill = ref(null)

const { isPending, run } = useRowAction()

const filteredList = computed(() => {
  const kw = keyword.value.trim()
  return list.value.filter(item => {
    const hitKeyword =
      !kw ||
      String(item.billNo || '').includes(kw) ||
      String(item.guestName || '').includes(kw) ||
      String(item.roomNumber || '').includes(kw)
    const hitStatus = !statusFilter.value || item.settleStatus === statusFilter.value
    return hitKeyword && hitStatus
  })
})

const pendingList = computed(() =>
  list.value.filter(item => item.settleStatus !== '已结算' && item.settleStatus !== '已退款')
)

const pendingCount = computed(() => pendingList.value.length)

const pendingAmount = computed(() =>
  pendingList.value.reduce((sum, item) => sum + payableOf(item), 0)
)

const itemsTotal = computed(() => {
  if (!currentBill.value?.items) return 0
  return currentBill.value.items.reduce(
    (sum, item) => sum + Number(item.amount || 0) * Number(item.quantity || 1),
    0
  )
})

function payableOf(bill) {
  const receivable = Number(bill.receivableAmount || 0)
  const deposit = Number(bill.depositDeduct || 0)
  return Math.max(0, Math.round((receivable - deposit) * 100) / 100)
}

function formatTime(value) {
  if (!value) return '-'
  return String(value).replace('T', ' ').slice(0, 19)
}

async function load() {
  loading.value = true
  try {
    const res = await api.get('/bills')
    list.value = res.data || []
  } finally {
    loading.value = false
  }
}

async function showDetail(row) {
  const res = await api.get(`/bills/${row.id}`)
  currentBill.value = res.data
  detailVisible.value = true
}

async function settle(row) {
  if (row.settleStatus === '已结算') {
    ElMessage.warning('已结算账单不可修改')
    return
  }
  if (row.settleStatus === '已退款') {
    ElMessage.warning('已退款账单不能再次结算')
    return
  }
  const payable = payableOf(row)
  try {
    await ElMessageBox.confirm('确认结算该账单？', '账单结算', { type: 'warning' })
  } catch (e) {
    return
  }
  await run(row, 'settle', async () => {
    // 显式回写实收金额，保证营收统计与收银日结口径正确
    await api.put(`/bills/${row.id}/settle`, { actualAmount: payable })
    ElMessage.success('结算成功，账单状态已更新为已结算')
    await load()
  })
}

/**
 * 退款：仅线上支付（微信/支付宝）的已结算账单有 paymentNo，退款后账单状态变为已退款
 */
async function refund(row) {
  if (!row.paymentNo) {
    ElMessage.warning('该账单没有可退款的线上支付记录')
    return
  }
  try {
    await ElMessageBox.confirm('确认退款该账单？退款后账单状态变为已退款。', '账单退款', { type: 'warning' })
  } catch (e) {
    return
  }
  await run(row, 'refund', async () => {
    await api.put(`/payment/refund/${row.paymentNo}`)
    ElMessage.success('退款成功，账单已标记为已退款')
    await load()
  })
}

onMounted(load)
</script>

<style scoped>
.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  gap: 12px;
  flex-wrap: wrap;
}
.filters {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}
.row-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.row-actions :deep(.el-button + .el-button) {
  margin-left: 0;
}
.summary {
  color: #606266;
  font-size: 13px;
}
</style>