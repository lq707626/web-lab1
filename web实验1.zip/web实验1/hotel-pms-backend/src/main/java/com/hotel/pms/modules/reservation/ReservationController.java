package com.hotel.pms.modules.reservation;

import com.hotel.pms.common.PageResult;
import com.hotel.pms.common.Result;
import com.hotel.pms.entity.Reservation;
import com.hotel.pms.vo.ReservationVO;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reservations")
public class ReservationController {

    private final ReservationService reservationService;

    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    /**
     * 全量列表（保留给接口测试脚本使用）
     */
    @GetMapping
    public Result<List<ReservationVO>> list() {
        return Result.success(reservationService.list());
    }

    /**
     * 条件分页：keyword（订单号/姓名/手机号）、status
     */
    @GetMapping("/page")
    public Result<PageResult<ReservationVO>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String status) {
        return Result.success(reservationService.page(pageNum, pageSize, keyword, status));
    }

    @PostMapping
    public Result<ReservationVO> create(@RequestBody Reservation reservation) {
        return Result.success(reservationService.create(reservation));
    }

    /**
     * 预订详情（与其他资源详情接口保持一致）
     */
    @GetMapping("/{id}")
    public Result<ReservationVO> detail(@PathVariable Long id) {
        return Result.success(reservationService.findById(id));
    }

    @PutMapping("/{id}")
    public Result<?> update(@PathVariable Long id, @RequestBody Reservation reservation) {
        reservationService.update(id, reservation);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    public Result<?> delete(@PathVariable Long id) {
        reservationService.delete(id);
        return Result.success();
    }

    @PutMapping("/{id}/confirm")
    public Result<?> confirm(@PathVariable Long id) {
        reservationService.confirm(id);
        return Result.success();
    }

    @PutMapping("/{id}/cancel")
    public Result<?> cancel(@PathVariable Long id,
                            @RequestBody(required = false) Map<String, String> body) {
        reservationService.cancel(id, body == null ? null : body.get("reason"));
        return Result.success();
    }
}
