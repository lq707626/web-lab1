import { createRouter, createWebHistory } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useUserStore } from '../store/user'
import { ALL_ROLES, ROLE_ADMIN, ROLE_CASHIER, ROLE_FRONT, ROLE_GENERAL, ROLE_MANAGER } from '../utils/permission'

const routes = [
  { path: '/login', component: () => import('../views/Login.vue'), meta: { public: true, title: '登录' } },
  { path: '/guest', component: () => import('../views/Guest.vue'), meta: { public: true, title: '在线预订' } },
  {
    path: '/',
    component: () => import('../views/Layout.vue'),
    redirect: () => {
      const userStore = useUserStore()
      return userStore.homePath
    },
    children: [
      {
        path: 'room',
        alias: ['/rooms'],
        name: '房态管理',
        component: () => import('../views/RoomStatus.vue'),
        meta: { roles: [ROLE_ADMIN, ROLE_FRONT, ROLE_MANAGER] }
      },
      {
        path: 'reservation',
        alias: ['/reservations'],
        name: '预订管理',
        component: () => import('../views/Reservation.vue'),
        meta: { roles: [ROLE_ADMIN, ROLE_FRONT] }
      },
      {
        path: 'checkin',
        alias: ['/checkins'],
        name: '入住管理',
        component: () => import('../views/Checkin.vue'),
        meta: { roles: [ROLE_ADMIN, ROLE_FRONT] }
      },
      {
        path: 'bill',
        alias: ['/bills'],
        name: '账单结算',
        component: () => import('../views/Bill.vue'),
        meta: { roles: [ROLE_ADMIN, ROLE_CASHIER] }
      },
      {
        path: 'cashier',
        name: '收银结算',
        component: () => import('../views/Cashier.vue'),
        meta: { roles: [ROLE_ADMIN, ROLE_CASHIER] }
      },
      {
        path: 'member',
        alias: ['/members'],
        name: '会员管理',
        component: () => import('../views/Member.vue'),
        meta: { roles: [ROLE_ADMIN, ROLE_FRONT] }
      },
      {
        path: 'statistics',
        name: '报表统计',
        component: () => import('../views/Statistics.vue'),
        meta: { roles: [ROLE_ADMIN, ROLE_MANAGER, ROLE_GENERAL] }
      },
      {
        path: 'employee',
        alias: ['/employees'],
        name: '员工管理',
        component: () => import('../views/Employee.vue'),
        meta: { roles: [ROLE_ADMIN] }
      },
      {
        path: 'third-party',
        alias: ['/thirdparty'],
        name: '第三方对接',
        component: () => import('../views/ThirdParty.vue'),
        meta: { roles: [ROLE_ADMIN] }
      }
    ]
  },
  { path: '/:pathMatch(.*)*', redirect: '/' }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach(to => {
  const userStore = useUserStore()

  // 公开页面：登录页 / 游客门户
  if (to.meta.public) {
    if (to.path === '/login' && userStore.token && userStore.homePath !== '/login') {
      return userStore.homePath
    }
    return true
  }

  // 未登录访问受保护页面 -> 登录页（报告 6.2.1 未登录直接访问）
  if (!userStore.token) {
    return { path: '/login', query: { redirect: to.fullPath } }
  }

  // 角色不在已知角色表中：清空会话，避免死循环
  if (!ALL_ROLES.includes(userStore.role)) {
    userStore.logout()
    return { path: '/login' }
  }

  // 菜单 / 路由级权限控制（报告 2.1.2、6.2.9）
  if (to.meta.roles && !to.meta.roles.includes(userStore.role)) {
    ElMessage.warning('当前角色无权访问该页面')
    return userStore.homePath
  }

  return true
})

router.afterEach(to => {
  document.title = to.meta.title ? `${to.meta.title} - 酒店PMS管理系统` : '酒店PMS管理系统'
})

export default router
