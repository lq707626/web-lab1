package com.hotel.pms.modules.member;

import com.hotel.pms.common.PageResult;
import com.hotel.pms.entity.Member;
import com.hotel.pms.entity.MemberTransaction;
import com.hotel.pms.vo.MemberVO;

import java.math.BigDecimal;
import java.util.List;

public interface MemberService {

    List<MemberVO> list();

    PageResult<MemberVO> page(int pageNum, int pageSize, String keyword, String level);

    MemberVO findById(Long id);

    MemberVO create(Member member);

    void update(Long id, Member member);

    void delete(Long id);

    void addPoints(Long memberId, Integer points);

    void addBalance(Long memberId, BigDecimal amount);

    void consumeBalance(Long memberId, BigDecimal amount);

    List<MemberTransaction> getTransactions(Long memberId);

    Member findByPhone(String phone);
}
