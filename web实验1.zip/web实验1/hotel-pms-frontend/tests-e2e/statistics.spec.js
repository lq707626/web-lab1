// 报表统计模块 E2E
// 对应用例：报告 7.2.8 报表统计模块测试
import { test, expect } from '@playwright/test'
import { loginAsAdmin, expectMessage } from './helpers/auth.js'

test.describe('报表统计', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page, '/statistics')
  })

  test('8 张指标卡全部渲染', async ({ page }) => {
    await page.getByTestId('statistics-value-revenue-today').waitFor({ state: 'visible' })
    await page.getByTestId('statistics-value-revenue-month').waitFor({ state: 'visible' })
    await page.getByTestId('statistics-value-occupancy-rate').waitFor({ state: 'visible' })
    await page.getByTestId('statistics-value-adr').waitFor({ state: 'visible' })
    await page.getByTestId('statistics-value-room-total').waitFor({ state: 'visible' })
    await page.getByTestId('statistics-value-checkin-active').waitFor({ state: 'visible' })
    await page.getByTestId('statistics-value-reservation-today').waitFor({ state: 'visible' })
    await page.getByTestId('statistics-value-member-total').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/statistics-01-cards.png', fullPage: true })
  })

  test('房态分布饼图渲染', async ({ page }) => {
    await page.getByTestId('statistics-status-chart').waitFor({ state: 'visible' })
    await expect(page.getByTestId('statistics-status-chart')).toBeVisible()
    await page.screenshot({ path: 'tests-e2e/screenshots/statistics-02-pie.png', fullPage: true })
  })

  test('会员等级柱状图渲染', async ({ page }) => {
    await page.getByTestId('statistics-member-chart').waitFor({ state: 'visible' })
    await expect(page.getByTestId('statistics-member-chart')).toBeVisible()
    await page.screenshot({ path: 'tests-e2e/screenshots/statistics-03-bar.png', fullPage: true })
  })

  test('营收趋势折线图渲染', async ({ page }) => {
    await page.getByTestId('statistics-trend-chart').waitFor({ state: 'visible' })
    await expect(page.getByTestId('statistics-trend-chart')).toBeVisible()
    await page.screenshot({ path: 'tests-e2e/screenshots/statistics-04-trend.png', fullPage: true })
  })

  test('日期范围选择器可见，切换后图表重新加载', async ({ page }) => {
    // el-date-picker 的 data-testid 不转发到 DOM，用 placeholder 定位
    await page.getByPlaceholder('开始日期').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/statistics-05-date-picker.png', fullPage: true })
  })

  test('报表权限：总经理 gm 可以访问报表页', async ({ page }) => {
    // 先清掉 admin 登录态，再用 gm 登录
    await page.evaluate(() => { localStorage.clear() })
    await page.goto('/login')
    await page.getByTestId('login-username-input').fill('gm')
    await page.getByTestId('login-password-input').fill('123456')
    await page.getByTestId('login-submit-btn').click()
    await expectMessage(page, '登录成功')
    await page.getByTestId('statistics-value-revenue-today').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/statistics-07-gm-access.png', fullPage: true })
  })
})
