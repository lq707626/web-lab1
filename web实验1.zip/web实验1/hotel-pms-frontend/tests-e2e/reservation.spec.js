// 预订管理模块 E2E
// 对应用例：报告 7.2.3 预订管理模块测试
import { test, expect } from '@playwright/test'
import {
  loginAsAdmin,
  expectMessage,
  confirmMessageBox,
  selectOption,
  uniquePhone,
  uniqueName,
  futureDate
} from './helpers/auth.js'

/**
 * 在 el-date-picker 里直接输入日期并回车。
 * Element Plus 的 date-picker 支持键盘输入 YYYY-MM-DD。
 * testid 在 el-date-picker 上不转发到 DOM，改用 placeholder 定位。
 */
async function fillDate(page, placeholder, dateStr) {
  await page.getByPlaceholder(placeholder).click()
  await page.keyboard.type(dateStr)
  await page.keyboard.press('Enter')
}

test.describe('预订管理', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page, '/reservation')
  })

  test('新增预订：填写姓名/手机号/房型/日期后提交成功', async ({ page }) => {
    const phone = uniquePhone()
    const name = uniqueName('E2E预订')
    const inDate = futureDate(10)
    const outDate = futureDate(12)

    await page.getByTestId('reservation-add-btn').click()
    await page.getByTestId('reservation-add-dialog').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/reservation-01-add-dialog.png', fullPage: true })

    await page.getByTestId('reservation-add-name-input').fill(name)
    await page.getByTestId('reservation-add-phone-input').fill(phone)
    await selectOption(page, 'reservation-add-roomtype-select', '大床房')
    await fillDate(page, '选择入住日期', inDate)
    await fillDate(page, '选择离店日期', outDate)

    await page.getByTestId('reservation-add-submit-btn').click()
    await expectMessage(page, '预订成功')

    // 搜出来确认
    await page.getByTestId('reservation-keyword-input').fill(phone)
    await page.getByTestId('reservation-search-btn').click()
    await page.getByTestId('reservation-row').first().waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/reservation-01-add-success.png', fullPage: true })
  })

  test('手机号格式错误时前端校验拦截', async ({ page }) => {
    await page.getByTestId('reservation-add-btn').click()
    await page.getByTestId('reservation-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('reservation-add-name-input').fill('格式校验')
    await page.getByTestId('reservation-add-phone-input').fill('123')
    await page.getByTestId('reservation-add-submit-btn').click()

    await expect(page.locator('.el-form-item__error').first()).toContainText(/手机号/)
    await page.getByTestId('reservation-add-dialog').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/reservation-02-phone-invalid.png', fullPage: true })
  })

  test('离店日期不晚于入住日期时提示错误', async ({ page }) => {
    await page.getByTestId('reservation-add-btn').click()
    await page.getByTestId('reservation-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('reservation-add-name-input').fill('日期校验')
    await page.getByTestId('reservation-add-phone-input').fill(uniquePhone())
    await selectOption(page, 'reservation-add-roomtype-select', '大床房')
    // 入住 = 离店，非法
    const d = futureDate(20)
    await fillDate(page, '选择入住日期', d)
    await fillDate(page, '选择离店日期', d)
    await page.getByTestId('reservation-add-submit-btn').click()

    await expect(page.locator('.el-form-item__error').last()).toContainText(/离店日期/)
    await page.getByTestId('reservation-add-dialog').waitFor({ state: 'visible' })
  })

  test('编辑预订：修改姓名后保存', async ({ page }) => {
    const phone = uniquePhone()
    await page.getByTestId('reservation-add-btn').click()
    await page.getByTestId('reservation-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('reservation-add-name-input').fill(uniqueName('待编辑'))
    await page.getByTestId('reservation-add-phone-input').fill(phone)
    await selectOption(page, 'reservation-add-roomtype-select', '大床房')
    await fillDate(page, '选择入住日期', futureDate(20))
    await fillDate(page, '选择离店日期', futureDate(22))
    await page.getByTestId('reservation-add-submit-btn').click()
    await expectMessage(page, '预订成功')

    await page.getByTestId('reservation-keyword-input').fill(phone)
    await page.getByTestId('reservation-search-btn').click()
    await page.getByTestId('reservation-row').first().waitFor({ state: 'visible' })
    // 待确认状态才有编辑按钮
    await page.getByTestId('reservation-row').first().getByTestId('reservation-edit-btn').click()

    await page.getByTestId('reservation-edit-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('reservation-edit-name-input').fill(uniqueName('已编辑'))
    await page.screenshot({ path: 'tests-e2e/screenshots/reservation-03-edit-dialog.png', fullPage: true })
    await page.getByTestId('reservation-edit-submit-btn').click()

    await expectMessage(page, '预订信息已更新')
    await page.screenshot({ path: 'tests-e2e/screenshots/reservation-03-edit-success.png', fullPage: true })
  })

  test('确认预订：对待确认订单点确认', async ({ page }) => {
    const phone = uniquePhone()
    await page.getByTestId('reservation-add-btn').click()
    await page.getByTestId('reservation-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('reservation-add-name-input').fill(uniqueName('待确认'))
    await page.getByTestId('reservation-add-phone-input').fill(phone)
    await selectOption(page, 'reservation-add-roomtype-select', '大床房')
    await fillDate(page, '选择入住日期', futureDate(30))
    await fillDate(page, '选择离店日期', futureDate(32))
    await page.getByTestId('reservation-add-submit-btn').click()
    await expectMessage(page, '预订成功')

    await page.getByTestId('reservation-keyword-input').fill(phone)
    await page.getByTestId('reservation-search-btn').click()
    await page.getByTestId('reservation-row').first().waitFor({ state: 'visible' })
    await page.getByTestId('reservation-row').first().getByTestId('reservation-confirm-btn').click()

    await expectMessage(page, '预订已确认')
    await page.screenshot({ path: 'tests-e2e/screenshots/reservation-04-confirm.png', fullPage: true })
  })

  test('取消预订：填原因后确认取消', async ({ page }) => {
    const phone = uniquePhone()
    await page.getByTestId('reservation-add-btn').click()
    await page.getByTestId('reservation-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('reservation-add-name-input').fill(uniqueName('待取消'))
    await page.getByTestId('reservation-add-phone-input').fill(phone)
    await selectOption(page, 'reservation-add-roomtype-select', '大床房')
    await fillDate(page, '选择入住日期', futureDate(40))
    await fillDate(page, '选择离店日期', futureDate(42))
    await page.getByTestId('reservation-add-submit-btn').click()
    await expectMessage(page, '预订成功')

    await page.getByTestId('reservation-keyword-input').fill(phone)
    await page.getByTestId('reservation-search-btn').click()
    await page.getByTestId('reservation-row').first().waitFor({ state: 'visible' })
    await page.getByTestId('reservation-row').first().getByTestId('reservation-cancel-btn').click()

    await page.getByTestId('reservation-cancel-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('reservation-cancel-reason-input').fill('E2E 测试取消')
    await page.screenshot({ path: 'tests-e2e/screenshots/reservation-05-cancel-dialog.png', fullPage: true })
    await page.getByTestId('reservation-cancel-confirm-btn').click()

    await expectMessage(page, '预订已取消')
    await page.screenshot({ path: 'tests-e2e/screenshots/reservation-05-cancel-success.png', fullPage: true })
  })

  test('删除预订：弹确认框后删除', async ({ page }) => {
    const phone = uniquePhone()
    await page.getByTestId('reservation-add-btn').click()
    await page.getByTestId('reservation-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('reservation-add-name-input').fill(uniqueName('待删除'))
    await page.getByTestId('reservation-add-phone-input').fill(phone)
    await selectOption(page, 'reservation-add-roomtype-select', '大床房')
    await fillDate(page, '选择入住日期', futureDate(50))
    await fillDate(page, '选择离店日期', futureDate(52))
    await page.getByTestId('reservation-add-submit-btn').click()
    await expectMessage(page, '预订成功')

    await page.getByTestId('reservation-keyword-input').fill(phone)
    await page.getByTestId('reservation-search-btn').click()
    await page.getByTestId('reservation-row').first().waitFor({ state: 'visible' })
    await page.getByTestId('reservation-row').first().getByTestId('reservation-delete-btn').click()

    await confirmMessageBox(page)
    await expectMessage(page, '预订已删除')
    await page.screenshot({ path: 'tests-e2e/screenshots/reservation-06-delete.png', fullPage: true })
  })

  test('查询不存在的订单显示空列表', async ({ page }) => {
    await page.getByTestId('reservation-keyword-input').fill('RS-NOT-EXIST-E2E')
    await page.getByTestId('reservation-search-btn').click()
    await page.getByTestId('reservation-table').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/reservation-07-empty.png', fullPage: true })
  })

  test('取消原因留空仍可取消', async ({ page }) => {
    const phone = uniquePhone()
    await page.getByTestId('reservation-add-btn').click()
    await page.getByTestId('reservation-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('reservation-add-name-input').fill(uniqueName('空原因'))
    await page.getByTestId('reservation-add-phone-input').fill(phone)
    await selectOption(page, 'reservation-add-roomtype-select', '大床房')
    await fillDate(page, '选择入住日期', futureDate(60))
    await fillDate(page, '选择离店日期', futureDate(62))
    await page.getByTestId('reservation-add-submit-btn').click()
    await expectMessage(page, '预订成功')

    await page.getByTestId('reservation-keyword-input').fill(phone)
    await page.getByTestId('reservation-search-btn').click()
    await page.getByTestId('reservation-row').first().waitFor({ state: 'visible' })
    await page.getByTestId('reservation-row').first().getByTestId('reservation-cancel-btn').click()

    await page.getByTestId('reservation-cancel-dialog').waitFor({ state: 'visible' })
    // 原因留空
    await page.getByTestId('reservation-cancel-confirm-btn').click()
    await expectMessage(page, '预订已取消')
    await page.screenshot({ path: 'tests-e2e/screenshots/reservation-08-cancel-no-reason.png', fullPage: true })
  })

  test('状态筛选：选"已取消"只显示已取消', async ({ page }) => {
    await page.getByTestId('reservation-status-select').click()
    const dropdown = page.locator('.el-select-dropdown:visible').last()
    await dropdown.waitFor({ state: 'visible' })
    await dropdown.locator('.el-select-dropdown__item', { hasText: '已取消' }).first().click()
    await page.getByTestId('reservation-search-btn').click()
    await page.getByTestId('reservation-table').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/reservation-13-status-filter.png', fullPage: true })
  })

  test('分页器可见', async ({ page }) => {
    await page.getByTestId('reservation-pagination').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/reservation-14-pagination.png', fullPage: true })
  })

  test('已确认订单显示"办理入住"按钮', async ({ page }) => {
    // 新增并确认
    const phone = uniquePhone()
    await page.getByTestId('reservation-add-btn').click()
    await page.getByTestId('reservation-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('reservation-add-name-input').fill(uniqueName('到店'))
    await page.getByTestId('reservation-add-phone-input').fill(phone)
    await selectOption(page, 'reservation-add-roomtype-select', '大床房')
    await fillDate(page, '选择入住日期', futureDate(70))
    await fillDate(page, '选择离店日期', futureDate(72))
    await page.getByTestId('reservation-add-submit-btn').click()
    await expectMessage(page, '预订成功')

    await page.getByTestId('reservation-keyword-input').fill(phone)
    await page.getByTestId('reservation-search-btn').click()
    await page.getByTestId('reservation-row').first().waitFor({ state: 'visible' })
    await page.getByTestId('reservation-row').first().getByTestId('reservation-confirm-btn').click()
    await expectMessage(page, '预订已确认')

    // 确认后应出现"办理入住"按钮
    await expect(page.getByTestId('reservation-row').first().getByTestId('reservation-checkin-btn')).toBeVisible()
    await page.screenshot({ path: 'tests-e2e/screenshots/reservation-16-checkin-btn.png', fullPage: true })
  })
})
