<template>
  <div>
    <el-card shadow="never">
      <div class="toolbar">
        <div class="filters">
          <el-input
            v-model="query.keyword"
            placeholder="按订单号 / 客人姓名 / 手机号查询"
            clearable
            style="width: 280px"
            :prefix-icon="Search"
            data-testid="reservation-keyword-input"
            @keyup.enter="search"
          />
          <el-select
            v-model="query.status"
            placeholder="全部状态"
            clearable
            style="width: 140px"
            data-testid="reservation-status-select"
          >
            <el-option v-for="s in statusOptions" :key="s" :label="s" :value="s" />
          </el-select>
          <el-button type="primary" :loading="loading" data-testid="reservation-search-btn" @click="search">
            查询
          </el-button>
          <el-button :disabled="loading" data-testid="reservation-reset-btn" @click="resetQuery">重置</el-button>
        </div>
        <el-button type="primary" :icon="Plus" data-testid="reservation-add-btn" @click="openAdd">
          新增预订
        </el-button>
      </div>

      <el-table
        :data="list"
        border
        stripe
        v-loading="loading"
        empty-text="暂无预订数据"
        data-testid="reservation-table"
      >
        <el-table-column prop="orderNo" label="订单号" width="190" />
        <el-table-column prop="guestName" label="客人姓名" width="100" />
        <el-table-column label="手机号" width="130">
          <template #default="{ row }">{{ maskPhone(row.phone) }}</template>
        </el-table-column>
        <el-table-column prop="typeName" label="房型" width="120" />
        <el-table-column prop="checkInDate" label="入住日期" width="110" />
        <el-table-column prop="checkOutDate" label="离店日期" width="110" />
        <el-table-column prop="roomCount" label="间数" width="70" align="center" />
        <el-table-column label="状态" width="90">
          <template #default="{ row }">
            <el-tag :type="RESERVATION_STATUS_TYPE[row.status] || 'info'">{{ row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="330" fixed="right">
          <template #default="{ row }">
            <div class="row-actions" data-testid="reservation-row" :data-reservation-id="row.id">
              <el-button
                v-if="row.status === '待确认'"
                size="small"
                type="success"
                :loading="isPending(row, 'confirm')"
                data-testid="reservation-confirm-btn"
                @click="confirmRow(row)"
              >
                确认
              </el-button>
              <el-button
                v-if="row.status === '已确认'"
                size="small"
                type="primary"
                data-testid="reservation-checkin-btn"
                @click="goCheckin(row)"
              >
                办理入住
              </el-button>
              <el-button
                v-if="row.status === '待确认' || row.status === '已确认'"
                size="small"
                data-testid="reservation-edit-btn"
                @click="openEdit(row)"
              >
                编辑
              </el-button>
              <el-button
                v-if="row.status === '待确认' || row.status === '已确认'"
                size="small"
                type="warning"
                plain
                data-testid="reservation-cancel-btn"
                @click="openCancel(row)"
              >
                取消
              </el-button>
              <el-button
                size="small"
                type="danger"
                plain
                :loading="isPending(row, 'delete')"
                data-testid="reservation-delete-btn"
                @click="remove(row)"
              >
                删除
              </el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>

      <div class="pager">
        <el-pagination
          v-model:current-page="query.pageNum"
          v-model:page-size="query.pageSize"
          :total="total"
          :page-sizes="[5, 10, 20, 50]"
          layout="total, sizes, prev, pager, next, jumper"
          data-testid="reservation-pagination"
          @size-change="load"
          @current-change="load"
        />
      </div>
    </el-card>

    <!-- 新增预订：只负责新增 -->
    <el-dialog
      v-model="addVisible"
      title="新增预订"
      width="520px"
      data-testid="reservation-add-dialog"
      @closed="resetAddForm"
    >
      <el-form ref="addFormRef" :model="addForm" :rules="addRules" label-width="90px">
        <el-form-item label="客人姓名" prop="guestName">
          <el-input
            v-model="addForm.guestName"
            placeholder="请输入客人姓名"
            maxlength="50"
            data-testid="reservation-add-name-input"
          />
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input
            v-model="addForm.phone"
            placeholder="11 位手机号"
            maxlength="11"
            data-testid="reservation-add-phone-input"
          />
        </el-form-item>
        <el-form-item label="房型" prop="roomTypeId">
          <el-select
            v-model="addForm.roomTypeId"
            placeholder="请选择房型"
            style="width: 100%"
            data-testid="reservation-add-roomtype-select"
          >
            <el-option
              v-for="t in types"
              :key="t.id"
              :label="`${t.typeName}（¥${money(t.basePrice)}/晚）`"
              :value="t.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="入住日期" prop="checkInDate">
          <el-date-picker
            v-model="addForm.checkInDate"
            type="date"
            value-format="YYYY-MM-DD"
            placeholder="选择入住日期"
            style="width: 100%"
            :disabled-date="disabledPast"
            data-testid="reservation-add-checkin-date"
          />
        </el-form-item>
        <el-form-item label="离店日期" prop="checkOutDate">
          <el-date-picker
            v-model="addForm.checkOutDate"
            type="date"
            value-format="YYYY-MM-DD"
            placeholder="选择离店日期"
            style="width: 100%"
            :disabled-date="disabledPast"
            data-testid="reservation-add-checkout-date"
          />
        </el-form-item>
        <el-form-item label="间数" prop="roomCount">
          <el-input-number v-model="addForm.roomCount" :min="1" :max="10" data-testid="reservation-add-roomcount-input" />
          <span class="muted" style="margin-left: 10px">共 {{ addNights }} 晚</span>
        </el-form-item>
        <el-form-item label="备注">
          <el-input
            v-model="addForm.remark"
            type="textarea"
            :rows="2"
            maxlength="200"
            show-word-limit
            data-testid="reservation-add-remark-input"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button data-testid="reservation-add-cancel-btn" @click="addVisible = false">取消</el-button>
        <el-button type="primary" :loading="adding" data-testid="reservation-add-submit-btn" @click="submitAdd">
          提交预订
        </el-button>
      </template>
    </el-dialog>

    <!-- 编辑预订：只负责编辑 -->
    <el-dialog
      v-model="editVisible"
      title="编辑预订"
      width="520px"
      data-testid="reservation-edit-dialog"
      @closed="resetEditForm"
    >
      <el-form ref="editFormRef" :model="editForm" :rules="editRules" label-width="90px">
        <el-form-item label="客人姓名" prop="guestName">
          <el-input
            v-model="editForm.guestName"
            placeholder="请输入客人姓名"
            maxlength="50"
            data-testid="reservation-edit-name-input"
          />
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input
            v-model="editForm.phone"
            placeholder="11 位手机号"
            maxlength="11"
            data-testid="reservation-edit-phone-input"
          />
        </el-form-item>
        <el-form-item label="房型" prop="roomTypeId">
          <el-select
            v-model="editForm.roomTypeId"
            placeholder="请选择房型"
            style="width: 100%"
            data-testid="reservation-edit-roomtype-select"
          >
            <el-option
              v-for="t in types"
              :key="t.id"
              :label="`${t.typeName}（¥${money(t.basePrice)}/晚）`"
              :value="t.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="入住日期" prop="checkInDate">
          <el-date-picker
            v-model="editForm.checkInDate"
            type="date"
            value-format="YYYY-MM-DD"
            placeholder="选择入住日期"
            style="width: 100%"
            :disabled-date="disabledPast"
            data-testid="reservation-edit-checkin-date"
          />
        </el-form-item>
        <el-form-item label="离店日期" prop="checkOutDate">
          <el-date-picker
            v-model="editForm.checkOutDate"
            type="date"
            value-format="YYYY-MM-DD"
            placeholder="选择离店日期"
            style="width: 100%"
            :disabled-date="disabledPast"
            data-testid="reservation-edit-checkout-date"
          />
        </el-form-item>
        <el-form-item label="间数" prop="roomCount">
          <el-input-number v-model="editForm.roomCount" :min="1" :max="10" data-testid="reservation-edit-roomcount-input" />
          <span class="muted" style="margin-left: 10px">共 {{ editNights }} 晚</span>
        </el-form-item>
        <el-form-item label="备注">
          <el-input
            v-model="editForm.remark"
            type="textarea"
            :rows="2"
            maxlength="200"
            show-word-limit
            data-testid="reservation-edit-remark-input"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button data-testid="reservation-edit-cancel-btn" @click="editVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" data-testid="reservation-edit-submit-btn" @click="submitEdit">
          保存修改
        </el-button>
      </template>
    </el-dialog>

    <!-- 取消预订 -->
    <el-dialog v-model="cancelVisible" title="取消预订" width="420px" data-testid="reservation-cancel-dialog">
      <p class="dialog-tip" data-testid="reservation-cancel-target">
        订单号：{{ currentRow?.orderNo }}（{{ currentRow?.guestName }}）
      </p>
      <el-form label-width="80px">
        <el-form-item label="取消原因">
          <el-input
            v-model="cancelReason"
            type="textarea"
            :rows="3"
            maxlength="100"
            show-word-limit
            placeholder="请填写取消原因"
            data-testid="reservation-cancel-reason-input"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button data-testid="reservation-cancel-back-btn" @click="cancelVisible = false">返回</el-button>
        <el-button type="danger" :loading="canceling" data-testid="reservation-cancel-confirm-btn" @click="submitCancel">
          确认取消
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Search } from '@element-plus/icons-vue'
import api from '../api'
import {
  RESERVATION_STATUS_TYPE,
  diffDays,
  isValidPhone,
  money,
  maskPhone
} from '../utils/format'
import { useRowAction } from '../utils/useRowAction'

const router = useRouter()

const list = ref([])
const types = ref([])
const total = ref(0)
const loading = ref(false)
const adding = ref(false)
const saving = ref(false)
const canceling = ref(false)
const addVisible = ref(false)
const editVisible = ref(false)
const cancelVisible = ref(false)
const currentRow = ref(null)
const cancelReason = ref('')
const addFormRef = ref(null)
const editFormRef = ref(null)

const { isPending, run } = useRowAction()

const query = reactive({ pageNum: 1, pageSize: 10, keyword: '', status: '' })
const statusOptions = ['待确认', '已确认', '已到店', '已离店', '已取消', 'NoShow']

const addForm = reactive({
  guestName: '',
  phone: '',
  roomTypeId: null,
  checkInDate: '',
  checkOutDate: '',
  roomCount: 1,
  remark: ''
})

const editForm = reactive({
  id: null,
  guestName: '',
  phone: '',
  roomTypeId: null,
  checkInDate: '',
  checkOutDate: '',
  roomCount: 1,
  remark: ''
})

const addNights = computed(() => diffDays(addForm.checkInDate, addForm.checkOutDate))
const editNights = computed(() => diffDays(editForm.checkInDate, editForm.checkOutDate))

function validatePhone(rule, value, callback) {
  if (!value) {
    callback(new Error('手机号不能为空'))
  } else if (!isValidPhone(value)) {
    callback(new Error('手机号格式不正确'))
  } else {
    callback()
  }
}

function makeCheckOutValidator(target) {
  return (rule, value, callback) => {
    if (!value) {
      callback(new Error('请选择离店日期'))
    } else if (target.checkInDate && diffDays(target.checkInDate, value) <= 0) {
      callback(new Error('离店日期必须晚于入住日期'))
    } else {
      callback()
    }
  }
}

function buildRules(target) {
  return {
    guestName: [{ required: true, message: '客人姓名不能为空', trigger: 'blur' }],
    phone: [{ required: true, validator: validatePhone, trigger: 'blur' }],
    roomTypeId: [{ required: true, message: '请选择房型', trigger: 'change' }],
    checkInDate: [{ required: true, message: '请选择入住日期', trigger: 'change' }],
    checkOutDate: [{ required: true, validator: makeCheckOutValidator(target), trigger: 'change' }],
    roomCount: [{ required: true, message: '请选择间数', trigger: 'change' }]
  }
}

const addRules = buildRules(addForm)
const editRules = buildRules(editForm)

function disabledPast(date) {
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  return date.getTime() < today.getTime()
}

async function load() {
  loading.value = true
  try {
    const res = await api.get('/reservations/page', {
      params: {
        pageNum: query.pageNum,
        pageSize: query.pageSize,
        keyword: query.keyword || undefined,
        status: query.status || undefined
      }
    })
    list.value = res.data.records || []
    total.value = res.data.total || 0
  } catch (e) {
    list.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

function search() {
  query.pageNum = 1
  load()
}

function resetQuery() {
  query.keyword = ''
  query.status = ''
  query.pageNum = 1
  load()
}

async function loadTypes() {
  try {
    const res = await api.get('/room-types')
    types.value = res.data || []
  } catch (e) {
    types.value = []
  }
}

function resetAddForm() {
  addForm.guestName = ''
  addForm.phone = ''
  addForm.roomTypeId = null
  addForm.checkInDate = ''
  addForm.checkOutDate = ''
  addForm.roomCount = 1
  addForm.remark = ''
  addFormRef.value?.clearValidate()
}

function resetEditForm() {
  editForm.id = null
  editForm.guestName = ''
  editForm.phone = ''
  editForm.roomTypeId = null
  editForm.checkInDate = ''
  editForm.checkOutDate = ''
  editForm.roomCount = 1
  editForm.remark = ''
  editFormRef.value?.clearValidate()
}

function openAdd() {
  resetAddForm()
  addVisible.value = true
}

function openEdit(row) {
  editForm.id = row.id
  editForm.guestName = row.guestName
  editForm.phone = row.phone
  editForm.roomTypeId = row.roomTypeId
  editForm.checkInDate = row.checkInDate
  editForm.checkOutDate = row.checkOutDate
  editForm.roomCount = row.roomCount || 1
  editForm.remark = row.remark || ''
  editVisible.value = true
}

async function submitAdd() {
  if (!addFormRef.value) return
  try {
    await addFormRef.value.validate()
  } catch (e) {
    return
  }
  adding.value = true
  try {
    await api.post('/reservations', {
      guestName: addForm.guestName,
      phone: addForm.phone,
      roomTypeId: addForm.roomTypeId,
      checkInDate: addForm.checkInDate,
      checkOutDate: addForm.checkOutDate,
      roomCount: addForm.roomCount,
      remark: addForm.remark
    })
    ElMessage.success('预订成功')
    addVisible.value = false
    await load()
  } finally {
    adding.value = false
  }
}

async function submitEdit() {
  if (!editFormRef.value) return
  try {
    await editFormRef.value.validate()
  } catch (e) {
    return
  }
  saving.value = true
  try {
    await api.put(`/reservations/${editForm.id}`, {
      guestName: editForm.guestName,
      phone: editForm.phone,
      roomTypeId: editForm.roomTypeId,
      checkInDate: editForm.checkInDate,
      checkOutDate: editForm.checkOutDate,
      roomCount: editForm.roomCount,
      remark: editForm.remark
    })
    ElMessage.success('预订信息已更新')
    editVisible.value = false
    await load()
  } finally {
    saving.value = false
  }
}

async function confirmRow(row) {
  await run(row, 'confirm', async () => {
    await api.put(`/reservations/${row.id}/confirm`)
    ElMessage.success('预订已确认，房型库存已锁定')
    await load()
  })
}

function openCancel(row) {
  currentRow.value = row
  cancelReason.value = ''
  cancelVisible.value = true
}

async function submitCancel() {
  if (!currentRow.value) return
  canceling.value = true
  try {
    await api.put(`/reservations/${currentRow.value.id}/cancel`, { reason: cancelReason.value })
    ElMessage.success('预订已取消，房型库存已释放')
    cancelVisible.value = false
    await load()
  } finally {
    canceling.value = false
  }
}

async function remove(row) {
  try {
    await ElMessageBox.confirm('确认删除该预订？删除后不再参与库存统计。', '删除预订', { type: 'warning' })
  } catch (e) {
    return
  }
  await run(row, 'delete', async () => {
    await api.delete(`/reservations/${row.id}`)
    ElMessage.success('预订已删除')
    if (list.value.length === 1 && query.pageNum > 1) {
      query.pageNum -= 1
    }
    await load()
  })
}

function goCheckin(row) {
  router.push({ path: '/checkin', query: { reservationId: row.id } })
}

onMounted(() => {
  load()
  loadTypes()
})
</script>

<style scoped>
.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  gap: 12px;
  flex-wrap: wrap;
}
.filters {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}
.row-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.row-actions :deep(.el-button + .el-button) {
  margin-left: 0;
}
.pager {
  display: flex;
  justify-content: flex-end;
  margin-top: 14px;
}
.muted {
  color: #c0c4cc;
  font-size: 12px;
}
.dialog-tip {
  margin: 0 0 12px;
  color: #606266;
}
</style>