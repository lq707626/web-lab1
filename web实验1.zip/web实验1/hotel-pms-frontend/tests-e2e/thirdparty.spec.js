// 第三方对接与门锁模拟 E2E
// 对应用例：报告 7.2.10 第三方对接与门锁模拟测试
import { test, expect } from '@playwright/test'
import { loginAsAdmin, expectMessage, selectOption } from './helpers/auth.js'

test.describe('第三方对接', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page, '/third-party')
  })

  test('携程推送订单：日志与渠道订单表新增记录', async ({ page }) => {
    await page.getByTestId('thirdparty-ota-ctrip-btn').click()
    await expectMessage(page, '订单已落地')
    await page.getByTestId('thirdparty-ota-orders-table').waitFor({ state: 'visible' })
    await page.getByTestId('thirdparty-ota-log-list').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/thirdparty-01-ctrip.png', fullPage: true })
  })

  test('美团推送订单：渠道显示美团', async ({ page }) => {
    await page.getByTestId('thirdparty-ota-meituan-btn').click()
    await expectMessage(page, '订单已落地')
    await page.screenshot({ path: 'tests-e2e/screenshots/thirdparty-02-meituan.png', fullPage: true })
  })

  test('渠道取消订单：日志记录库存释放', async ({ page }) => {
    // 先推一个订单
    await page.getByTestId('thirdparty-ota-ctrip-btn').click()
    await expectMessage(page, '订单已落地')
    // 再取消
    await page.getByTestId('thirdparty-ota-cancel-btn').click()
    await expectMessage(page, '渠道取消成功')
    await page.screenshot({ path: 'tests-e2e/screenshots/thirdparty-03-cancel.png', fullPage: true })
  })

  test('手动同步房态：提示同步完成', async ({ page }) => {
    await page.getByTestId('thirdparty-ota-sync-btn').click()
    await expectMessage(page, '房态同步完成')
    await page.screenshot({ path: 'tests-e2e/screenshots/thirdparty-04-sync.png', fullPage: true })
  })

  test('模拟接口超时重试：出现 warning 提示', async ({ page }) => {
    await page.getByTestId('thirdparty-ota-timeout-btn').click()
    const warn = page.locator('.el-message--warning').last()
    await warn.waitFor({ state: 'visible', timeout: 5_000 })
    await expect(warn).toContainText(/重试/)
    await page.screenshot({ path: 'tests-e2e/screenshots/thirdparty-05-timeout.png', fullPage: true })
  })

  test('AppKey 鉴权失败：error 提示 401', async ({ page }) => {
    await page.getByTestId('thirdparty-ota-auth-btn').click()
    const err = page.locator('.el-message--error').last()
    await err.waitFor({ state: 'visible', timeout: 5_000 })
    await expect(err).toContainText(/401|未授权/)
    await page.screenshot({ path: 'tests-e2e/screenshots/thirdparty-06-auth-fail.png', fullPage: true })
  })

  test('门锁发卡：选房间后点击发卡，提示成功', async ({ page }) => {
    // 切到门锁面板 tab
    await page.getByTestId('thirdparty-tabs').locator('text=门锁控制面板').click()
    await page.getByTestId('thirdparty-lock-room-select').waitFor({ state: 'visible' })
    await selectOption(page, 'thirdparty-lock-room-select', '')
    await page.getByTestId('thirdparty-lock-issue-btn').click()
    await expectMessage(page, '发卡成功')
    await page.getByTestId('thirdparty-lock-cards-table').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/thirdparty-07-issue.png', fullPage: true })
  })

  test('门锁销卡：发卡后销卡，提示成功', async ({ page }) => {
    await page.getByTestId('thirdparty-tabs').locator('text=门锁控制面板').click()
    await page.getByTestId('thirdparty-lock-room-select').waitFor({ state: 'visible' })
    await selectOption(page, 'thirdparty-lock-room-select', '')
    await page.getByTestId('thirdparty-lock-issue-btn').click()
    await expectMessage(page, '发卡成功')
    await page.getByTestId('thirdparty-lock-cancel-btn').click()
    await expectMessage(page, '房卡已注销')
    await page.screenshot({ path: 'tests-e2e/screenshots/thirdparty-08-cancel.png', fullPage: true })
  })
})
