package com.hotel.pms.modules.roomtype;

import com.hotel.pms.entity.RoomType;

import java.util.List;

public interface RoomTypeService {

    List<RoomType> list();

    RoomType findById(Long id);

    RoomType create(RoomType roomType);

    boolean update(Long id, RoomType roomType);

    boolean delete(Long id);
}
