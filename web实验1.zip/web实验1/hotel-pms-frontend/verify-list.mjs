import { readFileSync, readdirSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { parse } from '@vue/compiler-sfc'

const expansions = {
  'layout-menu': ['room', 'reservation', 'checkin', 'bill', 'cashier', 'member', 'statistics', 'employee', 'third-party'],
  'room-filter': ['empty', 'occupied', 'reserved', 'repair', 'cleaning'],
  'statistics-card': ['revenue-today', 'revenue-month', 'occupancy-rate', 'adr', 'room-total', 'checkin-active', 'reservation-today', 'member-total'],
  'statistics-value': ['revenue-today', 'revenue-month', 'occupancy-rate', 'adr', 'room-total', 'checkin-active', 'reservation-today', 'member-total'],
  'cashier-pay-method': ['cash', 'wechat', 'alipay', 'bankcard', 'member']
}

const root = fileURLToPath(new URL('./src/', import.meta.url))

function walk(dir) {
  const out = []
  for (const name of readdirSync(dir)) {
    const full = join(dir, name)
    if (statSync(full).isDirectory()) out.push(...walk(full))
    else if (name.endsWith('.vue')) out.push(full)
  }
  return out
}

const codeTestids = new Set()
const testidRegex = /data-testid="([^"]+)"/g

for (const file of walk(root)) {
  const source = readFileSync(file, 'utf8')
  const { descriptor } = parse(source, { filename: file })
  const template = descriptor.template?.content || ''
  let m
  while ((m = testidRegex.exec(template)) !== null) {
    const raw = m[1]
    if (raw.includes('${')) {
      const val = raw.replace(/^`|`$/g, '')
      for (const [prefix, codes] of Object.entries(expansions)) {
        if (val.startsWith(`${prefix}-\${`)) {
          codes.forEach(code => codeTestids.add(`${prefix}-${code}`))
        }
      }
    } else {
      codeTestids.add(raw)
    }
  }
}

const list = readFileSync('testid-list.md', 'utf8').split('\n').filter(Boolean)
const listSet = new Set(list)

const missingInCode = [...listSet].filter(id => !codeTestids.has(id))
const extraInCode = [...codeTestids].filter(id => !listSet.has(id))

console.log(`清单共 ${list.length} 条`)
console.log(`代码展开后 testid 共 ${codeTestids.size} 条`)
console.log('=== 清单中但代码未出现的 testid ===')
if (missingInCode.length === 0) console.log('（无）')
else missingInCode.forEach(x => console.log(' - ' + x))
console.log('=== 代码中有但清单未列的 testid ===')
if (extraInCode.length === 0) console.log('（无）')
else extraInCode.forEach(x => console.log(' - ' + x))
