package com.hotel.pms.entity;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 客房设施（与房间是多对多关系，通过 room_amenity 关联）
 */
@Data
public class Amenity {
    private Long id;
    private String name;
    private String icon;
    private Integer sortNo;
    private LocalDateTime createTime;
}
