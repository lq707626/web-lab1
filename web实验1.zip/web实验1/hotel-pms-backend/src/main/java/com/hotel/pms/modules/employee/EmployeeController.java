package com.hotel.pms.modules.employee;

import com.hotel.pms.common.PageResult;
import com.hotel.pms.common.Result;
import com.hotel.pms.entity.Employee;
import com.hotel.pms.vo.EmployeeVO;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping
    public Result<List<EmployeeVO>> list() {
        return Result.success(employeeService.list());
    }

    /**
     * 条件分页：keyword（用户名/姓名）、role
     */
    @GetMapping("/page")
    public Result<PageResult<EmployeeVO>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String role) {
        return Result.success(employeeService.page(pageNum, pageSize, keyword, role));
    }

    @GetMapping("/{id}")
    public Result<EmployeeVO> detail(@PathVariable Long id) {
        return Result.success(employeeService.findById(id));
    }

    @PostMapping
    public Result<EmployeeVO> create(@RequestBody Employee employee) {
        return Result.success(employeeService.create(employee));
    }

    @PutMapping("/{id}")
    public Result<?> update(@PathVariable Long id, @RequestBody Employee employee) {
        employeeService.update(id, employee);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    public Result<?> delete(@PathVariable Long id) {
        employeeService.delete(id);
        return Result.success();
    }
}
