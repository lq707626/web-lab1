package com.hotel.pms.common;

/**
 * 业务异常：携带业务错误码（400 参数/业务校验失败，403 锁定/无权限等）
 */
public class BizException extends RuntimeException {

    private final int code;

    public BizException(String message) {
        super(message);
        this.code = 400;
    }

    public BizException(int code, String message) {
        super(message);
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}
