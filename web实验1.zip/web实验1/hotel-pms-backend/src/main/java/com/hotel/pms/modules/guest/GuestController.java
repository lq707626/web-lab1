package com.hotel.pms.modules.guest;

import com.hotel.pms.common.Result;
import com.hotel.pms.entity.Reservation;
import com.hotel.pms.entity.RoomType;
import com.hotel.pms.modules.reservation.ReservationService;
import com.hotel.pms.modules.room.RoomService;
import com.hotel.pms.modules.roomtype.RoomTypeService;
import com.hotel.pms.vo.ReservationVO;
import com.hotel.pms.vo.RoomVO;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/guest")
public class GuestController {

    private final RoomTypeService roomTypeService;
    private final RoomService roomService;
    private final ReservationService reservationService;

    public GuestController(RoomTypeService roomTypeService,
                           RoomService roomService,
                           ReservationService reservationService) {
        this.roomTypeService = roomTypeService;
        this.roomService = roomService;
        this.reservationService = reservationService;
    }

    @GetMapping("/room-types")
    public Result<List<RoomType>> roomTypes() {
        return Result.success(roomTypeService.list());
    }

    /**
     * 游客端房态：只展示空房/已预订
     */
    @GetMapping("/rooms")
    public Result<List<RoomVO>> rooms() {
        List<RoomVO> filtered = roomService.list().stream()
            .filter(r -> "空房".equals(r.getRoomStatus()) || "已预订".equals(r.getRoomStatus()))
            .collect(Collectors.toList());
        return Result.success(filtered);
    }

    @PostMapping("/reservation")
    public Result<Map<String, Object>> createReservation(@RequestBody Reservation reservation) {
        ReservationVO created = reservationService.create(reservation);
        Map<String, Object> data = new HashMap<>();
        data.put("id", created.getId());
        data.put("orderNo", created.getOrderNo());
        data.put("queryCode", created.getQueryCode());
        data.put("message", "预订成功，请保存查询码以便查询订单");
        return Result.success(data);
    }

    @GetMapping("/reservation/query")
    public Result<ReservationVO> queryReservation(@RequestParam String phone,
                                                  @RequestParam String queryCode) {
        ReservationVO reservation = reservationService.queryByPhoneAndCode(phone, queryCode);
        if (reservation == null) {
            return Result.error(400, "未找到相关订单，请检查手机号和查询码");
        }
        return Result.success(reservation);
    }
}
