-- 酒店PMS · 增量迁移脚本（2026-10-31）
-- 适用场景：虚拟机 mydb 已经导入过旧版 init.sql，缺少后加的表/字段/测试账号。
-- 全部语句可重复执行；执行方式：
--   python sql/run_migration.py   或   mysql -uroot -pyour_password mydb < sql/migrate_20261031.sql
-- 注意：MySQL 8.0 不支持 ADD COLUMN IF NOT EXISTS，因此 query_code 用 information_schema 判断后动态执行。

USE mydb;

-- ========== 1. 会员流水表（缺失会导致积分/余额充值、消费流水接口报错） ==========
CREATE TABLE IF NOT EXISTS member_transaction (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    member_id BIGINT NOT NULL COMMENT '会员ID',
    type VARCHAR(30) NOT NULL COMMENT '类型:积分充值/余额充值/余额消费/积分奖励',
    amount DECIMAL(10,2) NOT NULL COMMENT '变动金额',
    balance_after DECIMAL(10,2) COMMENT '变动后余额',
    points_after INT COMMENT '变动后积分',
    remark VARCHAR(200),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_member_id(member_id),
    INDEX idx_type(type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员流水表';

-- ========== 2. 支付流水表（缺失会导致微信/支付宝沙箱支付、退款接口报错） ==========
CREATE TABLE IF NOT EXISTS payment (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    payment_no VARCHAR(32) NOT NULL UNIQUE COMMENT '支付单号',
    order_no VARCHAR(32) COMMENT '关联订单号',
    bill_id BIGINT COMMENT '关联账单ID',
    channel VARCHAR(20) NOT NULL COMMENT '支付渠道:微信支付/支付宝',
    amount DECIMAL(10,2) NOT NULL COMMENT '支付金额',
    status VARCHAR(20) NOT NULL DEFAULT '待支付' COMMENT '状态:待支付/已支付/已退款/支付失败',
    trade_no VARCHAR(64) COMMENT '第三方交易号',
    pay_time DATETIME COMMENT '支付时间',
    refund_time DATETIME COMMENT '退款时间',
    remark VARCHAR(200),
    create_by VARCHAR(50),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0,
    INDEX idx_bill_id(bill_id),
    INDEX idx_status(status),
    INDEX idx_channel(channel)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='支付流水表（沙箱）';

-- ========== 3. reservation.query_code（缺失会导致新增预订/游客下单 INSERT 失败） ==========
SET @has_query_code := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'reservation' AND COLUMN_NAME = 'query_code'
);
SET @ddl := IF(@has_query_code = 0,
    'ALTER TABLE reservation ADD COLUMN query_code VARCHAR(10) COMMENT ''订单查询码''',
    'SELECT 1');
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ========== 4. 补充"总经理"测试账号（密码 123456，与其它账号同一 BCrypt 哈希） ==========
INSERT INTO employee (username, password, name, role)
SELECT 'gm', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '总经理', '总经理'
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM employee WHERE username = 'gm');

-- ========== 5. 历史测试数据规范化（与报告 3.3 枚举一致） ==========
UPDATE reservation SET status = '已到店' WHERE status = '已入住';
UPDATE reservation SET status = '已离店' WHERE status = '已完成';
UPDATE reservation SET room_type_id = ((room_type_id - 1) % 5) + 1 WHERE room_type_id > 5;
UPDATE bill SET settle_status = '未结算' WHERE settle_status = '部分结算';
UPDATE bill_item SET item_type = '其他' WHERE item_type IN ('购物', '娱乐');
UPDATE bill_item SET item_type = '餐饮费' WHERE item_type = '餐饮';
UPDATE bill_item SET pay_method = '微信支付' WHERE pay_method = '微信';
UPDATE bill_item SET pay_method = '会员余额' WHERE pay_method = '会员卡';

-- ========== 6. 房态与入住记录对齐（历史种子数据里存在"在住"但房态仍为空房） ==========
UPDATE room r
JOIN checkin c ON c.room_id = r.id AND c.status = '在住' AND c.is_deleted = 0
SET r.room_status = '已入住'
WHERE r.is_deleted = 0;

-- ========== 7. 设施表 / 房间-设施关联表（多对多） ==========
CREATE TABLE IF NOT EXISTS amenity (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL COMMENT '设施名称',
    icon VARCHAR(50) COMMENT '图标标识',
    sort_no INT DEFAULT 0 COMMENT '排序号',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客房设施表';

CREATE TABLE IF NOT EXISTS room_amenity (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    room_id BIGINT NOT NULL COMMENT '房间ID',
    amenity_id BIGINT NOT NULL COMMENT '设施ID',
    UNIQUE KEY uk_room_amenity (room_id, amenity_id),
    KEY idx_amenity (amenity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='房间-设施关联表（多对多）';

INSERT IGNORE INTO amenity (id, name, icon, sort_no) VALUES
(1, '免费WiFi', 'wifi', 1),
(2, '空调', 'ac', 2),
(3, '液晶电视', 'tv', 3),
(4, '独立卫浴', 'bath', 4),
(5, '迷你吧', 'minibar', 5),
(6, '保险箱', 'safe', 6),
(7, '浴缸', 'bathtub', 7),
(8, '观景阳台', 'balcony', 8);

INSERT IGNORE INTO room_amenity (room_id, amenity_id) SELECT id, 1 FROM room;
INSERT IGNORE INTO room_amenity (room_id, amenity_id) SELECT id, 2 FROM room;
INSERT IGNORE INTO room_amenity (room_id, amenity_id) SELECT id, 3 FROM room;
INSERT IGNORE INTO room_amenity (room_id, amenity_id) SELECT id, 4 FROM room WHERE room_type_id >= 3;
INSERT IGNORE INTO room_amenity (room_id, amenity_id) SELECT id, 5 FROM room WHERE room_type_id >= 4;
INSERT IGNORE INTO room_amenity (room_id, amenity_id) SELECT id, 6 FROM room WHERE room_type_id = 5;
INSERT IGNORE INTO room_amenity (room_id, amenity_id) SELECT id, 7 FROM room WHERE room_type_id = 5;
INSERT IGNORE INTO room_amenity (room_id, amenity_id) SELECT id, 8 FROM room WHERE room_type_id >= 4;

-- ========== 8. 房间门锁表（与 room 一对一） ==========
CREATE TABLE IF NOT EXISTS room_lock (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    room_id BIGINT NOT NULL COMMENT '房间ID',
    lock_no VARCHAR(32) NOT NULL COMMENT '门锁编号',
    status VARCHAR(20) NOT NULL DEFAULT '已锁闭' COMMENT '门锁状态:已锁闭/已开卡',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_room_lock_room (room_id),
    UNIQUE KEY uk_room_lock_no (lock_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='房间门锁表（一对一）';

INSERT IGNORE INTO room_lock (room_id, lock_no, status)
SELECT id, CONCAT('LOCK-', room_number), '已锁闭' FROM room;
