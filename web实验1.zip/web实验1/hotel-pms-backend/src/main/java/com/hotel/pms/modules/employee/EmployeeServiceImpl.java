package com.hotel.pms.modules.employee;

import com.hotel.pms.common.BizException;
import com.hotel.pms.common.PageResult;
import com.hotel.pms.common.SecurityUtil;
import com.hotel.pms.entity.Employee;
import com.hotel.pms.mapper.EmployeeMapper;
import com.hotel.pms.vo.EmployeeVO;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeMapper employeeMapper;
    private final PasswordEncoder passwordEncoder;

    public EmployeeServiceImpl(EmployeeMapper employeeMapper, PasswordEncoder passwordEncoder) {
        this.employeeMapper = employeeMapper;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public List<EmployeeVO> list() {
        return employeeMapper.findAll().stream().map(this::toVO).collect(Collectors.toList());
    }

    @Override
    public PageResult<EmployeeVO> page(int pageNum, int pageSize, String keyword, String role) {
        pageNum = Math.max(pageNum, 1);
        pageSize = Math.min(Math.max(pageSize, 1), 100);
        int offset = (pageNum - 1) * pageSize;
        List<EmployeeVO> records = employeeMapper.findPageVO(offset, pageSize, keyword, role);
        long total = employeeMapper.countVO(keyword, role);
        return new PageResult<>(total, pageNum, pageSize, records);
    }

    @Override
    public EmployeeVO findById(Long id) {
        Employee emp = employeeMapper.findById(id);
        if (emp == null) {
            throw new BizException("员工不存在");
        }
        return toVO(emp);
    }

    @Override
    @Transactional
    public EmployeeVO create(Employee employee) {
        if (employee.getUsername() == null || employee.getUsername().trim().length() < 3) {
            throw new BizException("用户名长度至少 3 个字符");
        }
        if (employee.getPassword() == null || employee.getPassword().length() < 6) {
            throw new BizException("密码至少 6 位");
        }
        if (employeeMapper.findByUsername(employee.getUsername()) != null) {
            throw new BizException("用户名已存在");
        }
        employee.setUsername(employee.getUsername().trim());
        employee.setPassword(passwordEncoder.encode(employee.getPassword()));
        employee.setCreateBy(SecurityUtil.getCurrentUsername());
        try {
            employeeMapper.insert(employee);
        } catch (DuplicateKeyException e) {
            throw new BizException("用户名已存在");
        }
        return findById(employee.getId());
    }

    @Override
    @Transactional
    public void update(Long id, Employee employee) {
        Employee existing = employeeMapper.findById(id);
        if (existing == null) {
            throw new BizException("员工不存在");
        }
        employee.setId(id);
        if (employee.getName() == null || employee.getName().trim().isEmpty()) {
            throw new BizException("员工姓名不能为空");
        }
        if (employee.getRole() == null || employee.getRole().trim().isEmpty()) {
            throw new BizException("请选择员工角色");
        }
        if (employee.getPassword() != null && !employee.getPassword().isEmpty()) {
            if (employee.getPassword().length() < 6) {
                throw new BizException("密码至少 6 位");
            }
            employee.setPassword(passwordEncoder.encode(employee.getPassword()));
        } else {
            employee.setPassword(existing.getPassword());
        }
        if (employeeMapper.update(employee) == 0) {
            throw new BizException("员工信息修改失败，请刷新后重试");
        }
    }

    @Override
    @Transactional
    public void delete(Long id) {
        Employee existing = employeeMapper.findById(id);
        if (existing == null) {
            throw new BizException("员工不存在");
        }
        if ("admin".equals(existing.getUsername())) {
            throw new BizException("默认管理员账号不允许禁用");
        }
        if (employeeMapper.delete(id) == 0) {
            throw new BizException("员工禁用失败，请刷新后重试");
        }
    }

    @Override
    public Employee findByUsername(String username) {
        return employeeMapper.findByUsername(username);
    }

    @Override
    public boolean checkPassword(Employee employee, String rawPassword) {
        return passwordEncoder.matches(rawPassword, employee.getPassword());
    }

    private EmployeeVO toVO(Employee e) {
        EmployeeVO vo = new EmployeeVO();
        vo.setId(e.getId());
        vo.setUsername(e.getUsername());
        vo.setName(e.getName());
        vo.setRole(e.getRole());
        vo.setCreateTime(e.getCreateTime());
        return vo;
    }
}
