package com.hotel.pms.entity;

import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class Reservation {
    private Long id;
    private String orderNo;
    private String guestName;
    private String phone;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private Long roomTypeId;
    private Integer roomCount;
    private String status;
    private String queryCode;
    private String remark;
    private String createBy;
    private LocalDateTime createTime;
    private String updateBy;
    private LocalDateTime updateTime;
    private Integer isDeleted;
    private String typeName;
}
