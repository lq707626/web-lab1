import axios from 'axios'
import { ElMessage } from 'element-plus'
import { useUserStore } from '../store/user'
import router from '../router'

const api = axios.create({
  baseURL: '/api',
  timeout: 10000
})

let redirecting = false

/**
 * 统一处理未登录 / 登录过期：
 * 后端 SecurityConfig 对 401 使用 HTTP 200 + body.code=401 返回，
 * 因此必须在响应体中判断，而不是只看 HTTP 状态码。
 */
function handleUnauthorized(message) {
  const userStore = useUserStore()
  userStore.logout()
  if (redirecting) return
  redirecting = true
  ElMessage.error(message || '登录已过期，请重新登录')
  const current = router.currentRoute.value
  const target = current.path === '/login' ? null : { path: '/login', query: { redirect: current.fullPath } }
  Promise.resolve(target ? router.push(target) : null).finally(() => {
    redirecting = false
  })
}

api.interceptors.request.use(config => {
  const userStore = useUserStore()
  if (userStore.token) {
    config.headers.Authorization = 'Bearer ' + userStore.token
  }
  return config
})

api.interceptors.response.use(
  res => {
    const body = res.data
    // 统一返回格式 { code, message, data }
    if (body && body.code === 200) {
      return body
    }
    const code = body ? body.code : undefined
    const message = body ? body.message : ''
    if (code === 401) {
      handleUnauthorized(message)
    } else if (code === 403) {
      ElMessage.error(message || '无权限访问该资源')
    } else {
      ElMessage.error(message || '请求失败')
    }
    return Promise.reject(new Error(message || '请求失败'))
  },
  err => {
    if (err.response?.status === 401) {
      handleUnauthorized()
    } else if (err.response?.status === 403) {
      ElMessage.error('无权限访问该资源')
    } else {
      // 报告 6.3：后端不可达时提示"网络错误，请稍后重试"，页面不崩溃
      ElMessage.error('网络错误，请稍后重试')
    }
    return Promise.reject(err)
  }
)

export default api
