package com.hotel.pms.entity;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 房间门锁（与房间是一对一关系，room_id 唯一）
 */
@Data
public class RoomLock {
    private Long id;
    private Long roomId;
    private String lockNo;
    private String status;
    private LocalDateTime updateTime;
}
