package com.hotel.pms.common;

import lombok.Data;

import java.util.List;

/**
 * 分页返回结果（Service 层组装，避免 Controller 直接拼 Map）
 */
@Data
public class PageResult<T> {
    private long total;
    private int pageNum;
    private int pageSize;
    private List<T> records;

    public PageResult() {
    }

    public PageResult(long total, int pageNum, int pageSize, List<T> records) {
        this.total = total;
        this.pageNum = pageNum;
        this.pageSize = pageSize;
        this.records = records;
    }
}
