package com.hotel.pms.mapper;

import com.hotel.pms.entity.Bill;
import com.hotel.pms.entity.BillItem;
import com.hotel.pms.vo.BillVO;
import org.apache.ibatis.annotations.*;
import java.util.List;

public interface BillMapper {
    @Select("SELECT b.*, c.guest_name, c.checkin_no, r.room_number FROM bill b " +
            "LEFT JOIN checkin c ON b.checkin_id = c.id " +
            "LEFT JOIN room r ON c.room_id = r.id " +
            "WHERE b.is_deleted = 0 ORDER BY b.create_time DESC")
    List<Bill> findAll();

    @Select("SELECT b.*, c.guest_name, c.checkin_no, r.room_number FROM bill b " +
            "LEFT JOIN checkin c ON b.checkin_id = c.id " +
            "LEFT JOIN room r ON c.room_id = r.id " +
            "WHERE b.id = #{id} AND b.is_deleted = 0")
    Bill findById(@Param("id") Long id);

    @Select("SELECT * FROM bill_item WHERE bill_no = #{billNo} AND is_deleted = 0")
    List<BillItem> findItems(@Param("billNo") String billNo);

    @Insert("INSERT INTO bill(bill_no, checkin_id, receivable_amount, actual_amount, " +
            "deposit_deduct, settle_status, create_by) " +
            "VALUES(#{billNo}, #{checkinId}, #{receivableAmount}, #{actualAmount}, " +
            "#{depositDeduct}, '未结算', #{createBy})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Bill bill);

    @Insert("<script>INSERT INTO bill_item(bill_no, item_type, amount, quantity, pay_method) VALUES " +
            "<foreach collection='items' item='item' separator=','>" +
            "(#{item.billNo}, #{item.itemType}, #{item.amount}, #{item.quantity}, #{item.payMethod})" +
            "</foreach></script>")
    int batchInsertItems(@Param("items") List<BillItem> items);

    @Update("UPDATE bill SET settle_status = '已结算', settle_time = NOW() WHERE id = #{id} AND is_deleted = 0")
    int settle(@Param("id") Long id);

    @Update("UPDATE bill SET actual_amount = #{actualAmount}, settle_status = '已结算', " +
            "settle_time = NOW() WHERE id = #{id} AND is_deleted = 0")
    int settleWithAmount(@Param("id") Long id, @Param("actualAmount") java.math.BigDecimal actualAmount);

    /** 退款：账单标记为已退款并冲减实收，避免统计继续计入营收 */
    @Update("UPDATE bill SET settle_status = '已退款', actual_amount = 0, " +
            "update_time = NOW() WHERE id = #{id} AND is_deleted = 0")
    int markRefunded(@Param("id") Long id);

    /* ========== 以下方法由 BillMapper.xml 实现（条件分页 / 联查 / 一对一） ========== */

    List<BillVO> findPageVO(@Param("offset") int offset,
                            @Param("size") int size,
                            @Param("keyword") String keyword,
                            @Param("status") String status);

    long countVO(@Param("keyword") String keyword, @Param("status") String status);

    BillVO findVOById(@Param("id") Long id);

    /** 入住单与账单 1:1 查询（账单表 checkin_id 建立唯一索引） */
    BillVO findVOByCheckinId(@Param("checkinId") Long checkinId);
}
