<template>
  <div>
    <el-card shadow="never">
      <div class="toolbar">
        <div class="filters">
          <el-input
            v-model="query.keyword"
            placeholder="按房间号 / 姓名 / 手机号查询"
            clearable
            style="width: 260px"
            :prefix-icon="Search"
            data-testid="checkin-keyword-input"
            @keyup.enter="search"
          />
          <el-select
            v-model="query.status"
            placeholder="全部状态"
            clearable
            style="width: 130px"
            data-testid="checkin-status-select"
          >
            <el-option label="在住" value="在住" />
            <el-option label="已退房" value="已退房" />
          </el-select>
          <el-button type="primary" :loading="loading" data-testid="checkin-search-btn" @click="search">
            查询
          </el-button>
          <el-button :disabled="loading" data-testid="checkin-reset-btn" @click="resetQuery">重置</el-button>
        </div>
        <el-button type="primary" :icon="Plus" data-testid="checkin-add-btn" @click="openAdd">
          入住登记
        </el-button>
      </div>

      <el-table
        :data="list"
        border
        stripe
        v-loading="loading"
        empty-text="暂无入住记录"
        data-testid="checkin-table"
      >
        <el-table-column prop="checkinNo" label="入住单号" width="190" />
        <el-table-column prop="roomNumber" label="房间号" width="90" />
        <el-table-column prop="guestName" label="客人姓名" width="100" />
        <el-table-column label="手机号" width="130">
          <template #default="{ row }">{{ maskPhone(row.phone) }}</template>
        </el-table-column>
        <el-table-column label="身份证号" width="170">
          <template #default="{ row }">{{ maskIdCard(row.idCard) }}</template>
        </el-table-column>
        <el-table-column label="押金" width="100">
          <template #default="{ row }">¥{{ money(row.deposit) }}</template>
        </el-table-column>
        <el-table-column label="入住时间" width="160">
          <template #default="{ row }">{{ formatTime(row.checkinTime) }}</template>
        </el-table-column>
        <el-table-column label="状态" width="90">
          <template #default="{ row }">
            <el-tag :type="row.status === '在住' ? 'danger' : 'info'">{{ row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="210" fixed="right">
          <template #default="{ row }">
            <div class="row-actions" data-testid="checkin-row" :data-checkin-id="row.id">
              <el-button
                v-if="row.status === '在住'"
                size="small"
                type="warning"
                :loading="isPending(row, 'checkout')"
                data-testid="checkin-checkout-btn"
                @click="openCheckout(row)"
              >
                退房
              </el-button>
              <el-button
                v-if="row.status === '在住'"
                size="small"
                data-testid="checkin-edit-btn"
                @click="openEdit(row)"
              >
                编辑
              </el-button>
              <el-button
                v-if="row.status === '已退房'"
                size="small"
                type="danger"
                plain
                :loading="isPending(row, 'delete')"
                data-testid="checkin-delete-btn"
                @click="remove(row)"
              >
                删除
              </el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>

      <div class="pager">
        <el-pagination
          v-model:current-page="query.pageNum"
          v-model:page-size="query.pageSize"
          :total="total"
          :page-sizes="[5, 10, 20, 50]"
          layout="total, sizes, prev, pager, next, jumper"
          data-testid="checkin-pagination"
          @size-change="load"
          @current-change="load"
        />
      </div>
    </el-card>

    <!-- 入住登记：只负责新增 -->
    <el-dialog
      v-model="addVisible"
      title="入住登记"
      width="540px"
      data-testid="checkin-add-dialog"
      @closed="resetAddForm"
    >
      <el-form ref="addFormRef" :model="addForm" :rules="addRules" label-width="100px">
        <el-form-item label="关联预订">
          <el-select
            v-model="addForm.reservationId"
            placeholder="散客可不选"
            clearable
            style="width: 100%"
            data-testid="checkin-add-reservation-select"
            @change="onReservationChange(addForm.reservationId)"
          >
            <el-option
              v-for="r in confirmedReservations"
              :key="r.id"
              :label="`${r.orderNo} ${r.guestName} ${r.typeName || ''}`"
              :value="r.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="房间" prop="roomId">
          <el-select
            v-model="addForm.roomId"
            placeholder="仅可选择空房 / 已预订房间"
            style="width: 100%"
            data-testid="checkin-add-room-select"
          >
            <el-option
              v-for="r in availableRooms"
              :key="r.id"
              :label="`${r.roomNumber}（${r.typeName || '-'}，${r.roomStatus}，¥${money(r.basePrice)}）`"
              :value="r.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="客人姓名" prop="guestName">
          <el-input
            v-model="addForm.guestName"
            placeholder="请输入客人姓名"
            maxlength="50"
            data-testid="checkin-add-name-input"
          />
        </el-form-item>
        <el-form-item label="身份证号" prop="idCard">
          <el-input
            v-model="addForm.idCard"
            placeholder="18 位身份证号"
            maxlength="18"
            data-testid="checkin-add-idcard-input"
          />
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input
            v-model="addForm.phone"
            placeholder="11 位手机号"
            maxlength="11"
            data-testid="checkin-add-phone-input"
          />
        </el-form-item>
        <el-form-item label="押金" prop="deposit">
          <el-input-number
            v-model="addForm.deposit"
            :min="0"
            :precision="2"
            :step="100"
            data-testid="checkin-add-deposit-input"
          />
          <span class="muted" style="margin-left: 10px">押金需大于 0，退房时用于抵扣房费</span>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button data-testid="checkin-add-cancel-btn" @click="addVisible = false">取消</el-button>
        <el-button type="primary" :loading="adding" data-testid="checkin-add-submit-btn" @click="submitAdd">
          办理入住
        </el-button>
      </template>
    </el-dialog>

    <!-- 编辑入住信息：只负责编辑 -->
    <el-dialog
      v-model="editVisible"
      title="编辑入住信息"
      width="540px"
      data-testid="checkin-edit-dialog"
      @closed="resetEditForm"
    >
      <el-form ref="editFormRef" :model="editForm" :rules="editRules" label-width="100px">
        <el-form-item label="客人姓名" prop="guestName">
          <el-input
            v-model="editForm.guestName"
            placeholder="请输入客人姓名"
            maxlength="50"
            data-testid="checkin-edit-name-input"
          />
        </el-form-item>
        <el-form-item label="身份证号" prop="idCard">
          <el-input
            v-model="editForm.idCard"
            placeholder="18 位身份证号"
            maxlength="18"
            data-testid="checkin-edit-idcard-input"
          />
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input
            v-model="editForm.phone"
            placeholder="11 位手机号"
            maxlength="11"
            data-testid="checkin-edit-phone-input"
          />
        </el-form-item>
        <el-form-item label="押金" prop="deposit">
          <el-input-number
            v-model="editForm.deposit"
            :min="0"
            :precision="2"
            :step="100"
            data-testid="checkin-edit-deposit-input"
          />
          <span class="muted" style="margin-left: 10px">押金需大于 0，退房时用于抵扣房费</span>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button data-testid="checkin-edit-cancel-btn" @click="editVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" data-testid="checkin-edit-submit-btn" @click="submitEdit">
          保存修改
        </el-button>
      </template>
    </el-dialog>

    <!-- 退房结算 -->
    <el-dialog v-model="checkoutVisible" title="退房结算" width="520px" data-testid="checkin-checkout-dialog">
      <el-descriptions :column="2" border>
        <el-descriptions-item label="入住单号" :span="2">{{ currentRow?.checkinNo }}</el-descriptions-item>
        <el-descriptions-item label="房间号">{{ currentRow?.roomNumber }}</el-descriptions-item>
        <el-descriptions-item label="客人">{{ currentRow?.guestName }}</el-descriptions-item>
        <el-descriptions-item label="入住时间" :span="2">{{ formatTime(currentRow?.checkinTime) }}</el-descriptions-item>
        <el-descriptions-item label="入住天数">{{ checkoutPreview.nights }} 晚</el-descriptions-item>
        <el-descriptions-item label="房费单价">¥{{ money(checkoutPreview.price) }}</el-descriptions-item>
        <el-descriptions-item label="应收房费">¥{{ money(checkoutPreview.fee) }}</el-descriptions-item>
        <el-descriptions-item label="押金抵扣">¥{{ money(checkoutPreview.deposit) }}</el-descriptions-item>
        <el-descriptions-item label="结算结果" :span="2">
          <el-tag :type="checkoutPreview.balance >= 0 ? 'success' : 'danger'">
            {{ checkoutPreview.balance >= 0 ? '应退客人' : '客人应补' }} ¥{{ money(Math.abs(checkoutPreview.balance)) }}
          </el-tag>
        </el-descriptions-item>
      </el-descriptions>
      <el-alert
        type="warning"
        :closable="false"
        style="margin-top: 12px"
        title="确认退房后：房态变为「待清洁」、房卡模拟注销、自动生成房费账单（可在账单结算页面收款）"
      />
      <template #footer>
        <el-button data-testid="checkin-checkout-cancel-btn" @click="checkoutVisible = false">取消</el-button>
        <el-button type="warning" :loading="checkoutSaving" data-testid="checkin-checkout-confirm-btn" @click="submitCheckout">
          确认退房
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Search } from '@element-plus/icons-vue'
import api from '../api'
import { isValidIdCard, isValidPhone, maskIdCard, maskPhone, money } from '../utils/format'
import { useRowAction } from '../utils/useRowAction'

const route = useRoute()

const list = ref([])
const rooms = ref([])
const reservations = ref([])
const total = ref(0)
const loading = ref(false)
const adding = ref(false)
const saving = ref(false)
const checkoutSaving = ref(false)
const addVisible = ref(false)
const editVisible = ref(false)
const checkoutVisible = ref(false)
const currentRow = ref(null)
const addFormRef = ref(null)
const editFormRef = ref(null)

const { isPending, run } = useRowAction()

const query = reactive({ pageNum: 1, pageSize: 10, keyword: '', status: '' })

const addForm = reactive({
  reservationId: null,
  roomId: null,
  guestName: '',
  idCard: '',
  phone: '',
  deposit: 200
})

const editForm = reactive({
  id: null,
  guestName: '',
  idCard: '',
  phone: '',
  deposit: 200
})

const availableRooms = computed(() =>
  rooms.value.filter(room => room.roomStatus === '空房' || room.roomStatus === '已预订')
)

const confirmedReservations = computed(() =>
  reservations.value.filter(r => r.status === '已确认')
)

const checkoutPreview = computed(() => {
  const row = currentRow.value
  if (!row) return { nights: 0, price: 0, fee: 0, deposit: 0, balance: 0 }
  const price = Number(row.basePrice ?? rooms.value.find(r => r.id === row.roomId)?.basePrice ?? 0)
  const startText = String(row.checkinTime || '').replace('T', ' ').replace(/-/g, '/')
  const start = new Date(startText)
  const now = new Date()
  // 与后端 CheckinService 保持一致：ChronoUnit.DAYS 向下取整，不足 1 天按 1 天
  let nights = Math.floor((now.getTime() - start.getTime()) / 86400000)
  if (!Number.isFinite(nights) || nights < 1) nights = 1
  const fee = price * nights
  const deposit = Number(row.deposit || 0)
  return { nights, price, fee, deposit, balance: deposit - fee }
})

function validateIdCard(rule, value, callback) {
  if (!value) {
    callback(new Error('身份证号不能为空'))
  } else if (!isValidIdCard(value)) {
    callback(new Error('身份证号格式不正确'))
  } else {
    callback()
  }
}

function validateDeposit(rule, value, callback) {
  if (value === null || value === undefined || Number(value) <= 0) {
    callback(new Error('押金金额必须大于0'))
  } else {
    callback()
  }
}

function validatePhone(rule, value, callback) {
  if (!value) {
    callback()
  } else if (!isValidPhone(value)) {
    callback(new Error('手机号格式不正确'))
  } else {
    callback()
  }
}

const addRules = {
  roomId: [{ required: true, message: '请选择房间', trigger: 'change' }],
  guestName: [{ required: true, message: '客人姓名不能为空', trigger: 'blur' }],
  idCard: [{ required: true, validator: validateIdCard, trigger: 'blur' }],
  phone: [{ validator: validatePhone, trigger: 'blur' }],
  deposit: [{ required: true, validator: validateDeposit, trigger: 'change' }]
}

const editRules = {
  guestName: [{ required: true, message: '客人姓名不能为空', trigger: 'blur' }],
  idCard: [{ required: true, validator: validateIdCard, trigger: 'blur' }],
  phone: [{ validator: validatePhone, trigger: 'blur' }],
  deposit: [{ required: true, validator: validateDeposit, trigger: 'change' }]
}

function formatTime(value) {
  if (!value) return '-'
  return String(value).replace('T', ' ').slice(0, 19)
}

async function load() {
  loading.value = true
  try {
    const [checkinRes, roomRes, reservationRes] = await Promise.all([
      api.get('/checkins/page', {
        params: {
          pageNum: query.pageNum,
          pageSize: query.pageSize,
          keyword: query.keyword || undefined,
          status: query.status || undefined
        }
      }),
      api.get('/rooms'),
      api.get('/reservations')
    ])
    list.value = checkinRes.data.records || []
    total.value = checkinRes.data.total || 0
    rooms.value = roomRes.data || []
    reservations.value = reservationRes.data || []
  } catch (e) {
    list.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

function search() {
  query.pageNum = 1
  load()
}

function resetQuery() {
  query.keyword = ''
  query.status = ''
  query.pageNum = 1
  load()
}

function resetAddForm() {
  addForm.reservationId = null
  addForm.roomId = null
  addForm.guestName = ''
  addForm.idCard = ''
  addForm.phone = ''
  addForm.deposit = 200
  addFormRef.value?.clearValidate()
}

function resetEditForm() {
  editForm.id = null
  editForm.guestName = ''
  editForm.idCard = ''
  editForm.phone = ''
  editForm.deposit = 200
  editFormRef.value?.clearValidate()
}

function openAdd(reservationId = null) {
  resetAddForm()
  if (reservationId) {
    addForm.reservationId = Number(reservationId)
    onReservationChange(addForm.reservationId)
  }
  addVisible.value = true
}

function openEdit(row) {
  editForm.id = row.id
  editForm.guestName = row.guestName
  editForm.idCard = row.idCard
  editForm.phone = row.phone
  editForm.deposit = Number(row.deposit || 0)
  editVisible.value = true
}

function onReservationChange(id) {
  const reservation = reservations.value.find(r => r.id === id)
  if (reservation) {
    addForm.guestName = reservation.guestName || ''
    addForm.phone = reservation.phone || ''
  }
}

async function submitAdd() {
  if (!addFormRef.value) return
  try {
    await addFormRef.value.validate()
  } catch (e) {
    return
  }
  adding.value = true
  try {
    await api.post('/checkins', {
      reservationId: addForm.reservationId,
      roomId: addForm.roomId,
      guestName: addForm.guestName,
      idCard: addForm.idCard,
      phone: addForm.phone,
      deposit: addForm.deposit
    })
    ElMessage.success('入住成功，房卡已发放，房态已更新为已入住')
    addVisible.value = false
    await load()
  } finally {
    adding.value = false
  }
}

async function submitEdit() {
  if (!editFormRef.value) return
  try {
    await editFormRef.value.validate()
  } catch (e) {
    return
  }
  saving.value = true
  try {
    await api.put(`/checkins/${editForm.id}`, {
      guestName: editForm.guestName,
      idCard: editForm.idCard,
      phone: editForm.phone,
      deposit: editForm.deposit
    })
    ElMessage.success('入住信息已更新')
    editVisible.value = false
    await load()
  } finally {
    saving.value = false
  }
}

function openCheckout(row) {
  currentRow.value = { ...row }
  checkoutVisible.value = true
}

async function submitCheckout() {
  if (!currentRow.value) return
  checkoutSaving.value = true
  try {
    await api.put(`/checkins/${currentRow.value.id}/checkout`)
    ElMessage.success('退房成功，房卡已注销，房态已变为待清洁，房费账单已生成')
    checkoutVisible.value = false
    await load()
  } finally {
    checkoutSaving.value = false
  }
}

async function remove(row) {
  try {
    await ElMessageBox.confirm('确认删除该入住记录？删除后不再展示。', '删除入住记录', { type: 'warning' })
  } catch (e) {
    return
  }
  await run(row, 'delete', async () => {
    await api.delete(`/checkins/${row.id}`)
    ElMessage.success('入住记录已删除')
    if (list.value.length === 1 && query.pageNum > 1) {
      query.pageNum -= 1
    }
    await load()
  })
}

onMounted(async () => {
  await load()
  if (route.query.reservationId) {
    openAdd(route.query.reservationId)
  }
})
</script>

<style scoped>
.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  gap: 12px;
  flex-wrap: wrap;
}
.filters {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}
.row-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.row-actions :deep(.el-button + .el-button) {
  margin-left: 0;
}
.pager {
  display: flex;
  justify-content: flex-end;
  margin-top: 14px;
}
.muted {
  color: #c0c4cc;
  font-size: 12px;
}
</style>