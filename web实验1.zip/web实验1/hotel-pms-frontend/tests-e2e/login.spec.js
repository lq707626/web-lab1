// 登录与权限模块 E2E
// 对应用例：报告 7.2.1 登录与权限模块测试
import { test, expect } from '@playwright/test'
import { ADMIN_USERNAME, ADMIN_PASSWORD, expectMessage, seedFakeToken } from './helpers/auth.js'

/**
 * 通用登录：用任意账号密码登录，返回登录后是否成功。
 */
async function doLogin(page, username, password) {
  await page.goto('/login')
  await page.getByTestId('login-username-input').fill(username)
  await page.getByTestId('login-password-input').fill(password)
  await page.getByTestId('login-submit-btn').click()
}

test.describe('登录与权限', () => {
  test('管理员 admin 正常登录，进入房态管理，菜单齐全', async ({ page }) => {
    await doLogin(page, ADMIN_USERNAME, ADMIN_PASSWORD)
    await expectMessage(page, '登录成功')
    await page.getByTestId('layout-menu').waitFor({ state: 'visible' })
    // admin 应能看到 9 个菜单中的关键项
    await page.getByTestId('layout-menu-member').waitFor({ state: 'visible' })
    await page.getByTestId('layout-menu-employee').waitFor({ state: 'visible' })
    await page.getByTestId('layout-menu-statistics').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/login-01-admin-success.png', fullPage: true })
  })

  test('前台 front 登录，仅看到 4 个前台菜单', async ({ page }) => {
    await doLogin(page, 'front', '123456')
    await expectMessage(page, '登录成功')
    await page.getByTestId('layout-menu').waitFor({ state: 'visible' })
    // 前台可见：房态/预订/入住/会员
    await page.getByTestId('layout-menu-member').waitFor({ state: 'visible' })
    // 前台不可见：员工管理（admin 专属）
    await expect(page.getByTestId('layout-menu-employee')).toHaveCount(0)
    await expect(page.getByTestId('layout-menu-bill')).toHaveCount(0)
    await page.screenshot({ path: 'tests-e2e/screenshots/login-02-front-success.png', fullPage: true })
  })

  test('收银 cashier 登录，仅看到账单与收银菜单', async ({ page }) => {
    await doLogin(page, 'cashier', '123456')
    await expectMessage(page, '登录成功')
    await page.getByTestId('layout-menu').waitFor({ state: 'visible' })
    await page.getByTestId('layout-menu-cashier').waitFor({ state: 'visible' })
    await expect(page.getByTestId('layout-menu-member')).toHaveCount(0)
    await page.screenshot({ path: 'tests-e2e/screenshots/login-03-cashier-success.png', fullPage: true })
  })

  test('客房经理 manager 登录，仅看到房态与报表', async ({ page }) => {
    await doLogin(page, 'manager', '123456')
    await expectMessage(page, '登录成功')
    await page.getByTestId('layout-menu').waitFor({ state: 'visible' })
    await page.getByTestId('layout-menu-statistics').waitFor({ state: 'visible' })
    await expect(page.getByTestId('layout-menu-employee')).toHaveCount(0)
    await page.screenshot({ path: 'tests-e2e/screenshots/login-04-manager-success.png', fullPage: true })
  })

  test('总经理 gm 登录，仅看到报表统计', async ({ page }) => {
    await doLogin(page, 'gm', '123456')
    await expectMessage(page, '登录成功')
    await page.getByTestId('layout-menu-statistics').waitFor({ state: 'visible' })
    await expect(page.getByTestId('layout-menu-room')).toHaveCount(0)
    await page.screenshot({ path: 'tests-e2e/screenshots/login-05-gm-success.png', fullPage: true })
  })

  test('密码错误时提示且不跳转', async ({ page }) => {
    await doLogin(page, 'admin', 'wrong-pwd-000')
    const err = page.locator('.el-message--error').last()
    await err.waitFor({ state: 'visible', timeout: 8_000 })
    await expect(err).toContainText(/用户名或密码错误|密码错误/)
    await page.getByTestId('login-submit-btn').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/login-06-wrong-password.png', fullPage: true })
  })

  test('用户不存在时同样提示"用户名或密码错误"，不暴露账号是否存在', async ({ page }) => {
    await doLogin(page, 'nobody-e2e-xxx', '123456')
    const err = page.locator('.el-message--error').last()
    await err.waitFor({ state: 'visible', timeout: 8_000 })
    await expect(err).toContainText(/用户名或密码错误/)
    await page.getByTestId('login-submit-btn').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/login-07-no-such-user.png', fullPage: true })
  })

  test('用户名为空时前端校验拦截，不发请求', async ({ page }) => {
    await page.goto('/login')
    await page.getByTestId('login-password-input').fill(ADMIN_PASSWORD)
    await page.getByTestId('login-submit-btn').click()
    await expect(page.locator('.el-form-item__error').first()).toContainText(/用户名/)
    await page.getByTestId('login-submit-btn').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/login-08-empty-username.png', fullPage: true })
  })

  test('密码为空时前端校验拦截，不发请求', async ({ page }) => {
    await page.goto('/login')
    await page.getByTestId('login-username-input').fill(ADMIN_USERNAME)
    await page.getByTestId('login-submit-btn').click()
    await expect(page.locator('.el-form-item__error').first()).toContainText(/密码/)
    await page.getByTestId('login-submit-btn').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/login-10-empty-password.png', fullPage: true })
  })

  test('未登录直接访问受保护页面，自动跳转登录页', async ({ page }) => {
    await page.goto('/login')
    await page.evaluate(() => localStorage.clear())
    await page.goto('/member')
    await page.waitForURL(/\/login/, { timeout: 8_000 })
    await page.getByTestId('login-username-input').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/login-09-no-auth-redirect.png', fullPage: true })
  })

  test('Token 无效时后端返回 401，前端清登录态跳回登录页', async ({ page }) => {
    await seedFakeToken(page, 'fake.invalid.token')
    await page.goto('/member')
    // 接口返回 401 后拦截器会 ElMessage.error 并跳登录
    await page.waitForURL(/\/login/, { timeout: 10_000 })
    await page.getByTestId('login-username-input').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/login-10-token-invalid.png', fullPage: true })
  })

  test('越权访问页面：前台访问员工管理被弹回首页', async ({ page }) => {
    await doLogin(page, 'front', '123456')
    await expectMessage(page, '登录成功')
    await page.getByTestId('layout-menu').waitFor({ state: 'visible' })
    // 直接地址栏访问 /employee
    await page.goto('/employee')
    // 路由守卫应提示无权限并跳回首页
    const warn = page.locator('.el-message--warning').last()
    await warn.waitFor({ state: 'visible', timeout: 8_000 })
    await expect(warn).toContainText(/无权访问/)
    await page.screenshot({ path: 'tests-e2e/screenshots/login-11-forbidden-page.png', fullPage: true })
  })

  test('登录后退出登录，返回登录页', async ({ page }) => {
    await doLogin(page, ADMIN_USERNAME, ADMIN_PASSWORD)
    await expectMessage(page, '登录成功')
    await page.getByTestId('layout-menu').waitFor({ state: 'visible' })

    await page.getByTestId('layout-user-dropdown').hover()
    await page.getByTestId('layout-logout-btn').click()
    await expectMessage(page, '已退出登录')
    await page.waitForURL(/\/login/, { timeout: 8_000 })
    await page.getByTestId('login-username-input').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/login-12-logout.png', fullPage: true })
  })
})
