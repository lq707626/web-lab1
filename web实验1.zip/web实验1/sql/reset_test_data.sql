-- ============================================================
-- E2E 测试数据重置脚本
-- 用途：跑多轮 Playwright 后，把房间恢复空房、清掉测试造的入住/预订/账单
-- 用法：mysql -h your-vm-ip -u root -pyour_password mydb < sql/reset_test_data.sql
-- ============================================================

-- 1. 软删除所有入住记录（包括种子数据和测试数据）
UPDATE checkin SET is_deleted = 1 WHERE is_deleted = 0;

-- 2. 软删除所有账单及明细
UPDATE bill SET is_deleted = 1 WHERE is_deleted = 0;
UPDATE bill_item SET is_deleted = 1 WHERE is_deleted = 0;

-- 3. 软删除所有预订（测试造的 + 种子数据）
UPDATE reservation SET is_deleted = 1 WHERE is_deleted = 0;

-- 4. 软删除所有支付记录
UPDATE payment SET is_deleted = 1 WHERE is_deleted = 0;

-- 5. 恢复房间状态：
--    306 保持"维修中"（种子数据），其余全部恢复"空房"
UPDATE room SET room_status = '空房' WHERE room_status IN ('已入住', '已预订', '待清洁') AND is_deleted = 0;
UPDATE room SET room_status = '维修中' WHERE room_number = '306' AND is_deleted = 0;

-- 6. 软删除测试造的会员（保留种子数据：张三/李四 + 20条扩充会员）
--    种子会员 id <= 22（2 + 20 = 22），测试造的 id > 22
UPDATE member SET is_deleted = 1 WHERE id > 22;
UPDATE member_transaction SET member_id = 0 WHERE member_id > 22;

-- 7. 软删除测试造的员工（保留 admin/front/cashier/manager/gm 5个种子账号）
--    种子员工 id <= 5
UPDATE employee SET is_deleted = 1 WHERE id > 5;

-- 8. 重置门锁状态为"已锁闭"
UPDATE room_lock SET status = '已锁闭';

SELECT '=== 测试数据已重置 ===' AS msg;
SELECT room_number, room_status FROM room WHERE is_deleted = 0 ORDER BY room_number;
