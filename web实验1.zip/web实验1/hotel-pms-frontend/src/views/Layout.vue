<template>
  <el-container class="layout">
    <el-aside width="210px" class="aside">
      <div class="logo">酒店 PMS 管理系统</div>
      <el-menu
        :default-active="route.path"
        router
        background-color="#304156"
        text-color="#bfcbd9"
        active-text-color="#409EFF"
        data-testid="layout-menu"
      >
        <el-menu-item
          v-for="menu in userStore.menus"
          :key="menu.path"
          :index="menu.path"
          :data-testid="`layout-menu-${menu.key}`"
        >
          <el-icon><component :is="menu.icon" /></el-icon>
          <span>{{ menu.title }}</span>
        </el-menu-item>
      </el-menu>
    </el-aside>

    <el-container>
      <el-header class="header">
        <div class="page-title" data-testid="layout-page-title">{{ route.name }}</div>
        <div class="header-right">
          <el-tag type="info" effect="plain" class="role-tip" data-testid="layout-role-tag">
            {{ roleDescription(userStore.role) }}
          </el-tag>
          <el-dropdown @command="handleCommand">
            <span class="user-info" data-testid="layout-user-dropdown">
              <span class="user-name" data-testid="layout-user-name">{{ userStore.name }}</span>
              <span class="user-role">（{{ userStore.role }}）</span>
              <el-icon><ArrowDown /></el-icon>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item disabled>账号：{{ userStore.username }}</el-dropdown-item>
                <el-dropdown-item command="guest" data-testid="layout-guest-btn">前台在线预订门户</el-dropdown-item>
                <el-dropdown-item command="logout" divided :disabled="loggingOut" data-testid="layout-logout-btn">
                  {{ loggingOut ? '退出中' : '退出登录' }}
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </el-header>

      <el-main class="main">
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup>
import { ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import api from '../api'
import { useUserStore } from '../store/user'
import { roleDescription } from '../utils/permission'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const loggingOut = ref(false)

async function handleCommand(command) {
  if (command === 'guest') {
    router.push('/guest')
    return
  }
  if (command === 'logout') {
    loggingOut.value = true
    try {
      await api.post('/auth/logout')
    } catch (e) {
      // 注销接口异常不影响本地退出
    } finally {
      userStore.logout()
      loggingOut.value = false
      ElMessage.success('已退出登录')
      router.push('/login')
    }
  }
}
</script>

<style scoped>
.layout {
  height: 100vh;
}
.aside {
  background: #304156;
  overflow-x: hidden;
}
.logo {
  color: #fff;
  text-align: center;
  line-height: 60px;
  font-size: 17px;
  font-weight: bold;
  letter-spacing: 1px;
}
.header {
  background: #fff;
  border-bottom: 1px solid #eee;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.page-title {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}
.header-right {
  display: flex;
  align-items: center;
  gap: 16px;
}
.role-tip {
  font-size: 12px;
}
.user-info {
  cursor: pointer;
  color: #303133;
  display: flex;
  align-items: center;
  gap: 4px;
}
.user-name {
  font-weight: 600;
}
.user-role {
  color: #606266;
}
.main {
  background: #f0f2f5;
  padding: 16px;
  overflow-y: auto;
}
</style>