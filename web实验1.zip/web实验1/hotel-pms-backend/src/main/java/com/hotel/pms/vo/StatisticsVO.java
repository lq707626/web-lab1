package com.hotel.pms.vo;

import lombok.Data;

/**
 * 报表总览视图对象（Service 组装，Controller 直接返回）
 */
@Data
public class StatisticsVO {
    private Integer roomTotal;
    private Integer roomEmpty;
    private Integer roomOccupied;
    private Integer roomReserved;
    private Integer roomDirty;
    private Integer roomMaintenance;
    private Double occupancyRate;
    private Integer memberTotal;
    private Integer reservationToday;
    private Integer checkinActive;
    private Double revenueMonth;
    private Double revenueToday;
    private Double adr;
    private Integer roomNights;
}
