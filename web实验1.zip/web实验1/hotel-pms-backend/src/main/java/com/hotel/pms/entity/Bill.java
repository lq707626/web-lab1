package com.hotel.pms.entity;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class Bill {
    private Long id;
    private String billNo;
    private Long checkinId;
    private BigDecimal receivableAmount;
    private BigDecimal actualAmount;
    private BigDecimal depositDeduct;
    private String settleStatus;
    private LocalDateTime settleTime;
    private String createBy;
    private LocalDateTime createTime;
    private String updateBy;
    private LocalDateTime updateTime;
    private Integer isDeleted;
    private List<BillItem> items;

    // 联表查询字段：账单列表需要展示客人、房间号（报告 6.2.5 账单列表）
    private String guestName;
    private String roomNumber;
    private String checkinNo;
}
