package com.hotel.pms.modules.auth;

import com.hotel.pms.common.BizException;
import com.hotel.pms.common.JwtUtil;
import com.hotel.pms.common.RedisService;
import com.hotel.pms.entity.Employee;
import com.hotel.pms.modules.employee.EmployeeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Service
public class AuthServiceImpl implements AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthServiceImpl.class);

    private static final int MAX_FAIL_COUNT = 5;
    private static final long LOCK_TIME_MINUTES = 15;
    private static final String LOGIN_FAIL_PREFIX = "login:fail:";
    private static final String LOGIN_LOCK_PREFIX = "login:lock:";

    private final EmployeeService employeeService;
    private final JwtUtil jwtUtil;
    private final RedisService redisService;

    public AuthServiceImpl(EmployeeService employeeService,
                           JwtUtil jwtUtil,
                           RedisService redisService) {
        this.employeeService = employeeService;
        this.jwtUtil = jwtUtil;
        this.redisService = redisService;
    }

    @Override
    public Map<String, Object> login(String username, String password) {
        if (username == null || username.trim().isEmpty()) {
            throw new BizException("用户名不能为空");
        }
        if (password == null || password.trim().isEmpty()) {
            throw new BizException("密码不能为空");
        }
        username = username.trim();

        String lockKey = LOGIN_LOCK_PREFIX + username;
        if (redisService.hasKey(lockKey)) {
            throw new BizException(403, "账号已被锁定，请15分钟后再试");
        }

        Employee emp = employeeService.findByUsername(username);
        if (emp == null) {
            loginFail(username);
            return null;
        }
        if (!employeeService.checkPassword(emp, password)) {
            loginFail(username);
            return null;
        }

        redisService.delete(LOGIN_FAIL_PREFIX + username);
        String token = jwtUtil.generateToken(emp.getId(), emp.getUsername(), emp.getRole());
        redisService.saveLoginSession(token, emp.getUsername(), 24);
        log.info("用户登录成功：{}，角色：{}", username, emp.getRole());

        Map<String, Object> data = new HashMap<>();
        data.put("token", token);
        data.put("username", emp.getUsername());
        data.put("name", emp.getName());
        data.put("role", emp.getRole());
        return data;
    }

    /**
     * 登录失败统一处理：记录失败次数，第 5 次锁定 15 分钟
     * 使用 BizException 把业务码带到 Controller，避免账号枚举。
     */
    private void loginFail(String username) {
        int failCount = recordLoginFail(username);
        if (failCount >= MAX_FAIL_COUNT) {
            throw new BizException(403, "密码错误次数过多，账号已锁定15分钟");
        }
        throw new BizException("用户名或密码错误，还可尝试" + (MAX_FAIL_COUNT - failCount) + "次");
    }

    private int recordLoginFail(String username) {
        String failKey = LOGIN_FAIL_PREFIX + username;
        Long count = redisService.increment(failKey, 1);
        if (count == 1) {
            redisService.expire(failKey, LOCK_TIME_MINUTES, TimeUnit.MINUTES);
        }
        if (count >= MAX_FAIL_COUNT) {
            redisService.set(LOGIN_LOCK_PREFIX + username, "1", LOCK_TIME_MINUTES, TimeUnit.MINUTES);
            redisService.delete(failKey);
            return MAX_FAIL_COUNT;
        }
        return count.intValue();
    }

    @Override
    public void logout(String authorizationHeader) {
        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            redisService.logoutSession(authorizationHeader.substring(7));
            log.info("用户注销成功");
        }
    }
}
