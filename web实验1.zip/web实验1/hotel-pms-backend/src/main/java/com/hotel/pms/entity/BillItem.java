package com.hotel.pms.entity;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class BillItem {
    private Long id;
    private String billNo;
    private String itemType;
    private BigDecimal amount;
    private Integer quantity;
    private String payMethod;
    private LocalDateTime itemTime;
    private String createBy;
    private LocalDateTime createTime;
    private String updateBy;
    private LocalDateTime updateTime;
    private Integer isDeleted;
}
