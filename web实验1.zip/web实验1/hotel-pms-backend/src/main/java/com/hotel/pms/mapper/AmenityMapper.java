package com.hotel.pms.mapper;

import com.hotel.pms.entity.Amenity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 设施 Mapper：房间-设施多对多联查由 AmenityMapper.xml 实现
 */
public interface AmenityMapper {

    List<Amenity> findAll();

    List<Amenity> findByRoomId(@Param("roomId") Long roomId);
}
