package com.hotel.pms.modules.employee;

import com.hotel.pms.common.PageResult;
import com.hotel.pms.entity.Employee;
import com.hotel.pms.vo.EmployeeVO;

import java.util.List;

public interface EmployeeService {

    List<EmployeeVO> list();

    PageResult<EmployeeVO> page(int pageNum, int pageSize, String keyword, String role);

    EmployeeVO findById(Long id);

    EmployeeVO create(Employee employee);

    void update(Long id, Employee employee);

    void delete(Long id);

    /** 登录认证使用 */
    Employee findByUsername(String username);

    boolean checkPassword(Employee employee, String rawPassword);
}
