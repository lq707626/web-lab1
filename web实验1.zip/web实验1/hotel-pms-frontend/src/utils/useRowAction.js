import { ref } from 'vue'

/**
 * 行内异步操作状态。
 *
 * 作用：表格每行的异步按钮（删除 / 确认 / 结算 / 退款 ...）都能绑定真实的 :loading，
 * 不再出现"点了没反应"或"自己写转圈动画"的情况；同一时刻只会锁定被点击的那一行。
 *
 * 用法：
 *   const { isPending, run } = useRowAction()
 *   <el-button :loading="isPending(row, 'delete')" ... />
 *   run(row, 'delete', () => api.delete(`/members/${row.id}`))
 */
export function useRowAction() {
  const pendingKey = ref('')

  function keyOf(row, action) {
    return `${action}-${row && row.id !== undefined ? row.id : 'unknown'}`
  }

  function isPending(row, action) {
    return pendingKey.value === keyOf(row, action)
  }

  async function run(row, action, task) {
    pendingKey.value = keyOf(row, action)
    try {
      return await task()
    } finally {
      pendingKey.value = ''
    }
  }

  return { pendingKey, isPending, run }
}