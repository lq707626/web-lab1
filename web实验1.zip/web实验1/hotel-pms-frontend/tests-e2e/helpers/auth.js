// 登录辅助：每个用例前重新走一遍登录流程，保证登录态干净
// 账号密码来自《Vue3 可测试性前端开发要求》任务3 规定：admin / 123456

import { expect } from '@playwright/test'

export const ADMIN_USERNAME = 'admin'
export const ADMIN_PASSWORD = '123456'

/**
 * 以 admin 身份登录并跳转到目标页面。
 * 每个用例 beforeEach 调用，等价于"前置：每个用例执行前自动登录"。
 *
 * @param {import('@playwright/test').Page} page
 * @param {string} [targetPath='/member'] 登录成功后要进入的业务页面
 */
export async function loginAsAdmin(page, targetPath = '/member') {
  await page.goto('/login')
  await page.getByTestId('login-username-input').fill(ADMIN_USERNAME)
  await page.getByTestId('login-password-input').fill(ADMIN_PASSWORD)
  await page.getByTestId('login-submit-btn').click()
  // 等待登录成功提示出现，再跳转目标页
  await expectMessage(page, '登录成功')
  // 登录后默认落在 /room，再路由到目标页面
  await page.goto(targetPath)
  // 等主框架菜单出现，代表页面已经就绪
  await page.getByTestId('layout-menu').waitFor({ state: 'visible' })
}

/**
 * 直接调用登录接口拿 token 写入 localStorage，跳过 UI 登录。
 * 用于"未登录访问 / token 失效"这类反向用例的前置。
 */
export async function seedFakeToken(page, token = 'fake.token.value') {
  await page.goto('/login')
  await page.evaluate(t => {
    localStorage.setItem('token', t)
    localStorage.setItem('userInfo', JSON.stringify({ id: 1, username: 'admin', name: '系统管理员', role: '系统管理员' }))
  }, token)
}

/**
 * 等待 ElMessage 出现并断言文案包含 expected。
 * Element Plus 的 ElMessage 每次挂载都会生成新的 .el-message 节点，
 * 所以用 first() 取当前最新一条，避免命中上一条残留提示。
 */
export async function expectMessage(page, expected, type = 'success') {
  const klass = type === 'error' ? '.el-message--error'
    : type === 'warning' ? '.el-message--warning'
    : '.el-message--success'
  const msg = page.locator(klass).last()
  await msg.waitFor({ state: 'visible', timeout: 8_000 })
  await expectText(msg, expected)
  return msg
}

async function expectText(locator, expected) {
  // ElMessage 文案可能带图标/额外节点，用 toContainText 容错
  await expect(locator).toContainText(expected)
}

/**
 * 确认 Element Plus 的 ElMessageBox 弹窗。
 * 业务页面对话框都有 data-testid，但 MessageBox 是组件库全局浮层，
 * 前端无法加 testid，因此按其默认"确定"按钮文案定位。
 */
export async function confirmMessageBox(page) {
  const box = page.locator('.el-message-box').last()
  await box.waitFor({ state: 'visible', timeout: 5_000 })
  await box.getByRole('button', { name: '确定' }).click()
}

/**
 * 取消 Element Plus 的 ElMessageBox 弹窗。
 */
export async function cancelMessageBox(page) {
  const box = page.locator('.el-message-box').last()
  await box.waitFor({ state: 'visible', timeout: 5_000 })
  await box.getByRole('button', { name: '取消' }).click()
}

/**
 * 在 el-select 里选择一个选项。
 * select 本身有 data-testid，但下拉面板是组件库渲染在 body 下的浮层，
 * 没有 testid，因此按选项可见文本选择（选项文本是业务数据，不是靠 DOM 顺序）。
 *
 * @param {import('@playwright/test').Page} page
 * @param {string} testid
 * @param {string} optionText 选项可见文本，支持子串匹配
 */
export async function selectOption(page, testid, optionText) {
  await page.getByTestId(testid).click()
  // 下拉面板挂在 body 末尾，可见的才是刚打开的那个
  const dropdown = page.locator('.el-select-dropdown:visible').last()
  await dropdown.waitFor({ state: 'visible', timeout: 5_000 })
  await dropdown.locator('.el-select-dropdown__item', { hasText: optionText }).first().click()
}

/**
 * 生成唯一手机号（11 位，13 开头），避免用例间手机号冲突。
 */
export function uniquePhone() {
  // 中国手机号 11 位：前两位 13 + 后 9 位时间戳
  const tail = Date.now().toString().slice(-9)
  return `13${tail}`
}

/**
 * 生成唯一用户名。
 */
export function uniqueUsername(prefix = 'e2e') {
  return `${prefix}${Date.now().toString().slice(-7)}`
}

/**
 * 生成唯一中文姓名。
 */
export function uniqueName(prefix = '测试') {
  return `${prefix}${Date.now().toString().slice(-6)}`
}

/**
 * 返回 N 天后的日期字符串 YYYY-MM-DD，用于预订/入住日期选择。
 */
export function futureDate(daysFromNow) {
  const d = new Date()
  d.setDate(d.getDate() + daysFromNow)
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}
