package com.hotel.pms.modules.checkin;

import cn.hutool.core.util.RandomUtil;
import com.hotel.pms.common.BizException;
import com.hotel.pms.common.PageResult;
import com.hotel.pms.common.RedisService;
import com.hotel.pms.common.SecurityUtil;
import com.hotel.pms.entity.Bill;
import com.hotel.pms.entity.BillItem;
import com.hotel.pms.entity.Checkin;
import com.hotel.pms.entity.Room;
import com.hotel.pms.mapper.BillMapper;
import com.hotel.pms.mapper.CheckinMapper;
import com.hotel.pms.mapper.ReservationMapper;
import com.hotel.pms.mapper.RoomMapper;
import com.hotel.pms.vo.CheckinVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CheckinServiceImpl implements CheckinService {

    private static final Logger log = LoggerFactory.getLogger(CheckinServiceImpl.class);
    private static final String ROOM_LIST_CACHE_KEY = "room:list:v2";

    private final CheckinMapper checkinMapper;
    private final RoomMapper roomMapper;
    private final BillMapper billMapper;
    private final ReservationMapper reservationMapper;
    private final RedisService redisService;

    public CheckinServiceImpl(CheckinMapper checkinMapper,
                              RoomMapper roomMapper,
                              BillMapper billMapper,
                              ReservationMapper reservationMapper,
                              RedisService redisService) {
        this.checkinMapper = checkinMapper;
        this.roomMapper = roomMapper;
        this.billMapper = billMapper;
        this.reservationMapper = reservationMapper;
        this.redisService = redisService;
    }

    @Override
    public List<CheckinVO> list() {
        return checkinMapper.findAll().stream().map(this::toVO).collect(Collectors.toList());
    }

    @Override
    public PageResult<CheckinVO> page(int pageNum, int pageSize, String keyword, String status) {
        pageNum = Math.max(pageNum, 1);
        pageSize = Math.min(Math.max(pageSize, 1), 100);
        int offset = (pageNum - 1) * pageSize;
        List<CheckinVO> records = checkinMapper.findPageVO(offset, pageSize, keyword, status);
        long total = checkinMapper.countVO(keyword, status);
        return new PageResult<>(total, pageNum, pageSize, records);
    }

    @Override
    public CheckinVO findById(Long id) {
        CheckinVO vo = checkinMapper.findVOById(id);
        if (vo == null) {
            throw new BizException("入住记录不存在");
        }
        return vo;
    }

    /**
     * 入住登记：房态校验 -> 生成入住单号 -> 插入 -> 预订置已到店 -> 乐观锁改房态
     */
    @Override
    @Transactional
    public CheckinVO checkin(Checkin checkin) {
        Room room = roomMapper.findById(checkin.getRoomId());
        if (room == null) {
            throw new BizException("房间不存在");
        }
        if (!"空房".equals(room.getRoomStatus()) && !"已预订".equals(room.getRoomStatus())) {
            throw new BizException("当前房态不可入住：" + room.getRoomStatus());
        }
        if (checkin.getGuestName() == null || checkin.getGuestName().trim().isEmpty()) {
            throw new BizException("客人姓名不能为空");
        }
        if (checkin.getIdCard() == null || !checkin.getIdCard().matches("^\\d{17}[\\dXx]$")) {
            throw new BizException("请输入正确的身份证号");
        }
        if (checkin.getDeposit() == null) {
            checkin.setDeposit(BigDecimal.ZERO);
        }
        if (checkin.getDeposit().compareTo(BigDecimal.ZERO) <= 0) {
            throw new BizException("押金金额必须大于0");
        }

        String checkinNo = "CI" + LocalDateTime.now().format(
            DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS")) + RandomUtil.randomNumbers(3);
        checkin.setCheckinNo(checkinNo);
        checkin.setStatus("在住");
        checkin.setCreateBy(SecurityUtil.getCurrentUsername());

        checkinMapper.insert(checkin);
        log.info("入住登记成功，单号：{}，房间：{}，客人：{}",
            checkinNo, room.getRoomNumber(), checkin.getGuestName());

        if (checkin.getReservationId() != null) {
            reservationMapper.markArrived(checkin.getReservationId());
        }

        int rows = roomMapper.updateStatus(checkin.getRoomId(), "已入住", room.getVersion());
        if (rows == 0) {
            throw new BizException("房态已被其他终端修改，请刷新后重试");
        }
        redisService.delete(ROOM_LIST_CACHE_KEY);
        return findById(checkin.getId());
    }

    /**
     * 退房：入住记录置已退房 -> 房态待清洁 -> 生成房费账单
     */
    @Override
    @Transactional
    public void checkout(Long id) {
        Checkin checkin = checkinMapper.findById(id);
        if (checkin == null) {
            throw new BizException("入住记录不存在");
        }
        if (!"在住".equals(checkin.getStatus())) {
            throw new BizException("该订单已退房");
        }
        Room room = roomMapper.findById(checkin.getRoomId());
        if (room == null) {
            throw new BizException("房间不存在");
        }

        checkinMapper.checkout(id);
        int rows = roomMapper.updateStatus(checkin.getRoomId(), "待清洁", room.getVersion());
        if (rows == 0) {
            throw new BizException("房态已被其他终端修改，请刷新后重试");
        }
        generateRoomBill(checkin, room);
        redisService.delete(ROOM_LIST_CACHE_KEY);
        log.info("退房成功，入住单号：{}，房间：{}", checkin.getCheckinNo(), room.getRoomNumber());
    }

    @Override
    @Transactional
    public void update(Long id, Checkin checkin) {
        Checkin existing = checkinMapper.findById(id);
        if (existing == null) {
            throw new BizException("入住记录不存在");
        }
        if ("已退房".equals(existing.getStatus())) {
            throw new BizException("已退房记录不能编辑");
        }
        if (checkin.getGuestName() == null || checkin.getGuestName().trim().isEmpty()) {
            throw new BizException("客人姓名不能为空");
        }
        if (checkin.getIdCard() == null || !checkin.getIdCard().matches("^\\d{17}[\\dXx]$")) {
            throw new BizException("请输入正确的身份证号");
        }
        if (checkin.getDeposit() == null || checkin.getDeposit().compareTo(BigDecimal.ZERO) <= 0) {
            throw new BizException("押金金额必须大于0");
        }
        checkin.setId(id);
        checkinMapper.updateInfo(checkin);
        log.info("入住信息已修改，入住单号：{}", existing.getCheckinNo());
    }

    @Override
    @Transactional
    public void delete(Long id) {
        Checkin existing = checkinMapper.findById(id);
        if (existing == null) {
            throw new BizException("入住记录不存在");
        }
        if ("在住".equals(existing.getStatus())) {
            throw new BizException("在住记录请先办理退房，再删除");
        }
        if (checkinMapper.logicalDelete(id) == 0) {
            throw new BizException("入住记录删除失败，请刷新后重试");
        }
        log.info("入住记录已删除（逻辑删除），入住单号：{}", existing.getCheckinNo());
    }

    private void generateRoomBill(Checkin checkin, Room room) {
        long days = ChronoUnit.DAYS.between(checkin.getCheckinTime(), LocalDateTime.now());
        if (days < 1) {
            days = 1;
        }
        BigDecimal basePrice = room.getBasePrice() != null ? room.getBasePrice() : BigDecimal.ZERO;
        BigDecimal totalAmount = basePrice.multiply(BigDecimal.valueOf(days));

        Bill bill = new Bill();
        String billNo = "BL" + LocalDateTime.now().format(
            DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS")) + RandomUtil.randomNumbers(3);
        bill.setBillNo(billNo);
        bill.setCheckinId(checkin.getId());
        bill.setReceivableAmount(totalAmount);
        bill.setDepositDeduct(checkin.getDeposit() != null ? checkin.getDeposit() : BigDecimal.ZERO);
        bill.setActualAmount(BigDecimal.ZERO);
        bill.setSettleStatus("未结算");
        bill.setCreateBy(SecurityUtil.getCurrentUsername());
        billMapper.insert(bill);

        BillItem item = new BillItem();
        item.setBillNo(billNo);
        item.setItemType("房费");
        item.setAmount(basePrice);
        item.setQuantity((int) days);
        billMapper.batchInsertItems(Collections.singletonList(item));

        log.info("退房生成房费账单，账单号：{}，入住天数：{}，房费总额：{}", billNo, days, totalAmount);
    }

    private CheckinVO toVO(Checkin c) {
        CheckinVO vo = new CheckinVO();
        vo.setId(c.getId());
        vo.setCheckinNo(c.getCheckinNo());
        vo.setReservationId(c.getReservationId());
        vo.setRoomId(c.getRoomId());
        vo.setRoomNumber(c.getRoomNumber());
        vo.setGuestName(c.getGuestName());
        vo.setIdCard(c.getIdCard());
        vo.setPhone(c.getPhone());
        vo.setDeposit(c.getDeposit());
        vo.setCheckinTime(c.getCheckinTime());
        vo.setCheckoutTime(c.getCheckoutTime());
        vo.setStatus(c.getStatus());
        vo.setCreateBy(c.getCreateBy());
        vo.setCreateTime(c.getCreateTime());
        return vo;
    }
}
