package com.hotel.pms.entity;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class Checkin {
    private Long id;
    private String checkinNo;
    private Long reservationId;
    private Long roomId;
    private String guestName;
    private String idCard;
    private String phone;
    private BigDecimal deposit;
    private LocalDateTime checkinTime;
    private LocalDateTime checkoutTime;
    private String status;
    private String createBy;
    private LocalDateTime createTime;
    private String updateBy;
    private LocalDateTime updateTime;
    private Integer isDeleted;
    private String roomNumber;
}
