package com.hotel.pms.mapper;

import com.hotel.pms.entity.RoomType;
import org.apache.ibatis.annotations.*;
import java.util.List;

public interface RoomTypeMapper {
    @Select("SELECT * FROM room_type WHERE is_deleted = 0")
    List<RoomType> findAll();

    @Select("SELECT * FROM room_type WHERE id = #{id} AND is_deleted = 0")
    RoomType findById(@Param("id") Long id);

    @Insert("INSERT INTO room_type(type_name, bed_type, area, base_price, create_by) " +
            "VALUES(#{typeName}, #{bedType}, #{area}, #{basePrice}, #{createBy})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(RoomType roomType);

    @Update("UPDATE room_type SET type_name = #{typeName}, bed_type = #{bedType}, area = #{area}, base_price = #{basePrice}, update_time = NOW() WHERE id = #{id} AND is_deleted = 0")
    int update(RoomType roomType);

    @Update("UPDATE room_type SET is_deleted = 1, update_time = NOW() WHERE id = #{id}")
    int delete(@Param("id") Long id);
}
