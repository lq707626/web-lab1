package com.hotel.pms.mapper;

import com.hotel.pms.entity.Member;
import com.hotel.pms.vo.MemberVO;
import org.apache.ibatis.annotations.*;
import java.util.List;

public interface MemberMapper {
    @Select("SELECT * FROM member WHERE is_deleted = 0 ORDER BY create_time DESC")
    List<Member> findAll();

    @Select("SELECT * FROM member WHERE id = #{id} AND is_deleted = 0")
    Member findById(@Param("id") Long id);

    @Select("SELECT * FROM member WHERE phone = #{phone} AND is_deleted = 0")
    Member findByPhone(@Param("phone") String phone);

    @Insert("INSERT INTO member(name, phone, level, points, balance, create_by) " +
            "VALUES(#{name}, #{phone}, #{level}, #{points}, #{balance}, #{createBy})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Member member);

    @Update("UPDATE member SET name=#{name}, phone=#{phone}, level=#{level}, " +
            "points=#{points}, balance=#{balance}, update_time=NOW() " +
            "WHERE id=#{id} AND is_deleted = 0")
    int update(Member member);

    /**
     * 逻辑删除：手机号追加删除后缀，避免"删除后重新注册同一手机号"触发唯一索引
     * （phone 字段长度 20，后缀压缩到不会超长）
     */
    @Update("UPDATE member SET is_deleted = 1, " +
            "phone = CONCAT('D', UNIX_TIMESTAMP(), SUBSTRING(phone, 1, 3)), " +
            "update_time=NOW() WHERE id=#{id} AND is_deleted = 0")
    int delete(@Param("id") Long id);

    /* ========== 以下方法由 MemberMapper.xml 实现（条件分页） ========== */

    List<MemberVO> findPageVO(@Param("offset") int offset,
                              @Param("size") int size,
                              @Param("keyword") String keyword,
                              @Param("level") String level);

    long countVO(@Param("keyword") String keyword, @Param("level") String level);
}
