<template>
  <el-card shadow="never">
    <el-tabs v-model="activeTab" data-testid="thirdparty-tabs">
      <!-- OTA 渠道同步（前端演示，订单写入本地系统） -->
      <el-tab-pane label="OTA 订单同步演示" name="ota">
        <el-alert
          type="info"
          :closable="false"
          title="说明：携程 / 美团推送仅模拟，订单落地后写入本系统预订表，用于演示渠道订单与房态锁定效果。"
          style="margin-bottom: 14px"
        />

        <div class="btn-group">
          <el-button type="primary" data-testid="thirdparty-ota-ctrip-btn" @click="pushOrder('携程')">
            模拟携程推送订单
          </el-button>
          <el-button type="primary" plain data-testid="thirdparty-ota-meituan-btn" @click="pushOrder('美团')">
            模拟美团推送订单
          </el-button>
          <el-button
            type="danger"
            plain
            :disabled="!canCancel"
            data-testid="thirdparty-ota-cancel-btn"
            @click="cancelChannelOrder"
          >
            模拟渠道推送取消
          </el-button>
          <el-button data-testid="thirdparty-ota-sync-btn" @click="syncRoomStatus">
            手动同步房态（渠道拉取）
          </el-button>
          <el-button data-testid="thirdparty-ota-timeout-btn" @click="simulateTimeout">
            模拟接口超时重试
          </el-button>
          <el-button data-testid="thirdparty-ota-auth-btn" @click="simulateAuthFail">
            模拟错误 AppKey 鉴权
          </el-button>
        </div>

        <el-row :gutter="12" style="margin-top: 16px">
          <el-col :xs="24" :md="12">
            <el-card shadow="never" class="inner-card">
              <template #header>渠道订单落地情况</template>
              <el-table
                :data="channelOrders"
                border
                size="small"
                empty-text="暂无渠道订单，请点击上方按钮模拟推送"
                data-testid="thirdparty-ota-orders-table"
              >
                <el-table-column prop="orderNo" label="订单号" width="180" />
                <el-table-column prop="channel" label="渠道" width="80" />
                <el-table-column prop="guestName" label="客人" width="80" />
                <el-table-column prop="status" label="状态" width="90">
                  <template #default="{ row }">
                    <el-tag :type="row.status === '已取消' ? 'danger' : 'warning'" size="small">{{ row.status }}</el-tag>
                  </template>
                </el-table-column>
              </el-table>
            </el-card>
          </el-col>
          <el-col :xs="24" :md="12">
            <el-card shadow="never" class="inner-card">
              <template #header>接口调用日志（最近 20 条）</template>
              <div class="log-list" data-testid="thirdparty-ota-log-list">
                <div
                  v-for="log in logs"
                  :key="log.id"
                  class="log-item"
                  data-testid="thirdparty-ota-log-item"
                >
                  <span class="log-time">{{ log.time }}</span>
                  <el-tag :type="log.type" size="small" effect="plain">{{ log.tag }}</el-tag>
                  <span class="log-text">{{ log.text }}</span>
                </div>
                <el-empty v-if="logs.length === 0" description="暂无调用日志" :image-size="60" />
              </div>
            </el-card>
          </el-col>
        </el-row>
      </el-tab-pane>

      <!-- 门锁控制面板（纯前端演示） -->
      <el-tab-pane label="门锁控制面板（演示）" name="lock">
        <el-alert
          type="info"
          :closable="false"
          title="说明：门锁为前端模拟演示页，不接真实硬件与后端接口。入住时「发卡」、退房时「销卡」，界面展示房卡状态变化。"
          style="margin-bottom: 14px"
        />

        <el-form inline>
          <el-form-item label="房间">
            <el-select
              v-model="lockRoomId"
              placeholder="选择房间"
              style="width: 220px"
              data-testid="thirdparty-lock-room-select"
            >
              <el-option
                v-for="room in rooms"
                :key="room.id"
                :label="`${room.roomNumber}（${room.roomStatus}）`"
                :value="room.id"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              :disabled="!lockRoomId"
              data-testid="thirdparty-lock-issue-btn"
              @click="issueCard"
            >
              模拟发卡
            </el-button>
            <el-button
              type="danger"
              plain
              :disabled="!activeCard"
              data-testid="thirdparty-lock-cancel-btn"
              @click="cancelCard"
            >
              模拟销卡
            </el-button>
          </el-form-item>
        </el-form>

        <el-descriptions :column="3" border style="margin: 14px 0" title="当前门锁状态">
          <el-descriptions-item label="房间">{{ currentLockRoom?.roomNumber || '-' }}</el-descriptions-item>
          <el-descriptions-item label="门锁状态">
            <el-tag :type="activeCard ? 'success' : 'info'">
              {{ activeCard ? '已开卡（房卡有效）' : '已锁闭（无有效房卡）' }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="有效房卡">{{ activeCard?.cardNo || '无' }}</el-descriptions-item>
        </el-descriptions>

        <el-table
          :data="cardRecords"
          border
          size="small"
          empty-text="暂无房卡记录"
          data-testid="thirdparty-lock-cards-table"
        >
          <el-table-column prop="cardNo" label="房卡编号" width="180" />
          <el-table-column prop="roomNumber" label="房间号" width="100" />
          <el-table-column prop="guestName" label="关联客人" width="120" />
          <el-table-column prop="status" label="状态" width="100">
            <template #default="{ row }">
              <el-tag :type="row.status === '已发卡' ? 'success' : 'info'" size="small">{{ row.status }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="time" label="操作时间" />
        </el-table>
      </el-tab-pane>
    </el-tabs>
  </el-card>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import api from '../api'

const activeTab = ref('ota')
const rooms = ref([])
const roomTypes = ref([])
const channelOrders = ref([])
const logs = ref([])

const lockRoomId = ref(null)
const cardRecords = ref([])

const lockRoom = computed(() => rooms.value.find(room => room.id === lockRoomId.value) || null)
const currentLockRoom = computed(() => lockRoom.value)
const activeCard = computed(() =>
  cardRecords.value.find(record => record.roomId === lockRoomId.value && record.status === '已发卡')
)

const canCancel = computed(() => channelOrders.value.some(order => order.status !== '已取消'))

// 自增 ID，用于 v-for 的 key（替代 index）
let logIdSeq = 0

function nowText() {
  const d = new Date()
  const p = n => String(n).padStart(2, '0')
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
}

function addLog(type, tag, text) {
  logs.value.unshift({ id: ++logIdSeq, time: nowText(), type, tag, text })
  if (logs.value.length > 20) logs.value.pop()
}

function dateAfter(days) {
  const d = new Date()
  d.setDate(d.getDate() + days)
  const p = n => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}

function randomPhone() {
  return '137' + String(Math.floor(Math.random() * 90000000) + 10000000)
}

async function loadBaseData() {
  const [roomRes, typeRes] = await Promise.all([api.get('/rooms'), api.get('/room-types')])
  rooms.value = roomRes.data || []
  roomTypes.value = typeRes.data || []
}

async function pushOrder(channel) {
  if (!roomTypes.value.length) {
    ElMessage.warning('暂无房型数据，无法推送订单')
    return
  }
  const type = roomTypes.value[Math.floor(Math.random() * roomTypes.value.length)]
  const guestName = `${channel}客人${Math.floor(Math.random() * 900 + 100)}`
  try {
    const res = await api.post('/reservations', {
      guestName,
      phone: randomPhone(),
      roomTypeId: type.id,
      checkInDate: dateAfter(1),
      checkOutDate: dateAfter(3),
      roomCount: 1,
      remark: `OTA渠道推送：${channel}`
    })
    const order = {
      id: res.data.id,
      orderNo: res.data.orderNo,
      channel,
      guestName,
      status: res.data.status
    }
    channelOrders.value.unshift(order)
    addLog('success', '200', `${channel} 推送订单成功：${order.orderNo}，房型库存已锁定`)
    ElMessage.success(`${channel} 订单已落地，状态：待确认`)
  } catch (e) {
    addLog('danger', '500', `${channel} 推送订单失败`)
  }
}

async function cancelChannelOrder() {
  const target = channelOrders.value.find(order => order.status !== '已取消')
  if (!target) {
    ElMessage.info('暂无可取消的渠道订单')
    return
  }
  try {
    await api.put(`/reservations/${target.id}/cancel`, { reason: `OTA渠道取消：${target.channel}` })
    target.status = '已取消'
    addLog('warning', '200', `${target.channel} 推送取消订单：${target.orderNo}，房型库存已释放`)
    ElMessage.success('渠道取消成功，订单状态已变为已取消')
  } catch (e) {
    addLog('danger', '500', `取消订单失败：${target.orderNo}`)
  }
}

async function syncRoomStatus() {
  try {
    const res = await api.get('/rooms')
    rooms.value = res.data || []
    const summary = ['空房', '已入住', '已预订', '维修中', '待清洁']
      .map(status => `${status}${rooms.value.filter(r => r.roomStatus === status).length}间`)
      .join(' / ')
    addLog('success', '200', `从渠道拉取房态成功，共 ${rooms.value.length} 间：${summary}`)
    ElMessage.success('房态同步完成')
  } catch (e) {
    addLog('danger', '500', '房态同步失败')
  }
}

/**
 * 模拟接口超时重试：不再使用 setTimeout 延时，
 * 而是直接按顺序写入日志（同步操作），用 loading 状态作为等待信号。
 */
function simulateTimeout() {
  addLog('warning', '重试1', '调用渠道接口超时（3000ms），准备第 1 次重试')
  addLog('warning', '重试2', '调用渠道接口超时（3000ms），准备第 2 次重试')
  addLog('warning', '重试3', '调用渠道接口超时（3000ms），准备第 3 次重试')
  addLog('danger', '失败', '重试 3 次仍失败，已记录异常日志并进入人工处理队列')
  ElMessage.warning('接口重试 3 次后失败，已记录日志')
}

function simulateAuthFail() {
  addLog('danger', '401', 'AppKey 校验失败：未授权访问，拒绝本次渠道请求')
  ElMessage.error('接口鉴权失败：401 未授权')
}

function issueCard() {
  const room = lockRoom.value
  if (!room) return
  const record = {
    roomId: room.id,
    roomNumber: room.roomNumber,
    cardNo: `CARD${Date.now().toString().slice(-8)}`,
    guestName: channelOrders.value[0]?.guestName || '在住客人',
    status: '已发卡',
    time: `${dateAfter(0)} ${nowText()}`
  }
  // 同一房间旧卡自动失效
  cardRecords.value
    .filter(item => item.roomId === room.id && item.status === '已发卡')
    .forEach(item => {
      item.status = '已销卡'
    })
  cardRecords.value.unshift(record)
  ElMessage.success('发卡成功')
}

function cancelCard() {
  if (!activeCard.value) return
  activeCard.value.status = '已销卡'
  ElMessage.success('房卡已注销')
}

onMounted(loadBaseData)
</script>

<style scoped>
.btn-group {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}
.inner-card {
  height: 100%;
}
.log-list {
  max-height: 320px;
  overflow-y: auto;
}
.log-item {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 6px 0;
  border-bottom: 1px dashed #ebeef5;
  font-size: 13px;
}
.log-time {
  color: #a8abb2;
  flex-shrink: 0;
}
.log-text {
  color: #606266;
  line-height: 1.5;
}
</style>