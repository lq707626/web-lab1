package com.hotel.pms.modules.room;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hotel.pms.common.BizException;
import com.hotel.pms.common.RedisService;
import com.hotel.pms.entity.Room;
import com.hotel.pms.mapper.AmenityMapper;
import com.hotel.pms.mapper.RoomMapper;
import com.hotel.pms.vo.RoomVO;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

@Service
public class RoomServiceImpl implements RoomService {

    private final RoomMapper roomMapper;
    private final AmenityMapper amenityMapper;
    private final RedisService redisService;
    private final ObjectMapper objectMapper;

    private static final String ROOM_LIST_CACHE_KEY = "room:list:v2";
    private static final Set<String> VALID_STATUS =
        Set.of("空房", "已入住", "已预订", "维修中", "待清洁");

    public RoomServiceImpl(RoomMapper roomMapper,
                           AmenityMapper amenityMapper,
                           RedisService redisService,
                           ObjectMapper objectMapper) {
        this.roomMapper = roomMapper;
        this.amenityMapper = amenityMapper;
        this.redisService = redisService;
        this.objectMapper = objectMapper;
    }

    /**
     * 房态列表：先查 Redis 缓存，未命中查库（房间 + 房型 + 门锁 + 设施）后回写缓存
     */
    @Override
    public List<RoomVO> list() {
        String cacheJson = redisService.get(ROOM_LIST_CACHE_KEY);
        if (cacheJson != null) {
            try {
                return objectMapper.readValue(cacheJson,
                    objectMapper.getTypeFactory().constructCollectionType(List.class, RoomVO.class));
            } catch (Exception e) {
                // 反序列化失败则回源数据库
            }
        }

        List<RoomVO> rooms = roomMapper.findAllVO();
        rooms.forEach(this::fillAmenities);

        try {
            String json = objectMapper.writeValueAsString(rooms);
            redisService.set(ROOM_LIST_CACHE_KEY, json, 5, TimeUnit.MINUTES);
        } catch (Exception e) {
            // 缓存写入失败不影响主流程
        }
        return rooms;
    }

    @Override
    public RoomVO findById(Long id) {
        RoomVO room = roomMapper.findDetailById(id);
        if (room == null) {
            throw new BizException("房间不存在");
        }
        fillAmenities(room);
        return room;
    }

    private void fillAmenities(RoomVO room) {
        room.setAmenities(amenityMapper.findByRoomId(room.getId()));
    }

    /**
     * 修改房态：枚举校验 + 流转校验 + version 乐观锁
     */
    @Override
    public void updateStatus(Long id, String status, Integer version) {
        if (status == null || !VALID_STATUS.contains(status)) {
            throw new BizException("非法的房态值：" + status);
        }
        Room room = roomMapper.findById(id);
        if (room == null) {
            throw new BizException("房间不存在");
        }
        if (status.equals(room.getRoomStatus())) {
            return;
        }
        if (!isTransitionAllowed(room.getRoomStatus(), status)) {
            if ("已入住".equals(room.getRoomStatus())) {
                throw new BizException("房间正在入住中，请先办理退房再修改房态");
            }
            throw new BizException("房态不能从「" + room.getRoomStatus()
                + "」直接变更为「" + status + "」");
        }

        int rows = roomMapper.updateStatus(id, status, version);
        if (rows == 0) {
            throw new BizException("房态已被其他终端修改，请刷新后重试");
        }
        redisService.delete(ROOM_LIST_CACHE_KEY);
    }

    private boolean isTransitionAllowed(String from, String to) {
        if (from == null) {
            return true;
        }
        switch (from) {
            case "空房":
                return !"空房".equals(to);
            case "已预订":
                return "空房".equals(to) || "已入住".equals(to) || "维修中".equals(to);
            case "已入住":
                // 已入住必须走退房流程，禁止手工改房态
                return false;
            case "维修中":
                return "空房".equals(to) || "待清洁".equals(to);
            case "待清洁":
                return "空房".equals(to) || "维修中".equals(to);
            default:
                return true;
        }
    }
}
