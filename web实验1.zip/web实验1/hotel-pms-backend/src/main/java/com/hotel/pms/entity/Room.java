package com.hotel.pms.entity;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class Room {
    private Long id;
    private String roomNumber;
    private Long roomTypeId;
    private Integer floor;
    private String roomStatus;
    private String remark;
    private Integer version;
    private String createBy;
    private LocalDateTime createTime;
    private String updateBy;
    private LocalDateTime updateTime;
    private Integer isDeleted;
    // 联表查询字段
    private String typeName;
    private String bedType;
    private java.math.BigDecimal basePrice;
}
