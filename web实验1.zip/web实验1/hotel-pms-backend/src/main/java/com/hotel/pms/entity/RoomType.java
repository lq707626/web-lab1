package com.hotel.pms.entity;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class RoomType {
    private Long id;
    private String typeName;
    private String bedType;
    private BigDecimal area;
    private BigDecimal basePrice;
    private String createBy;
    private LocalDateTime createTime;
    private String updateBy;
    private LocalDateTime updateTime;
    private Integer isDeleted;
}
