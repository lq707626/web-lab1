// 会员管理模块 E2E
// 对应用例：报告 7.2.7 会员管理模块测试
import { test, expect } from '@playwright/test'
import {
  loginAsAdmin,
  expectMessage,
  confirmMessageBox,
  selectOption,
  uniquePhone,
  uniqueName
} from './helpers/auth.js'

test.describe('会员管理', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page, '/member')
  })

  test('新增会员：填写姓名/手机号/等级/初始余额后保存成功', async ({ page }) => {
    const phone = uniquePhone()
    const name = uniqueName('E2E会员')

    await page.getByTestId('member-add-btn').click()
    await page.getByTestId('member-add-dialog').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/member-01-add-dialog.png', fullPage: true })

    await page.getByTestId('member-add-name-input').fill(name)
    await page.getByTestId('member-add-phone-input').fill(phone)
    await selectOption(page, 'member-add-level-select', '普通会员')
    // 初始余额使用 el-input-number，直接 fill input
    await page.getByTestId('member-add-balance-input').locator('input').fill('100')

    await page.getByTestId('member-add-submit-btn').click()
    await expectMessage(page, '会员添加成功')

    // 用刚新增的手机号搜出来，确认列表有这条记录
    await page.getByTestId('member-keyword-input').fill(phone)
    await page.getByTestId('member-search-btn').click()
    await page.getByTestId('member-row').first().waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/member-01-add-success.png', fullPage: true })
  })

  test('手机号格式不正确时前端校验拦截，不提交', async ({ page }) => {
    await page.getByTestId('member-add-btn').click()
    await page.getByTestId('member-add-dialog').waitFor({ state: 'visible' })

    await page.getByTestId('member-add-name-input').fill('格式校验')
    await page.getByTestId('member-add-phone-input').fill('123') // 非法手机号
    await page.getByTestId('member-add-submit-btn').click()

    // 精确到字段的错误提示
    await expect(page.locator('.el-form-item__error').first()).toContainText(/手机号/)
    // 弹窗不关闭
    await page.getByTestId('member-add-dialog').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/member-02-phone-invalid.png', fullPage: true })
  })

  test('姓名为空时提示"会员姓名不能为空"', async ({ page }) => {
    await page.getByTestId('member-add-btn').click()
    await page.getByTestId('member-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('member-add-phone-input').fill(uniquePhone())
    await page.getByTestId('member-add-submit-btn').click()

    await expect(page.locator('.el-form-item__error').first()).toContainText(/会员姓名不能为空/)
    await page.getByTestId('member-add-dialog').waitFor({ state: 'visible' })
  })

  test('编辑会员：修改姓名与等级后保存', async ({ page }) => {
    // 先造一条数据
    const phone = uniquePhone()
    const name = uniqueName('待编辑')
    await page.getByTestId('member-add-btn').click()
    await page.getByTestId('member-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('member-add-name-input').fill(name)
    await page.getByTestId('member-add-phone-input').fill(phone)
    await selectOption(page, 'member-add-level-select', '普通会员')
    await page.getByTestId('member-add-submit-btn').click()
    await expectMessage(page, '会员添加成功')

    // 搜出来点编辑
    await page.getByTestId('member-keyword-input').fill(phone)
    await page.getByTestId('member-search-btn').click()
    await page.getByTestId('member-row').first().waitFor({ state: 'visible' })
    await page.getByTestId('member-row').first().getByTestId('member-edit-btn').click()

    await page.getByTestId('member-edit-dialog').waitFor({ state: 'visible' })
    const newName = uniqueName('已编辑')
    await page.getByTestId('member-edit-name-input').fill(newName)
    await selectOption(page, 'member-edit-level-select', '银卡会员')
    await page.screenshot({ path: 'tests-e2e/screenshots/member-03-edit-dialog.png', fullPage: true })
    await page.getByTestId('member-edit-submit-btn').click()

    await expectMessage(page, '会员信息已更新')
    await page.screenshot({ path: 'tests-e2e/screenshots/member-03-edit-success.png', fullPage: true })
  })

  test('积分充值：输入积分后提示成功', async ({ page }) => {
    const phone = uniquePhone()
    await page.getByTestId('member-add-btn').click()
    await page.getByTestId('member-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('member-add-name-input').fill(uniqueName('积分'))
    await page.getByTestId('member-add-phone-input').fill(phone)
    await selectOption(page, 'member-add-level-select', '普通会员')
    await page.getByTestId('member-add-submit-btn').click()
    await expectMessage(page, '会员添加成功')

    await page.getByTestId('member-keyword-input').fill(phone)
    await page.getByTestId('member-search-btn').click()
    await page.getByTestId('member-row').first().waitFor({ state: 'visible' })
    await page.getByTestId('member-row').first().getByTestId('member-points-btn').click()

    await page.getByTestId('member-points-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('member-points-input').locator('input').fill('100')
    await page.screenshot({ path: 'tests-e2e/screenshots/member-04-points-dialog.png', fullPage: true })
    await page.getByTestId('member-points-submit-btn').click()

    await expectMessage(page, '积分充值成功')
    await page.screenshot({ path: 'tests-e2e/screenshots/member-04-points-success.png', fullPage: true })
  })

  test('余额充值：输入金额后提示成功', async ({ page }) => {
    const phone = uniquePhone()
    await page.getByTestId('member-add-btn').click()
    await page.getByTestId('member-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('member-add-name-input').fill(uniqueName('充值'))
    await page.getByTestId('member-add-phone-input').fill(phone)
    await selectOption(page, 'member-add-level-select', '普通会员')
    await page.getByTestId('member-add-submit-btn').click()
    await expectMessage(page, '会员添加成功')

    await page.getByTestId('member-keyword-input').fill(phone)
    await page.getByTestId('member-search-btn').click()
    await page.getByTestId('member-row').first().waitFor({ state: 'visible' })
    await page.getByTestId('member-row').first().getByTestId('member-recharge-btn').click()

    await page.getByTestId('member-recharge-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('member-recharge-input').locator('input').fill('200')
    await page.getByTestId('member-recharge-submit-btn').click()

    await expectMessage(page, '余额充值成功')
    await page.screenshot({ path: 'tests-e2e/screenshots/member-05-recharge-success.png', fullPage: true })
  })

  test('删除会员：弹确认框，确认后提示成功', async ({ page }) => {
    const phone = uniquePhone()
    await page.getByTestId('member-add-btn').click()
    await page.getByTestId('member-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('member-add-name-input').fill(uniqueName('待删除'))
    await page.getByTestId('member-add-phone-input').fill(phone)
    await selectOption(page, 'member-add-level-select', '普通会员')
    await page.getByTestId('member-add-submit-btn').click()
    await expectMessage(page, '会员添加成功')

    await page.getByTestId('member-keyword-input').fill(phone)
    await page.getByTestId('member-search-btn').click()
    await page.getByTestId('member-row').first().waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/member-06-before-delete.png', fullPage: true })
    await page.getByTestId('member-row').first().getByTestId('member-delete-btn').click()

    // ElMessageBox 确认
    await confirmMessageBox(page)
    await expectMessage(page, '会员已删除')

    // 再次查询应该空列表
    await page.getByTestId('member-search-btn').click()
    await page.getByTestId('member-table').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/member-06-after-delete.png', fullPage: true })
  })

  test('查询不存在的手机号，显示空列表不报错', async ({ page }) => {
    await page.getByTestId('member-keyword-input').fill('00000000000')
    await page.getByTestId('member-search-btn').click()
    // 表格仍在，只是没有 row
    await page.getByTestId('member-table').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/member-07-empty.png', fullPage: true })
  })

  test('手机号重复时提示"该手机号已注册为会员"', async ({ page }) => {
    // 先造一个会员
    const phone = uniquePhone()
    await page.getByTestId('member-add-btn').click()
    await page.getByTestId('member-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('member-add-name-input').fill(uniqueName('重复'))
    await page.getByTestId('member-add-phone-input').fill(phone)
    await selectOption(page, 'member-add-level-select', '普通会员')
    await page.getByTestId('member-add-submit-btn').click()
    await expectMessage(page, '会员添加成功')

    // 再用同手机号新增
    await page.getByTestId('member-add-btn').click()
    await page.getByTestId('member-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('member-add-name-input').fill(uniqueName('重复2'))
    await page.getByTestId('member-add-phone-input').fill(phone)
    await selectOption(page, 'member-add-level-select', '普通会员')
    await page.getByTestId('member-add-submit-btn').click()

    const err = page.locator('.el-message--error').last()
    await err.waitFor({ state: 'visible', timeout: 8_000 })
    await expect(err).toContainText(/手机号已注册/)
    await page.screenshot({ path: 'tests-e2e/screenshots/member-08-duplicate-phone.png', fullPage: true })
  })

  test('等级筛选：选金卡会员后列表只显示金卡', async ({ page }) => {
    await selectOption(page, 'member-level-select', '金卡会员')
    await page.getByTestId('member-search-btn').click()
    await page.getByTestId('member-table').waitFor({ state: 'visible' })
    const rows = page.locator('tr:has([data-testid="member-row"])')
    const n = await rows.count()
    for (let i = 0; i < Math.min(n, 3); i++) {
      await expect(rows.nth(i)).toContainText('金卡会员')
    }
    await page.screenshot({ path: 'tests-e2e/screenshots/member-09-level-filter.png', fullPage: true })
  })

  test('会员流水：点击流水按钮弹窗展示流水表', async ({ page }) => {
    // 先造一个会员并充值
    const phone = uniquePhone()
    await page.getByTestId('member-add-btn').click()
    await page.getByTestId('member-add-dialog').waitFor({ state: 'visible' })
    await page.getByTestId('member-add-name-input').fill(uniqueName('流水'))
    await page.getByTestId('member-add-phone-input').fill(phone)
    await selectOption(page, 'member-add-level-select', '普通会员')
    await page.getByTestId('member-add-submit-btn').click()
    await expectMessage(page, '会员添加成功')

    await page.getByTestId('member-keyword-input').fill(phone)
    await page.getByTestId('member-search-btn').click()
    await page.getByTestId('member-row').first().waitFor({ state: 'visible' })
    await page.getByTestId('member-row').first().getByTestId('member-transactions-btn').click()
    await page.getByTestId('member-transactions-dialog').waitFor({ state: 'visible' })
    await expect(page.getByTestId('member-transactions-table')).toBeVisible()
    await page.screenshot({ path: 'tests-e2e/screenshots/member-11-transactions.png', fullPage: true })
    await page.getByTestId('member-transactions-close-btn').click()
  })

  test('手机号脱敏：列表手机号显示为 138****1234 格式', async ({ page }) => {
    await page.getByTestId('member-table').waitFor({ state: 'visible' })
    const rows = page.locator('tr:has([data-testid="member-row"])')
    if ((await rows.count()) === 0) {
      test.info().annotations.push({ type: 'skip', description: '无会员数据' })
      return
    }
    // 手机号列应包含 ****
    await expect(rows.first()).toContainText('****')
    await page.screenshot({ path: 'tests-e2e/screenshots/member-12-mask.png', fullPage: true })
  })

  test('分页器可见，可点击下一页', async ({ page }) => {
    await page.getByTestId('member-pagination').waitFor({ state: 'visible' })
    await page.screenshot({ path: 'tests-e2e/screenshots/member-08-pagination.png', fullPage: true })
  })
})
