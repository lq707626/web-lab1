package com.hotel.pms.modules.reservation;

import cn.hutool.core.util.RandomUtil;
import com.hotel.pms.common.BizException;
import com.hotel.pms.common.PageResult;
import com.hotel.pms.common.SecurityUtil;
import com.hotel.pms.entity.Reservation;
import com.hotel.pms.mapper.ReservationMapper;
import com.hotel.pms.mapper.RoomMapper;
import com.hotel.pms.vo.ReservationVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReservationServiceImpl implements ReservationService {

    private static final Logger log = LoggerFactory.getLogger(ReservationServiceImpl.class);

    private final ReservationMapper reservationMapper;
    private final RoomMapper roomMapper;

    public ReservationServiceImpl(ReservationMapper reservationMapper, RoomMapper roomMapper) {
        this.reservationMapper = reservationMapper;
        this.roomMapper = roomMapper;
    }

    @Override
    public List<ReservationVO> list() {
        return reservationMapper.findAll().stream().map(this::toVO).collect(Collectors.toList());
    }

    @Override
    public PageResult<ReservationVO> page(int pageNum, int pageSize, String keyword, String status) {
        pageNum = Math.max(pageNum, 1);
        pageSize = Math.min(Math.max(pageSize, 1), 100);
        int offset = (pageNum - 1) * pageSize;
        List<ReservationVO> records = reservationMapper.findPageVO(offset, pageSize, keyword, status);
        long total = reservationMapper.countVO(keyword, status);
        return new PageResult<>(total, pageNum, pageSize, records);
    }

    @Override
    public ReservationVO findById(Long id) {
        ReservationVO vo = reservationMapper.findVOById(id);
        if (vo == null) {
            throw new BizException("预订记录不存在");
        }
        return vo;
    }

    /**
     * 新增预订：日期校验 + 按房型/日期区间校验库存 + 生成订单号与查询码
     */
    @Override
    @Transactional
    public ReservationVO create(Reservation reservation) {
        validateDates(reservation);
        int roomCount = reservation.getRoomCount() != null ? reservation.getRoomCount() : 1;
        reservation.setRoomCount(roomCount);

        int totalRooms = roomMapper.countByTypeId(reservation.getRoomTypeId());
        if (totalRooms <= 0) {
            throw new BizException("所选房型暂无可售房间");
        }
        int occupiedRooms = reservationMapper.countOverlapByTypeId(
            reservation.getRoomTypeId(), reservation.getCheckInDate(), reservation.getCheckOutDate());
        if (occupiedRooms + roomCount > totalRooms) {
            throw new BizException("该房型在所选日期可用房间不足，当前可预订"
                + Math.max(0, totalRooms - occupiedRooms) + "间");
        }

        String orderNo = "RS" + LocalDateTime.now().format(
            DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS")) + RandomUtil.randomNumbers(3);
        reservation.setOrderNo(orderNo);
        reservation.setStatus("待确认");
        reservation.setQueryCode(RandomUtil.randomNumbers(6));
        reservation.setCreateBy(SecurityUtil.getCurrentUsername());

        reservationMapper.insert(reservation);
        log.info("预订创建成功，订单号：{}，客人：{}", orderNo, reservation.getGuestName());
        return findById(reservation.getId());
    }

    /**
     * 编辑预订：修改客人/日期/房型/间数，库存校验时排除自身
     */
    @Override
    @Transactional
    public void update(Long id, Reservation reservation) {
        Reservation existing = reservationMapper.findById(id);
        if (existing == null) {
            throw new BizException("预订记录不存在");
        }
        if ("已取消".equals(existing.getStatus()) || "已离店".equals(existing.getStatus())) {
            throw new BizException("已取消/已离店的预订不能编辑");
        }
        validateDates(reservation);

        int roomCount = reservation.getRoomCount() != null ? reservation.getRoomCount() : 1;
        reservation.setRoomCount(roomCount);
        int totalRooms = roomMapper.countByTypeId(reservation.getRoomTypeId());
        int occupied = reservationMapper.countOverlapExcludeId(
            reservation.getRoomTypeId(), reservation.getCheckInDate(), reservation.getCheckOutDate(), id);
        if (totalRooms <= 0 || occupied + roomCount > totalRooms) {
            throw new BizException("该房型在所选日期可用房间不足，当前可预订"
                + Math.max(0, totalRooms - occupied) + "间");
        }

        reservation.setId(id);
        reservationMapper.updateInfo(reservation);
        log.info("预订信息已修改，订单号：{}", existing.getOrderNo());
    }

    @Override
    @Transactional
    public void delete(Long id) {
        if (reservationMapper.findById(id) == null) {
            throw new BizException("预订记录不存在");
        }
        if (reservationMapper.logicalDelete(id) == 0) {
            throw new BizException("预订删除失败，请刷新后重试");
        }
        log.info("预订已删除（逻辑删除），ID：{}", id);
    }

    @Override
    @Transactional
    public void confirm(Long id) {
        Reservation reservation = reservationMapper.findById(id);
        if (reservation == null) {
            throw new BizException("预订记录不存在");
        }
        if (!"待确认".equals(reservation.getStatus())) {
            throw new BizException("只有待确认状态的预订才能确认");
        }
        reservationMapper.updateStatus(id, "已确认");
        log.info("预订确认成功，订单号：{}", reservation.getOrderNo());
    }

    @Override
    @Transactional
    public void cancel(Long id, String reason) {
        Reservation reservation = reservationMapper.findById(id);
        if (reservation == null) {
            throw new BizException("预订记录不存在");
        }
        if ("已取消".equals(reservation.getStatus())) {
            throw new BizException("该预订已取消");
        }
        if ("已离店".equals(reservation.getStatus())) {
            throw new BizException("该订单已离店，不能取消");
        }
        reservationMapper.cancel(id, reason);
        log.info("预订取消成功，订单号：{}，原因：{}", reservation.getOrderNo(),
            reason == null || reason.isEmpty() ? "未填写" : reason);
    }

    @Override
    public ReservationVO queryByPhoneAndCode(String phone, String queryCode) {
        Reservation reservation = reservationMapper.findByPhoneAndQueryCode(phone, queryCode);
        return reservation == null ? null : toVO(reservation);
    }

    private void validateDates(Reservation reservation) {
        if (reservation.getCheckInDate() == null || reservation.getCheckOutDate() == null) {
            throw new BizException("入住日期和离店日期不能为空");
        }
        if (!reservation.getCheckOutDate().isAfter(reservation.getCheckInDate())) {
            throw new BizException("离店日期必须晚于入住日期");
        }
        if (reservation.getGuestName() == null || reservation.getGuestName().trim().isEmpty()) {
            throw new BizException("客人姓名不能为空");
        }
        if (reservation.getPhone() == null || !reservation.getPhone().matches("^1[3-9]\\d{9}$")) {
            throw new BizException("请输入正确的手机号");
        }
    }

    private ReservationVO toVO(Reservation r) {
        ReservationVO vo = new ReservationVO();
        vo.setId(r.getId());
        vo.setOrderNo(r.getOrderNo());
        vo.setGuestName(r.getGuestName());
        vo.setPhone(r.getPhone());
        vo.setCheckInDate(r.getCheckInDate());
        vo.setCheckOutDate(r.getCheckOutDate());
        vo.setRoomTypeId(r.getRoomTypeId());
        vo.setTypeName(r.getTypeName());
        vo.setRoomCount(r.getRoomCount());
        vo.setStatus(r.getStatus());
        vo.setQueryCode(r.getQueryCode());
        vo.setRemark(r.getRemark());
        vo.setCreateBy(r.getCreateBy());
        vo.setCreateTime(r.getCreateTime());
        vo.setUpdateTime(r.getUpdateTime());
        return vo;
    }
}
