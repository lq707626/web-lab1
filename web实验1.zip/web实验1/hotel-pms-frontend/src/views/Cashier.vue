<template>
  <div>
    <el-row :gutter="12" class="stat-row">
      <el-col :xs="12" :sm="6">
        <el-card shadow="never" class="stat-card">
          <div class="stat-label">待结算账单</div>
          <div class="stat-value" data-testid="cashier-pending-count">{{ pendingList.length }} 张</div>
        </el-card>
      </el-col>
      <el-col :xs="12" :sm="6">
        <el-card shadow="never" class="stat-card">
          <div class="stat-label">待收金额</div>
          <div class="stat-value warning" data-testid="cashier-pending-amount">¥{{ money(pendingAmount) }}</div>
        </el-card>
      </el-col>
      <el-col :xs="12" :sm="6">
        <el-card shadow="never" class="stat-card">
          <div class="stat-label">今日收款</div>
          <div class="stat-value success" data-testid="cashier-today-amount">¥{{ money(todayAmount) }}</div>
        </el-card>
      </el-col>
      <el-col :xs="12" :sm="6">
        <el-card shadow="never" class="stat-card">
          <div class="stat-label">今日已结算</div>
          <div class="stat-value" data-testid="cashier-today-settled">{{ todaySettled.length }} 笔</div>
        </el-card>
      </el-col>
    </el-row>

    <el-card shadow="never">
      <div class="toolbar">
        <el-input
          v-model="keyword"
          placeholder="按账单号 / 客人 / 房间号查询"
          clearable
          style="width: 280px"
          :prefix-icon="Search"
          data-testid="cashier-keyword-input"
        />
        <el-button
          type="primary"
          plain
          :icon="Document"
          data-testid="cashier-daily-btn"
          @click="openDaily"
        >
          日结统计
        </el-button>
      </div>

      <el-table
        :data="filteredList"
        border
        stripe
        v-loading="loading"
        empty-text="暂无待结算账单"
        data-testid="cashier-table"
      >
        <el-table-column prop="billNo" label="账单号" width="190" />
        <el-table-column label="客人" width="100">
          <template #default="{ row }">{{ row.guestName || '-' }}</template>
        </el-table-column>
        <el-table-column label="房间号" width="90">
          <template #default="{ row }">{{ row.roomNumber || '-' }}</template>
        </el-table-column>
        <el-table-column label="应收金额" width="110">
          <template #default="{ row }">¥{{ money(row.receivableAmount) }}</template>
        </el-table-column>
        <el-table-column label="押金抵扣" width="110">
          <template #default="{ row }">¥{{ money(row.depositDeduct) }}</template>
        </el-table-column>
        <el-table-column label="需收金额" width="110">
          <template #default="{ row }">¥{{ money(payableOf(row)) }}</template>
        </el-table-column>
        <el-table-column label="创建时间" width="170">
          <template #default="{ row }">{{ formatTime(row.createTime) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="120" fixed="right">
          <template #default="{ row }">
            <div data-testid="cashier-row" :data-bill-id="row.id">
              <el-button
                size="small"
                type="primary"
                data-testid="cashier-pay-btn"
                @click="openPay(row)"
              >
                收款
              </el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 收款 -->
    <el-dialog v-model="payVisible" title="收款结算" width="560px" data-testid="cashier-pay-dialog">
      <el-descriptions :column="2" border size="small">
        <el-descriptions-item label="账单号" :span="2">{{ currentBill?.billNo }}</el-descriptions-item>
        <el-descriptions-item label="客人">{{ currentBill?.guestName || '-' }}</el-descriptions-item>
        <el-descriptions-item label="房间号">{{ currentBill?.roomNumber || '-' }}</el-descriptions-item>
        <el-descriptions-item label="应收金额">¥{{ money(currentBill?.receivableAmount) }}</el-descriptions-item>
        <el-descriptions-item label="押金抵扣">¥{{ money(currentBill?.depositDeduct) }}</el-descriptions-item>
        <el-descriptions-item label="需收金额" :span="2">
          <span class="payable" data-testid="cashier-pay-amount">¥{{ money(payable) }}</span>
        </el-descriptions-item>
      </el-descriptions>

      <el-form label-width="90px" style="margin-top: 14px">
        <el-form-item label="支付方式">
          <el-radio-group v-model="payMethod" data-testid="cashier-pay-method-group">
            <el-radio-button
              v-for="m in payMethods"
              :key="m.code"
              :value="m.label"
              :data-testid="`cashier-pay-method-${m.code}`"
            >
              {{ m.label }}
            </el-radio-button>
          </el-radio-group>
        </el-form-item>

        <el-form-item v-if="payMethod === '现金'" label="实收现金">
          <el-input-number
            v-model="received"
            :min="0"
            :precision="2"
            :step="50"
            data-testid="cashier-cash-received-input"
          />
          <span class="change-tip">
            找零：<b data-testid="cashier-cash-change">¥{{ money(Math.max(0, Number(received) - payable)) }}</b>
          </span>
        </el-form-item>

        <el-form-item v-if="payMethod === '会员余额'" label="会员">
          <el-select
            v-model="memberId"
            filterable
            placeholder="按姓名 / 手机号选择会员"
            style="width: 100%"
            data-testid="cashier-member-select"
          >
            <el-option
              v-for="m in members"
              :key="m.id"
              :label="`${m.name}（${maskPhone(m.phone)}）余额 ¥${money(m.balance)}`"
              :value="m.id"
            />
          </el-select>
          <div v-if="selectedMember" class="change-tip">
            可用余额 ¥{{ money(selectedMember.balance) }}
            <span v-if="Number(selectedMember.balance) < payable" class="danger-text">（余额不足）</span>
          </div>
        </el-form-item>

        <el-form-item v-if="payMethod === '微信支付' || payMethod === '支付宝'" label="沙箱支付">
          <el-alert
            type="info"
            :closable="false"
            title="点击确认后调用沙箱下单 + 支付回调，回调成功自动结算账单"
          />
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button data-testid="cashier-pay-cancel-btn" @click="payVisible = false">取消</el-button>
        <el-button type="primary" :loading="paying" data-testid="cashier-pay-submit-btn" @click="submitPay">
          确认收款
        </el-button>
      </template>
    </el-dialog>

    <!-- 日结 -->
    <el-dialog v-model="dailyVisible" title="收银日结" width="560px" data-testid="cashier-daily-dialog">
      <el-descriptions :column="2" border size="small">
        <el-descriptions-item label="已结算账单数">{{ todaySettled.length }} 笔</el-descriptions-item>
        <el-descriptions-item label="收款总额">¥{{ money(todayAmount) }}</el-descriptions-item>
      </el-descriptions>
      <el-table :data="dailyRows" border size="small" style="margin-top: 12px" empty-text="今日暂无收款记录" data-testid="cashier-daily-table">
        <el-table-column prop="channel" label="支付方式" />
        <el-table-column prop="count" label="笔数" width="100" align="center" />
        <el-table-column label="金额" width="140" align="right">
          <template #default="{ row }">¥{{ money(row.amount) }}</template>
        </el-table-column>
      </el-table>
      <template #footer>
        <el-button data-testid="cashier-daily-close-btn" @click="dailyVisible = false">关闭</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Document, Search } from '@element-plus/icons-vue'
import api from '../api'
import { maskPhone, money, todayStr } from '../utils/format'

const bills = ref([])
const payments = ref([])
const members = ref([])
const loading = ref(false)
const paying = ref(false)
const keyword = ref('')

const payVisible = ref(false)
const currentBill = ref(null)
const payMethod = ref('现金')
const received = ref(0)
const memberId = ref(null)

const dailyVisible = ref(false)
const today = todayStr()

const payMethods = [
  { label: '现金', code: 'cash' },
  { label: '微信支付', code: 'wechat' },
  { label: '支付宝', code: 'alipay' },
  { label: '银行卡', code: 'bankcard' },
  { label: '会员余额', code: 'member' }
]

const payable = computed(() => payableOf(currentBill.value || {}))

const pendingList = computed(() =>
  bills.value.filter(b => b.settleStatus !== '已结算' && b.settleStatus !== '已退款')
)

const pendingAmount = computed(() =>
  pendingList.value.reduce((sum, b) => sum + payableOf(b), 0)
)

const filteredList = computed(() => {
  const kw = keyword.value.trim()
  if (!kw) return pendingList.value
  return pendingList.value.filter(
    b =>
      String(b.billNo || '').includes(kw) ||
      String(b.guestName || '').includes(kw) ||
      String(b.roomNumber || '').includes(kw)
  )
})

const todaySettled = computed(() =>
  bills.value.filter(
    b => b.settleStatus === '已结算' && String(b.settleTime || '').startsWith(today)
  )
)

const todayAmount = computed(() =>
  todaySettled.value.reduce((sum, b) => sum + Number(b.actualAmount || 0), 0)
)

const todayPayments = computed(() =>
  payments.value.filter(
    p => p.status === '已支付' && String(p.payTime || '').startsWith(today)
  )
)

const selectedMember = computed(() => members.value.find(m => m.id === memberId.value) || null)

const dailyRows = computed(() => {
  const map = new Map()
  todayPayments.value.forEach(p => {
    const key = p.channel || '其他'
    const row = map.get(key) || { channel: key, count: 0, amount: 0 }
    row.count += 1
    row.amount += Number(p.amount || 0)
    map.set(key, row)
  })
  const onlineAmount = todayPayments.value.reduce((sum, p) => sum + Number(p.amount || 0), 0)
  const offline = todayAmount.value - onlineAmount
  if (offline > 0.001) {
    map.set('现金 / 银行卡（直接结算）', {
      channel: '现金 / 银行卡（直接结算）',
      count: Math.max(0, todaySettled.value.length - todayPayments.value.length),
      amount: offline
    })
  }
  return [...map.values()]
})

function payableOf(bill) {
  const receivable = Number(bill.receivableAmount || 0)
  const deposit = Number(bill.depositDeduct || 0)
  return Math.max(0, Math.round((receivable - deposit) * 100) / 100)
}

function formatTime(value) {
  if (!value) return '-'
  return String(value).replace('T', ' ').slice(0, 19)
}

async function load() {
  loading.value = true
  try {
    const billRes = await api.get('/bills')
    bills.value = billRes.data || []
  } catch (e) {
    bills.value = []
  }
  try {
    const paymentRes = await api.get('/payment')
    payments.value = paymentRes.data || []
  } catch (e) {
    payments.value = []
  }
  try {
    const memberRes = await api.get('/members')
    members.value = memberRes.data || []
  } catch (e) {
    members.value = []
  }
  loading.value = false
}

function openPay(row) {
  currentBill.value = row
  payMethod.value = '现金'
  received.value = payableOf(row)
  memberId.value = null
  payVisible.value = true
}

async function submitPay() {
  if (!currentBill.value) return
  const bill = currentBill.value
  const amount = payable.value

  if (payMethod.value === '现金') {
    if (Number(received.value) < amount) {
      ElMessage.error('实收金额不足')
      return
    }
  }
  if (payMethod.value === '会员余额') {
    if (!selectedMember.value) {
      ElMessage.warning('请选择会员')
      return
    }
    if (Number(selectedMember.value.balance) < amount) {
      ElMessage.error('会员余额不足，请更换支付方式')
      return
    }
  }

  paying.value = true
  try {
    if (payMethod.value === '微信支付' || payMethod.value === '支付宝') {
      try {
        await ElMessageBox.confirm(
          '模拟沙箱扫码支付，确认已完成支付？',
          `${payMethod.value}（沙箱）`,
          { type: 'info', confirmButtonText: '我已支付' }
        )
      } catch (e) {
        return
      }
      const created = await api.post('/payment/create', {
        billId: bill.id,
        orderNo: bill.billNo,
        channel: payMethod.value,
        amount
      })
      await api.put(`/payment/callback/${created.data.paymentNo}`)
      ElMessage.success('支付成功，账单已自动结算')
    } else if (payMethod.value === '会员余额') {
      await api.put(`/members/${selectedMember.value.id}/consume`, { amount })
      await api.put(`/bills/${bill.id}/settle`, { actualAmount: amount })
      ElMessage.success('会员余额扣款成功，账单已结算')
    } else {
      await api.put(`/bills/${bill.id}/settle`, { actualAmount: amount })
      const change = payMethod.value === '现金' ? Number(received.value) - amount : 0
      if (payMethod.value === '现金') {
        ElMessage.success('现金收款成功，账单已结算')
      } else {
        ElMessage.success('银行卡收款成功，账单已结算')
      }
    }
    payVisible.value = false
    await load()
  } finally {
    paying.value = false
  }
}

function openDaily() {
  dailyVisible.value = true
}

onMounted(load)
</script>

<style scoped>
.stat-row {
  margin-bottom: 4px;
}
.stat-card {
  margin-bottom: 12px;
}
.stat-label {
  color: #909399;
  font-size: 13px;
}
.stat-value {
  font-size: 22px;
  font-weight: 600;
  margin-top: 6px;
  color: #303133;
}
.stat-value.warning {
  color: #e6a23c;
}
.stat-value.success {
  color: #67c23a;
}
.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}
.payable {
  color: #f56c6c;
  font-weight: 600;
  font-size: 16px;
}
.change-tip {
  margin-left: 12px;
  color: #606266;
  font-size: 13px;
}
.danger-text {
  color: #f56c6c;
}
</style>