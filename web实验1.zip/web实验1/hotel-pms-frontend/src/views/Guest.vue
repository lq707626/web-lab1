<template>
  <div class="guest-page">
    <header class="guest-header">
      <div class="brand">
        <span class="brand-main">西安工程大学 · 酒店 PMS</span>
        <span class="brand-sub">在线预订 · 无需登录</span>
      </div>
      <el-button plain data-testid="guest-login-btn" @click="goLogin">员工登录</el-button>
    </header>

    <main class="guest-main">
      <el-tabs v-model="activeTab" class="guest-tabs" data-testid="guest-tabs">
        <el-tab-pane label="房型预订" name="book">
          <el-row :gutter="16" v-loading="loading">
            <el-col v-for="type in roomTypes" :key="type.id" :xs="24" :sm="12" :md="8">
              <el-card shadow="hover" class="type-card" data-testid="guest-roomtype-card" :data-type-id="type.id">
                <div class="type-name">{{ type.typeName }}</div>
                <div class="type-meta">
                  <el-tag size="small" type="info">{{ type.bedType }}</el-tag>
                  <span class="type-area">{{ type.area }} ㎡</span>
                </div>
                <div class="type-price">¥{{ money(type.basePrice) }}<span class="unit"> / 晚</span></div>
                <div class="type-available">当前可售 {{ availableCount(type.id) }} 间</div>
                <el-button
                  type="primary"
                  class="book-btn"
                  :disabled="availableCount(type.id) <= 0"
                  data-testid="guest-book-btn"
                  @click="openBook(type)"
                >
                  立即预订
                </el-button>
              </el-card>
            </el-col>
            <el-col v-if="!loading && roomTypes.length === 0" :span="24">
              <el-empty description="暂无可预订房型" />
            </el-col>
          </el-row>
        </el-tab-pane>

        <el-tab-pane label="实时房态" name="status">
          <el-card shadow="never">
            <div class="status-tip">展示可售房间（空房 / 已预订），维修中与待清洁房间不对外展示</div>
            <el-row :gutter="12" v-loading="loading">
              <el-col v-for="room in guestRooms" :key="room.id" :xs="12" :sm="8" :md="6" :lg="4">
                <div
                  class="room-card"
                  data-testid="guest-room-card"
                  :data-room-number="room.roomNumber"
                  :data-room-status="room.roomStatus"
                >
                  <div class="room-card-no">{{ room.roomNumber }}</div>
                  <div class="room-card-type">{{ room.typeName }}</div>
                  <div class="room-card-price">¥{{ money(room.basePrice) }}</div>
                  <div class="room-card-status">{{ room.roomStatus }}</div>
                </div>
              </el-col>
              <el-col v-if="!loading && guestRooms.length === 0" :span="24">
                <el-empty description="暂无可用房间" />
              </el-col>
            </el-row>
          </el-card>
        </el-tab-pane>

        <el-tab-pane label="订单查询" name="query">
          <el-card shadow="never" class="query-card">
            <el-form :inline="true" :model="queryForm">
              <el-form-item label="手机号">
                <el-input
                  v-model="queryForm.phone"
                  placeholder="下单时填写的手机号"
                  maxlength="11"
                  style="width: 180px"
                  data-testid="guest-query-phone-input"
                />
              </el-form-item>
              <el-form-item label="查询码">
                <el-input
                  v-model="queryForm.queryCode"
                  placeholder="6 位查询码"
                  maxlength="6"
                  style="width: 150px"
                  data-testid="guest-query-code-input"
                />
              </el-form-item>
              <el-form-item>
                <el-button
                  type="primary"
                  :loading="querying"
                  data-testid="guest-query-btn"
                  @click="doQuery"
                >
                  查询订单
                </el-button>
              </el-form-item>
            </el-form>

            <el-descriptions v-if="queryResult" :column="2" border style="margin-top: 12px" data-testid="guest-query-result">
              <el-descriptions-item label="订单号">{{ queryResult.orderNo }}</el-descriptions-item>
              <el-descriptions-item label="订单状态">
                <el-tag :type="RESERVATION_STATUS_TYPE[queryResult.status] || 'info'">{{ queryResult.status }}</el-tag>
              </el-descriptions-item>
              <el-descriptions-item label="客人姓名">{{ queryResult.guestName }}</el-descriptions-item>
              <el-descriptions-item label="房型">{{ queryResult.typeName || '-' }}</el-descriptions-item>
              <el-descriptions-item label="入住日期">{{ queryResult.checkInDate }}</el-descriptions-item>
              <el-descriptions-item label="离店日期">{{ queryResult.checkOutDate }}</el-descriptions-item>
              <el-descriptions-item label="间数">{{ queryResult.roomCount }} 间</el-descriptions-item>
              <el-descriptions-item label="预订时间">{{ formatTime(queryResult.createTime) }}</el-descriptions-item>
            </el-descriptions>
            <el-empty v-else description="输入手机号与查询码查看订单" :image-size="80" />
          </el-card>
        </el-tab-pane>
      </el-tabs>
    </main>

    <!-- 预订表单 -->
    <el-dialog v-model="bookVisible" title="填写预订信息" width="480px" data-testid="guest-book-dialog" @closed="resetBook">
      <el-form ref="bookFormRef" :model="bookForm" :rules="rules" label-width="90px">
        <el-form-item label="房型">
          <el-input
            :model-value="`${bookingType?.typeName || ''}（¥${money(bookingType?.basePrice)}/晚）`"
            disabled
            data-testid="guest-book-roomtype-input"
          />
        </el-form-item>
        <el-form-item label="入住日期" prop="checkInDate">
          <el-date-picker
            v-model="bookForm.checkInDate"
            type="date"
            value-format="YYYY-MM-DD"
            placeholder="选择入住日期"
            style="width: 100%"
            :disabled-date="disabledPast"
            data-testid="guest-book-checkin-date"
          />
        </el-form-item>
        <el-form-item label="离店日期" prop="checkOutDate">
          <el-date-picker
            v-model="bookForm.checkOutDate"
            type="date"
            value-format="YYYY-MM-DD"
            placeholder="选择离店日期"
            style="width: 100%"
            :disabled-date="disabledPast"
            data-testid="guest-book-checkout-date"
          />
        </el-form-item>
        <el-form-item label="间数" prop="roomCount">
          <el-input-number v-model="bookForm.roomCount" :min="1" :max="5" data-testid="guest-book-roomcount-input" />
          <span class="muted" style="margin-left: 10px">共 {{ nights }} 晚，预计 ¥{{ money(nights * bookForm.roomCount * Number(bookingType?.basePrice || 0)) }}</span>
        </el-form-item>
        <el-form-item label="客人姓名" prop="guestName">
          <el-input
            v-model="bookForm.guestName"
            maxlength="50"
            placeholder="请输入入住人姓名"
            data-testid="guest-book-name-input"
          />
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input
            v-model="bookForm.phone"
            maxlength="11"
            placeholder="用于接收订单与查询码"
            data-testid="guest-book-phone-input"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button data-testid="guest-book-cancel-btn" @click="bookVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitting" data-testid="guest-book-submit-btn" @click="submitBook">
          提交预订
        </el-button>
      </template>
    </el-dialog>

    <!-- 预订成功 -->
    <el-dialog v-model="resultVisible" title="预订成功" width="420px" data-testid="guest-result-dialog">
      <el-result icon="success" title="预订成功" sub-title="请保存订单号与查询码，凭手机号 + 查询码可查询订单">
        <template #extra>
          <el-descriptions :column="1" border size="small">
            <el-descriptions-item label="订单号">{{ result.orderNo }}</el-descriptions-item>
            <el-descriptions-item label="查询码">
              <span class="query-code">{{ result.queryCode }}</span>
            </el-descriptions-item>
          </el-descriptions>
        </template>
      </el-result>
      <template #footer>
        <el-button type="primary" data-testid="guest-result-ok-btn" @click="afterBooked">我知道了</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import api from '../api'
import {
  RESERVATION_STATUS_TYPE,
  diffDays,
  isValidPhone,
  money
} from '../utils/format'

const router = useRouter()

const activeTab = ref('book')
const loading = ref(false)
const submitting = ref(false)
const querying = ref(false)
const roomTypes = ref([])
const guestRooms = ref([])

const bookVisible = ref(false)
const bookingType = ref(null)
const bookFormRef = ref(null)
const bookForm = reactive({
  checkInDate: '',
  checkOutDate: '',
  roomCount: 1,
  guestName: '',
  phone: ''
})

const resultVisible = ref(false)
const result = reactive({ orderNo: '', queryCode: '' })
const lastPhone = ref('')

const queryForm = reactive({ phone: '', queryCode: '' })
const queryResult = ref(null)

const nights = computed(() => diffDays(bookForm.checkInDate, bookForm.checkOutDate))

function availableCount(typeId) {
  return guestRooms.value.filter(room => room.roomTypeId === typeId && room.roomStatus === '空房').length
}

function formatTime(value) {
  if (!value) return '-'
  return String(value).replace('T', ' ').slice(0, 19)
}

function disabledPast(date) {
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  return date.getTime() < today.getTime()
}

function validatePhone(rule, value, callback) {
  if (!value) {
    callback(new Error('手机号不能为空'))
  } else if (!isValidPhone(value)) {
    callback(new Error('手机号格式不正确'))
  } else {
    callback()
  }
}

function validateCheckOut(rule, value, callback) {
  if (!value) {
    callback(new Error('请选择离店日期'))
  } else if (bookForm.checkInDate && diffDays(bookForm.checkInDate, value) <= 0) {
    callback(new Error('离店日期必须晚于入住日期'))
  } else {
    callback()
  }
}

const rules = {
  checkInDate: [{ required: true, message: '请选择入住日期', trigger: 'change' }],
  checkOutDate: [{ required: true, validator: validateCheckOut, trigger: 'change' }],
  roomCount: [{ required: true, message: '请选择间数', trigger: 'change' }],
  guestName: [{ required: true, message: '客人姓名不能为空', trigger: 'blur' }],
  phone: [{ required: true, validator: validatePhone, trigger: 'blur' }]
}

async function load() {
  loading.value = true
  try {
    const [typeRes, roomRes] = await Promise.all([
      api.get('/guest/room-types'),
      api.get('/guest/rooms')
    ])
    roomTypes.value = typeRes.data || []
    guestRooms.value = roomRes.data || []
  } finally {
    loading.value = false
  }
}

function openBook(type) {
  bookingType.value = type
  const today = new Date()
  const tomorrow = new Date(today.getTime() + 86400000)
  const p = n => String(n).padStart(2, '0')
  const fmt = d => `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
  bookForm.checkInDate = fmt(today)
  bookForm.checkOutDate = fmt(tomorrow)
  bookForm.roomCount = 1
  bookVisible.value = true
}

function resetBook() {
  bookForm.checkInDate = ''
  bookForm.checkOutDate = ''
  bookForm.roomCount = 1
  bookForm.guestName = ''
  bookForm.phone = ''
  bookFormRef.value?.clearValidate()
}

async function submitBook() {
  if (!bookFormRef.value) return
  try {
    await bookFormRef.value.validate()
  } catch (e) {
    return
  }
  submitting.value = true
  try {
    const res = await api.post('/guest/reservation', {
      guestName: bookForm.guestName,
      phone: bookForm.phone,
      roomTypeId: bookingType.value.id,
      checkInDate: bookForm.checkInDate,
      checkOutDate: bookForm.checkOutDate,
      roomCount: bookForm.roomCount,
      remark: '游客端在线预订'
    })
    result.orderNo = res.data.orderNo
    result.queryCode = res.data.queryCode
    lastPhone.value = bookForm.phone
    bookVisible.value = false
    resultVisible.value = true
    await load()
  } finally {
    submitting.value = false
  }
}

function afterBooked() {
  resultVisible.value = false
  queryForm.phone = lastPhone.value
  queryForm.queryCode = result.queryCode
  activeTab.value = 'query'
}

async function doQuery() {
  if (!isValidPhone(queryForm.phone)) {
    ElMessage.warning('请输入正确的手机号')
    return
  }
  if (!queryForm.queryCode) {
    ElMessage.warning('请输入查询码')
    return
  }
  querying.value = true
  try {
    const res = await api.get('/guest/reservation/query', {
      params: { phone: queryForm.phone, queryCode: queryForm.queryCode }
    })
    queryResult.value = res.data
  } catch (e) {
    queryResult.value = null
  } finally {
    querying.value = false
  }
}

function goLogin() {
  router.push('/login')
}

onMounted(load)
</script>

<style scoped>
.guest-page {
  min-height: 100vh;
  background: #f4f6f9;
}
.guest-header {
  height: 68px;
  background: #fff;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 32px;
  box-shadow: 0 1px 6px rgba(0, 0, 0, 0.06);
}
.brand-main {
  font-size: 19px;
  font-weight: 700;
  color: #303133;
}
.brand-sub {
  margin-left: 12px;
  font-size: 13px;
  color: #909399;
}
.guest-main {
  max-width: 1080px;
  margin: 20px auto;
  padding: 0 16px;
}
.guest-tabs {
  background: transparent;
}
.type-card {
  margin-bottom: 16px;
  border-radius: 8px;
}
.type-name {
  font-size: 18px;
  font-weight: 600;
  color: #303133;
}
.type-meta {
  margin: 8px 0;
  color: #909399;
  font-size: 13px;
  display: flex;
  align-items: center;
  gap: 8px;
}
.type-price {
  color: #f56c6c;
  font-size: 24px;
  font-weight: 700;
  margin: 4px 0;
}
.type-price .unit {
  font-size: 13px;
  color: #909399;
  font-weight: normal;
}
.type-available {
  color: #67c23a;
  font-size: 13px;
  margin-bottom: 10px;
}
.book-btn {
  width: 100%;
}
.status-tip {
  color: #909399;
  font-size: 13px;
  margin-bottom: 12px;
}
.room-card {
  border-radius: 8px;
  color: #fff;
  padding: 14px 12px;
  margin-bottom: 12px;
  text-align: center;
}
/* 房态配色通过 data-room-status 属性驱动，不使用业务 CSS class（满足可测试性要求 8.3） */
.room-card[data-room-status='空房'] {
  background: #67c23a;
}
.room-card[data-room-status='已预订'] {
  background: #e6a23c;
}
.room-card-no {
  font-size: 20px;
  font-weight: bold;
}
.room-card-type,
.room-card-price,
.room-card-status {
  font-size: 12px;
  margin-top: 2px;
}
.query-card {
  min-height: 260px;
}
.muted {
  color: #909399;
  font-size: 12px;
}
.query-code {
  font-size: 18px;
  font-weight: 700;
  color: #f56c6c;
  letter-spacing: 2px;
}
</style>