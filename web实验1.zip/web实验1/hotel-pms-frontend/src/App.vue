<template>
  <router-view />
</template>

<style>
body { margin: 0; font-family: 'Helvetica Neue', Arial, sans-serif; }
</style>
