package com.hotel.pms.mapper;

import com.hotel.pms.entity.Room;
import com.hotel.pms.vo.RoomVO;
import org.apache.ibatis.annotations.*;
import java.util.List;

public interface RoomMapper {
    @Select("SELECT r.*, rt.type_name, rt.bed_type, rt.base_price FROM room r " +
            "LEFT JOIN room_type rt ON r.room_type_id = rt.id " +
            "WHERE r.is_deleted = 0 ORDER BY r.floor, r.room_number")
    List<Room> findAll();

    @Select("SELECT r.*, rt.type_name, rt.bed_type, rt.base_price FROM room r " +
            "LEFT JOIN room_type rt ON r.room_type_id = rt.id " +
            "WHERE r.id = #{id} AND r.is_deleted = 0")
    Room findById(@Param("id") Long id);

    @Update("UPDATE room SET room_status = #{status}, version = version + 1, update_time = NOW() " +
            "WHERE id = #{id} AND version = #{version} AND is_deleted = 0")
    int updateStatus(@Param("id") Long id, @Param("status") String status, @Param("version") Integer version);

    @Update("UPDATE room SET room_status = #{status}, update_time = NOW() WHERE id = #{id} AND is_deleted = 0")
    int updateStatusSimple(@Param("id") Long id, @Param("status") String status);

    @Select("SELECT COUNT(*) FROM room WHERE room_type_id = #{typeId} AND is_deleted = 0")
    int countByTypeId(@Param("typeId") Long typeId);

    @Select("SELECT COUNT(*) FROM room WHERE room_type_id = #{typeId} AND room_status = '空房' AND is_deleted = 0")
    int countEmptyByTypeId(@Param("typeId") Long typeId);

    /* ========== 以下方法由 RoomMapper.xml 实现（一对一/多对多联查） ========== */

    /** 房间列表（房间 + 房型 + 门锁 一对一） */
    List<RoomVO> findAllVO();

    /** 房间详情（房间 + 房型 + 门锁） */
    RoomVO findDetailById(@Param("id") Long id);
}
