package com.hotel.pms.vo;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 预订视图对象：预订 + 房型名称
 */
@Data
public class ReservationVO {
    private Long id;
    private String orderNo;
    private String guestName;
    private String phone;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private Long roomTypeId;
    private String typeName;
    private Integer roomCount;
    private String status;
    private String queryCode;
    private String remark;
    private String createBy;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
