package com.hotel.pms.vo;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 员工视图对象（不返回密码哈希）
 */
@Data
public class EmployeeVO {
    private Long id;
    private String username;
    private String name;
    private String role;
    private LocalDateTime createTime;
}
