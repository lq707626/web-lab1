package com.hotel.pms.mapper;

import com.hotel.pms.entity.Reservation;
import com.hotel.pms.vo.ReservationVO;
import org.apache.ibatis.annotations.*;
import java.time.LocalDate;
import java.util.List;

public interface ReservationMapper {
    @Select("SELECT r.*, rt.type_name FROM reservation r " +
            "LEFT JOIN room_type rt ON r.room_type_id = rt.id " +
            "WHERE r.is_deleted = 0 ORDER BY r.create_time DESC")
    List<Reservation> findAll();

    @Select("SELECT r.*, rt.type_name FROM reservation r " +
            "LEFT JOIN room_type rt ON r.room_type_id = rt.id " +
            "WHERE r.is_deleted = 0 ORDER BY r.create_time DESC " +
            "LIMIT #{offset}, #{size}")
    List<Reservation> findPage(@Param("offset") int offset, @Param("size") int size);

    @Select("SELECT COUNT(*) FROM reservation WHERE is_deleted = 0")
    long count();

    @Select("SELECT COUNT(*) FROM reservation WHERE room_type_id = #{typeId} " +
            "AND status IN ('待确认', '已确认') AND is_deleted = 0")
    int countActiveByTypeId(@Param("typeId") Long typeId);

    /**
     * 按"房型 + 日期区间"统计已占用房间数（报告 3.4：预订阶段按房型 + 日期占用库存）
     * 区间重叠判定：已有预订.check_in < 本次离店 AND 已有预订.check_out > 本次入住
     */
    @Select("SELECT COALESCE(SUM(room_count), 0) FROM reservation " +
            "WHERE room_type_id = #{typeId} AND status IN ('待确认', '已确认') AND is_deleted = 0 " +
            "AND check_in_date < #{checkOut} AND check_out_date > #{checkIn}")
    int countOverlapByTypeId(@Param("typeId") Long typeId,
                             @Param("checkIn") LocalDate checkIn,
                             @Param("checkOut") LocalDate checkOut);

    @Select("SELECT r.*, rt.type_name FROM reservation r " +
            "LEFT JOIN room_type rt ON r.room_type_id = rt.id " +
            "WHERE r.id = #{id} AND r.is_deleted = 0")
    Reservation findById(@Param("id") Long id);

    @Select("SELECT r.*, rt.type_name FROM reservation r " +
            "LEFT JOIN room_type rt ON r.room_type_id = rt.id " +
            "WHERE r.phone = #{phone} AND r.is_deleted = 0 " +
            "ORDER BY r.create_time DESC LIMIT 1")
    Reservation findByPhone(@Param("phone") String phone);

    @Select("SELECT r.*, rt.type_name FROM reservation r " +
            "LEFT JOIN room_type rt ON r.room_type_id = rt.id " +
            "WHERE r.phone = #{phone} AND r.query_code = #{queryCode} AND r.is_deleted = 0 " +
            "ORDER BY r.create_time DESC LIMIT 1")
    Reservation findByPhoneAndQueryCode(@Param("phone") String phone,
                                         @Param("queryCode") String queryCode);

    @Insert("INSERT INTO reservation(order_no, guest_name, phone, check_in_date, check_out_date, " +
            "room_type_id, room_count, status, query_code, create_by, remark) " +
            "VALUES(#{orderNo}, #{guestName}, #{phone}, #{checkInDate}, #{checkOutDate}, " +
            "#{roomTypeId}, #{roomCount}, #{status}, #{queryCode}, #{createBy}, #{remark})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Reservation reservation);

    @Update("UPDATE reservation SET status = #{status}, update_time = NOW() WHERE id = #{id} AND is_deleted = 0")
    int updateStatus(@Param("id") Long id, @Param("status") String status);

    /** 办理入住后把关联预订置为"已到店"（报告 3.3 订单状态） */
    @Update("UPDATE reservation SET status = '已到店', update_time = NOW() " +
            "WHERE id = #{id} AND status IN ('待确认', '已确认') AND is_deleted = 0")
    int markArrived(@Param("id") Long id);

    @Update("UPDATE reservation SET status = '已取消', " +
            "remark = CASE WHEN #{reason} IS NULL OR #{reason} = '' THEN remark " +
            "ELSE CONCAT(IFNULL(remark, ''), ' | 取消原因：', #{reason}) END, " +
            "update_time = NOW() WHERE id = #{id} AND is_deleted = 0")
    int cancel(@Param("id") Long id, @Param("reason") String reason);

    /* ========== 以下方法由 ReservationMapper.xml 实现（条件分页 / 编辑 / 删除） ========== */

    List<ReservationVO> findPageVO(@Param("offset") int offset,
                                   @Param("size") int size,
                                   @Param("keyword") String keyword,
                                   @Param("status") String status);

    long countVO(@Param("keyword") String keyword, @Param("status") String status);

    ReservationVO findVOById(@Param("id") Long id);

    int logicalDelete(@Param("id") Long id);

    /** 编辑预订信息（客人、日期、房型、间数、备注） */
    int updateInfo(Reservation reservation);

    /** 编辑时校验库存：排除自身后，统计同房型日期重叠的已占用间数 */
    int countOverlapExcludeId(@Param("typeId") Long typeId,
                              @Param("checkIn") LocalDate checkIn,
                              @Param("checkOut") LocalDate checkOut,
                              @Param("excludeId") Long excludeId);
}
