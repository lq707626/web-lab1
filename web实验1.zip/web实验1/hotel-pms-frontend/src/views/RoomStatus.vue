<template>
  <div v-loading="loading">
    <el-card shadow="never">
      <div class="toolbar">
        <div class="legend">
          <el-check-tag
            v-for="item in ROOM_STATUS_LIST"
            :key="item.code"
            :checked="statusFilter === item.label"
            class="legend-tag"
            :data-testid="`room-filter-${item.code}`"
            @change="toggleFilter(item.label)"
          >
            <span class="dot" :style="{ background: item.color }"></span>
            {{ item.label }}（{{ countByStatus(item.label) }}）
          </el-check-tag>
          <el-check-tag
            :checked="statusFilter === ''"
            class="legend-tag"
            data-testid="room-filter-all"
            @change="toggleFilter('')"
          >
            全部（{{ rooms.length }}）
          </el-check-tag>
        </div>
        <div class="actions">
          <span class="summary">共 {{ rooms.length }} 间客房 / {{ floorList.length }} 个楼层</span>
          <el-button type="primary" plain :icon="Refresh" :loading="loading" data-testid="room-refresh-btn" @click="loadRooms">
            刷新房态
          </el-button>
        </div>
      </div>

      <el-empty v-if="!loading && visibleRooms.length === 0" description="暂无符合条件的房间" />

      <div v-for="floor in floorList" :key="floor">
        <div class="floor-title">{{ floor }} 楼 <span class="floor-count">（{{ countByFloor(floor) }} 间）</span></div>
        <el-row :gutter="12">
          <el-col v-for="room in roomsOfFloor(floor)" :key="room.id" :xs="12" :sm="8" :md="6" :lg="4">
            <div
              class="room-cell"
              :style="{ background: roomColor(room.roomStatus) }"
              role="button"
              tabindex="0"
              data-testid="room-cell"
              :data-room-number="room.roomNumber"
              :data-room-status="room.roomStatus"
              @click="openRoomDialog(room)"
              @keyup.enter="openRoomDialog(room)"
            >
              <div class="room-no">{{ room.roomNumber }}</div>
              <div class="room-type">{{ room.typeName || '未分配房型' }}</div>
              <div class="room-price">¥{{ money(room.basePrice) }}</div>
              <div class="room-status">{{ room.roomStatus }}</div>
            </div>
          </el-col>
        </el-row>
      </div>
    </el-card>

    <el-dialog v-model="dialogVisible" title="房间详情与房态变更" width="460px" data-testid="room-detail-dialog">
      <el-descriptions :column="2" border>
        <el-descriptions-item label="房间号">{{ currentRoom?.roomNumber }}</el-descriptions-item>
        <el-descriptions-item label="楼层">{{ currentRoom?.floor }} 楼</el-descriptions-item>
        <el-descriptions-item label="房型">{{ currentRoom?.typeName || '-' }}</el-descriptions-item>
        <el-descriptions-item label="床型">{{ currentRoom?.bedType || '-' }}</el-descriptions-item>
        <el-descriptions-item label="房价">¥{{ money(currentRoom?.basePrice) }}</el-descriptions-item>
        <el-descriptions-item label="当前房态">
          <el-tag :color="roomColor(currentRoom?.roomStatus)" style="color:#fff;border:none">
            {{ currentRoom?.roomStatus }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="门锁" :span="2">
          {{ currentRoom?.lockNo || '-' }}（{{ currentRoom?.lockStatus || '未配置' }}）
        </el-descriptions-item>
        <el-descriptions-item label="客房设施" :span="2">
          <el-tag
            v-for="a in currentRoom?.amenities || []"
            :key="a.id"
            size="small"
            type="info"
            style="margin: 0 6px 4px 0"
          >{{ a.name }}</el-tag>
          <span v-if="!(currentRoom?.amenities || []).length" class="muted">暂无设施</span>
        </el-descriptions-item>
        <el-descriptions-item label="数据版本" :span="2">
          v{{ currentRoom?.version ?? 0 }}（乐观锁，防止多终端同时修改）
        </el-descriptions-item>
      </el-descriptions>

      <el-form label-width="80px" class="status-form">
        <el-form-item label="目标房态">
          <el-select
            v-model="newStatus"
            placeholder="请选择目标房态"
            style="width: 100%"
            data-testid="room-status-select"
          >
            <el-option v-for="item in ROOM_STATUS_LIST" :key="item.code" :label="item.label" :value="item.label" />
          </el-select>
        </el-form-item>
      </el-form>
      <el-alert
        v-if="currentRoom?.roomStatus === '已入住'"
        type="warning"
        :closable="false"
        title="已入住房间需先在【入住管理】办理退房，房态不能手工修改"
      />
      <el-alert
        v-else-if="currentRoom?.roomStatus === '待清洁'"
        type="info"
        :closable="false"
        title="待清洁房间打扫完成后可改为空房"
      />

      <template #footer>
        <el-button data-testid="room-status-cancel-btn" @click="dialogVisible = false">取消</el-button>
        <el-button
          type="primary"
          :loading="saving"
          :disabled="saving"
          data-testid="room-status-submit-btn"
          @click="saveStatus"
        >
          保存房态
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { Refresh } from '@element-plus/icons-vue'
import api from '../api'
import { ROOM_STATUS_LIST, ROOM_STATUS_TRANSITIONS, money, roomColor } from '../utils/format'

const rooms = ref([])
const loading = ref(false)
const saving = ref(false)
const statusFilter = ref('')
const dialogVisible = ref(false)
const currentRoom = ref(null)
const newStatus = ref('')

const visibleRooms = computed(() =>
  statusFilter.value ? rooms.value.filter(room => room.roomStatus === statusFilter.value) : rooms.value
)

const floorList = computed(() => {
  const floors = [...new Set(visibleRooms.value.map(room => room.floor ?? 0))]
  return floors.sort((a, b) => a - b)
})

function roomsOfFloor(floor) {
  return visibleRooms.value
    .filter(room => (room.floor ?? 0) === floor)
    .sort((a, b) => String(a.roomNumber).localeCompare(String(b.roomNumber)))
}

function countByStatus(status) {
  return rooms.value.filter(room => room.roomStatus === status).length
}

function countByFloor(floor) {
  return visibleRooms.value.filter(room => (room.floor ?? 0) === floor).length
}

function toggleFilter(status) {
  statusFilter.value = statusFilter.value === status ? '' : status
}

async function loadRooms() {
  loading.value = true
  try {
    const res = await api.get('/rooms')
    rooms.value = res.data || []
  } finally {
    loading.value = false
  }
}

function openRoomDialog(room) {
  currentRoom.value = { ...room }
  newStatus.value = room.roomStatus
  dialogVisible.value = true
}

async function saveStatus() {
  const room = currentRoom.value
  if (!room) return
  if (newStatus.value === room.roomStatus) {
    ElMessage.info('房态未发生变化')
    return
  }

  const allowed = ROOM_STATUS_TRANSITIONS[room.roomStatus] || []
  if (!allowed.includes(newStatus.value)) {
    if (room.roomStatus === '已入住') {
      ElMessage.error('已入住房间需先办理退房，不能直接修改房态')
    } else {
      // 固定文案，便于自动化断言；具体的当前房态/目标房态在弹窗中可见
      ElMessage.error('当前房态不允许变更为所选房态')
    }
    return
  }

  saving.value = true
  try {
    // 必须携带 version，后端用 WHERE id = ? AND version = ? 做乐观锁校验
    await api.put(`/rooms/${room.id}/status`, { status: newStatus.value, version: room.version })
    ElMessage.success('房态已更新')
    dialogVisible.value = false
    await loadRooms()
  } catch (e) {
    // 乐观锁失败提示由拦截器弹出，这里刷新最新房态
    await loadRooms()
  } finally {
    saving.value = false
  }
}

onMounted(loadRooms)
</script>

<style scoped>
.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 12px;
}
.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
.legend-tag {
  display: inline-flex;
  align-items: center;
  font-size: 13px;
}
.dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  margin-right: 6px;
  display: inline-block;
}
.actions {
  display: flex;
  align-items: center;
  gap: 12px;
}
.summary {
  color: #909399;
  font-size: 13px;
}
.floor-title {
  margin: 14px 0 8px;
  font-size: 14px;
  font-weight: 600;
  color: #303133;
}
.floor-count {
  color: #909399;
  font-weight: normal;
  font-size: 12px;
}
.room-cell {
  height: 108px;
  border-radius: 6px;
  color: #fff;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  margin-bottom: 12px;
  transition: transform 0.2s, box-shadow 0.2s;
  user-select: none;
}
.room-cell:hover {
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.18);
}
.room-no {
  font-size: 20px;
  font-weight: bold;
}
.room-type {
  font-size: 12px;
  margin-top: 2px;
}
.room-price {
  font-size: 12px;
  opacity: 0.9;
}
.room-status {
  font-size: 12px;
  margin-top: 4px;
  background: rgba(255, 255, 255, 0.22);
  border-radius: 8px;
  padding: 0 8px;
}
.status-form {
  margin-top: 16px;
}
.muted {
  color: #909399;
}
</style>