package com.hotel.pms.modules.room;

import com.hotel.pms.vo.RoomVO;

import java.util.List;

public interface RoomService {

    List<RoomVO> list();

    RoomVO findById(Long id);

    void updateStatus(Long id, String status, Integer version);
}
