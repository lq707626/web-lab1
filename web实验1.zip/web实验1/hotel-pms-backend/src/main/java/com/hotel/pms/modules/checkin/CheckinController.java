package com.hotel.pms.modules.checkin;

import com.hotel.pms.common.PageResult;
import com.hotel.pms.common.Result;
import com.hotel.pms.entity.Checkin;
import com.hotel.pms.vo.CheckinVO;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/checkins")
public class CheckinController {

    private final CheckinService checkinService;

    public CheckinController(CheckinService checkinService) {
        this.checkinService = checkinService;
    }

    @GetMapping
    public Result<List<CheckinVO>> list() {
        return Result.success(checkinService.list());
    }

    /**
     * 条件分页：keyword（姓名/手机号/单号/房间号）、status
     */
    @GetMapping("/page")
    public Result<PageResult<CheckinVO>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String status) {
        return Result.success(checkinService.page(pageNum, pageSize, keyword, status));
    }

    @GetMapping("/{id}")
    public Result<CheckinVO> detail(@PathVariable Long id) {
        return Result.success(checkinService.findById(id));
    }

    @PostMapping
    public Result<CheckinVO> checkin(@RequestBody Checkin checkin) {
        return Result.success(checkinService.checkin(checkin));
    }

    /**
     * 编辑入住信息（姓名、身份证、手机号、押金）
     */
    @PutMapping("/{id}")
    public Result<?> update(@PathVariable Long id, @RequestBody Checkin checkin) {
        checkinService.update(id, checkin);
        return Result.success();
    }

    /**
     * 逻辑删除（仅已退房记录）
     */
    @DeleteMapping("/{id}")
    public Result<?> delete(@PathVariable Long id) {
        checkinService.delete(id);
        return Result.success();
    }

    @PutMapping("/{id}/checkout")
    public Result<?> checkout(@PathVariable Long id) {
        checkinService.checkout(id);
        return Result.success();
    }
}
