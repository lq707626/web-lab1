package com.hotel.pms.entity;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 支付流水（沙箱环境）
 */
@Data
public class Payment {
    private Long id;
    private String paymentNo;      // 支付单号
    private String orderNo;        // 关联订单号
    private Long billId;           // 关联账单ID
    private String channel;        // 支付渠道：微信支付、支付宝
    private BigDecimal amount;     // 支付金额
    private String status;         // 状态：待支付、已支付、已退款、支付失败
    private String tradeNo;        // 第三方交易号（沙箱模拟）
    private LocalDateTime payTime;
    private LocalDateTime refundTime;
    private String remark;
    private String createBy;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
    private Integer isDeleted;
}
